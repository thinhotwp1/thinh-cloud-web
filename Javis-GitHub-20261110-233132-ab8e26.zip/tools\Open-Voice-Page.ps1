param([string]$VoiceUrl='http://127.0.0.1:8766/',[switch]$EnsureWorkOnly,[switch]$NoLock)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
. (Join-Path $PSScriptRoot 'Chrome-Cdp.ps1')
. (Join-Path $PSScriptRoot 'Show-WorkWindow.ps1')
$profile=Join-Path $root 'state\chrome-profile'
$voiceStatePath=Join-Path $root 'state\webspeech-live-browser.json'
$workStatePath=Join-Path $root 'state\browser.json'
$mutex=New-Object Threading.Mutex($false,'Local\JarvisChromePage')
$owned=$false; $socket=$null; $guard=$null; $requestCounter=0
function Invoke-Cdp([string]$Method,[hashtable]$Parameters,[string]$SessionId='') {
    $script:requestCounter++
    $payload=@{id=$script:requestCounter;method=$Method;params=$Parameters}
    if($SessionId) {$payload.sessionId=$SessionId}
    $cts=New-Object Threading.CancellationTokenSource(10000)
    try {
        $bytes=[Text.Encoding]::UTF8.GetBytes(($payload|ConvertTo-Json -Depth 12 -Compress))
        [void]$socket.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,$cts.Token).GetAwaiter().GetResult()
        $buffer=New-Object byte[] 16384
        while($true) {
            $stream=New-Object IO.MemoryStream
            try {
                do {
                    $part=$socket.ReceiveAsync([ArraySegment[byte]]::new($buffer),$cts.Token).GetAwaiter().GetResult()
                    if($part.MessageType -eq [Net.WebSockets.WebSocketMessageType]::Close) {throw 'Chrome disconnected.'}
                    $stream.Write($buffer,0,$part.Count)
                } while(-not $part.EndOfMessage)
                $response=[Text.Encoding]::UTF8.GetString($stream.ToArray())|ConvertFrom-Json
            } finally {$stream.Dispose()}
            if($response.id -eq $script:requestCounter) {
                if($response.error) {throw ($response.error|ConvertTo-Json -Compress)}
                return $response.result
            }
        }
    } finally {$cts.Dispose()}
}
function Is-VoicePage($page) {
    return ($page.targetId -eq $script:rememberedVoice -or $page.url -match '^http://127\.0\.0\.1:876[56](?:/|$)')
}
function New-BackgroundPage {
    return (Invoke-Cdp 'Target.createTarget' @{url='about:blank';newWindow=$true;background=$true;focus=$false}).targetId
}
try {
    if(-not $NoLock) {
        try {$owned=$mutex.WaitOne(15000)} catch [Threading.AbandonedMutexException] {$owned=$true}
        if(-not $owned) {throw 'Another Jarvis browser action is running.'}
    }
    $portLines=@(Get-Content -LiteralPath (Join-Path $profile 'DevToolsActivePort'))
    $endpoint='http://127.0.0.1:'+([int]$portLines[0])
    $version=Invoke-RestMethod ($endpoint+'/json/version') -TimeoutSec 3
    if(([uri]$version.webSocketDebuggerUrl).AbsolutePath -ne $portLines[1]) {throw 'Chrome profile endpoint mismatch.'}
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -Path (Join-Path $PSScriptRoot 'jarvis_windows.cs')
    $dpiContext=[JarvisWindowGuard]::UsePhysicalCoordinates()
    $screen=[Windows.Forms.Screen]::AllScreens | Where-Object {-not $_.Primary} | Select-Object -First 1
    if(-not $screen){$screen=[Windows.Forms.Screen]::PrimaryScreen}
    $area=$screen.WorkingArea
    $browserPids=[uint32[]]@(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" | Where-Object {
        $_.CommandLine -and $_.CommandLine.Contains($profile) -and $_.CommandLine -notmatch '\s--type='
    } | ForEach-Object {$_.ProcessId})
    if(-not $browserPids.Count) {throw 'Owned Jarvis browser process not found.'}
    $guard=New-Object JarvisWindowGuard($area.X,$area.Y,$area.Width,$area.Height,([string[]]@('chrome')),'Chrome_WidgetWin_',$browserPids)
    $socket=New-Object Net.WebSockets.ClientWebSocket
    $socket.ConnectAsync([uri]$version.webSocketDebuggerUrl,[Threading.CancellationToken]::None).GetAwaiter().GetResult()|Out-Null
    $script:rememberedVoice=''
    if(Test-Path -LiteralPath $voiceStatePath) {$script:rememberedVoice=(Get-Content $voiceStatePath -Raw|ConvertFrom-Json).voice_target}
    $pages=@((Invoke-Cdp 'Target.getTargets' @{}).targetInfos|Where-Object type -eq page)
    $voice=$pages|Where-Object {Is-VoicePage $_}|Sort-Object @{Expression={$_.targetId -ne $script:rememberedVoice}}|Select-Object -First 1
    $voiceId=if($voice){$voice.targetId}else{''}
    $rememberedWork=''
    if(Test-Path -LiteralPath $workStatePath) {$rememberedWork=(Get-Content $workStatePath -Raw|ConvertFrom-Json).target_id}
    $worksetIds=@()
    $pendingMarkerPrefix=([uri](Join-Path $root 'state/workset-pending.html')).AbsoluteUri+'#jarvis-'
    $worksetStatePath=Join-Path $root 'state/worksets.json'
    if(Test-Path -LiteralPath $worksetStatePath) {
        $worksetState=Get-Content -LiteralPath $worksetStatePath -Raw -Encoding UTF8|ConvertFrom-Json
        $worksetIds=@($worksetState.tabs|Where-Object target_id|ForEach-Object {$_.target_id})
    }
    $work=$pages|Where-Object {-not(Is-VoicePage $_) -and (-not $voiceId -or $_.openerId -ne $voiceId) -and $_.targetId -notin $worksetIds -and
        -not $_.url.StartsWith($pendingMarkerPrefix,[StringComparison]::OrdinalIgnoreCase)}|Sort-Object @{Expression={$_.targetId -ne $rememberedWork}}|Select-Object -First 1
    $workId=if($work){$work.targetId}else{New-BackgroundPage}
    if(-not $EnsureWorkOnly) {
        if(-not $voiceId) {$voiceId=New-BackgroundPage}
        if(-not $voice -or $voice.url -ne $VoiceUrl) {
            $attached=Invoke-Cdp 'Target.attachToTarget' @{targetId=$voiceId;flatten=$true}
            $navigation=Invoke-Cdp 'Page.navigate' @{url=$VoiceUrl} $attached.sessionId
            if($navigation.errorText) {throw $navigation.errorText}
            [void](Invoke-Cdp 'Target.detachFromTarget' @{sessionId=$attached.sessionId})
        }
    }
    @{target_id=$workId;endpoint=$endpoint}|ConvertTo-Json|Set-Content -Encoding UTF8 -LiteralPath $workStatePath
    if($voiceId) {@{voice_target=$voiceId;work_target=$workId;endpoint=$endpoint;voice_url=$VoiceUrl}|ConvertTo-Json|Set-Content -Encoding UTF8 -LiteralPath $voiceStatePath}
    Start-Sleep -Milliseconds 500
    $guard.Dispose(); $guard=$null
    if($voiceId) {
        $voiceWindow=Invoke-Cdp 'Browser.getWindowForTarget' @{targetId=$voiceId}
        $workWindow=Invoke-Cdp 'Browser.getWindowForTarget' @{targetId=$workId}
        if($voiceWindow.windowId -eq $workWindow.windowId) {throw 'Voice and work tabs share one window. Move the listener into its own Chrome window manually and relaunch.'}
    }
    $showClient=Connect-JarvisCdp $version.webSocketDebuggerUrl
    try{foreach($id in @($voiceId,$workId)|Where-Object {$_ -and (-not $EnsureWorkOnly -or $_ -eq $workId)}) {
        $voiceWidth=[Math]::Min(700,[int]($area.Width*.4))
        $bounds=if($voiceId -and $id -eq $voiceId){@{left=$area.X;top=$area.Y;width=$voiceWidth;height=$area.Height}}elseif($voiceId){@{left=($area.X+$voiceWidth);top=$area.Y;width=($area.Width-$voiceWidth);height=$area.Height}}else{@{left=$area.X;top=$area.Y;width=$area.Width;height=$area.Height}}
        $shown=Show-JarvisWorkWindow $showClient $id $browserPids $bounds.left $bounds.top $bounds.width $bounds.height
        if(-not $shown.visible){throw 'Requested Jarvis window could not be shown.'}
    }}finally{$showClient.socket.Dispose()}
    @{voice_target=$voiceId;work_target=$workId;endpoint=$endpoint}|ConvertTo-Json -Compress
} finally {
    if($guard) {$guard.Dispose()}
    if($socket) {$socket.Dispose()}
    if($owned) {$mutex.ReleaseMutex()}
    $mutex.Dispose()
    if($dpiContext){[JarvisWindowGuard]::RestoreCoordinates($dpiContext)}
}
