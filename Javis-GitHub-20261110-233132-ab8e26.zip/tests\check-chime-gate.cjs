const assert=require('node:assert/strict');
const {setup,flush}=require('./check-webspeech-ui.cjs');

(async()=>{
  const app=setup({nativePet:true,deferNativeDone:true,silenceMs:5000});await flush();
  await app.node('start').onclick();app.instances.at(-1).final('Hey Javis');await flush();
  const speech=app.instances.at(-1);speech.final('open configured page');speech.onspeechend();await app.advance(5000);
  assert.equal(app.pendingNativeDone.length,1,'fixture should hold the Done sound while it plays');
  assert.equal(app.state.listening,false,'wake mic should pause while Done chime plays');
  assert.equal(app.calls.find(c=>c.path==='/api/pet/audio'&&c.body.clip==='done').body.gain,1);
  app.pendingNativeDone[0]({played:true});await flush();
  assert.equal(app.state.phase,'wake');assert.equal(app.state.listening,true);
  app.stop();console.log('PASS: completion chime pauses recognition without changing mic gain.');
})().catch(error=>{console.error(error);process.exitCode=1;});
