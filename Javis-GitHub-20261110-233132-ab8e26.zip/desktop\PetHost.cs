using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace JavisDesktop {
 public sealed class PetHost {
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll",EntryPoint="GetWindowLongW")] static extern int GetStyle(IntPtr h,int i);
  [DllImport("user32.dll",EntryPoint="SetWindowLongW")] static extern int SetStyle(IntPtr h,int i,int s);
  [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
  readonly JavaScriptSerializer json=new JavaScriptSerializer();
  readonly string root,url; readonly bool test,fixture;
  readonly List<string> testActions=new List<string>();
  Window window; Image pet; Border thought,toolbar; TextBlock status,heard,activity;
  Button mic,cancel,sound,sendNow; BitmapSource atlas; CroppedBitmap frame;
  DispatcherTimer animation,poller; string token="",phase="idle",lastError="",lastJob="",epoch="";
  bool dragging,walking,reduced,compact,wantsMic,soundOn=true,closing; Point dragStart; double startLeft,startTop,anchorLeft,anchorTop;
  int row,column,pollBusy; DateTime nextFrame=DateTime.MinValue,errorUntil=DateTime.MinValue; double walkDirection=1;
  static readonly int[] Counts={6,8,8,4,5,8,6,6,6};
  static readonly int[] BaseDurations={140,120,120,140,140,140,150,120,150};
  string settingsPath {get{return Path.Combine(root,"state/pet-layout.json");}}
  public static void Run(string root,string url,bool selfTest,bool fixtureTest) {new PetHost(root,url,selfTest,fixtureTest).Start();}
  PetHost(string root,string url,bool selfTest,bool fixtureTest){this.root=root;this.url=url.TrimEnd('/');test=selfTest;fixture=fixtureTest;}
  static Dictionary<string,object> Obj(object value){return value as Dictionary<string,object> ?? new Dictionary<string,object>();}
  static string Text(Dictionary<string,object> value,string key){object v;return value.TryGetValue(key,out v)&&v!=null?v.ToString():"";}
  static bool Flag(Dictionary<string,object> value,string key){object v;return value.TryGetValue(key,out v)&&v is bool&&(bool)v;}
  object Request(string path,object body) {
   var request=(HttpWebRequest)WebRequest.Create(url+path);request.Proxy=null;request.Timeout=3500;request.ReadWriteTimeout=3500;request.KeepAlive=false;
   if(token.Length>0)request.Headers["X-Jarvis-Token"]=token;
   if(body!=null){request.Method="POST";request.ContentType="application/json";request.Headers["Origin"]=url;
    var bytes=Encoding.UTF8.GetBytes(json.Serialize(body));request.ContentLength=bytes.Length;using(var stream=request.GetRequestStream())stream.Write(bytes,0,bytes.Length);}
   using(var response=request.GetResponse())using(var reader=new StreamReader(response.GetResponseStream(),Encoding.UTF8))return json.DeserializeObject(reader.ReadToEnd());
  }
  void Start() {
   SetThreadDpiAwarenessContext(new IntPtr(-4));
   using(var stream=File.OpenRead(Path.Combine(root,"desktop/PetWindow.xaml")))window=(Window)XamlReader.Load(stream);
   pet=(Image)window.FindName("Pet");thought=(Border)window.FindName("Thought");toolbar=(Border)window.FindName("Toolbar");
   status=(TextBlock)window.FindName("Status");heard=(TextBlock)window.FindName("Heard");activity=(TextBlock)window.FindName("Activity");
   mic=(Button)window.FindName("Mic");cancel=(Button)window.FindName("Cancel");sound=(Button)window.FindName("Sound");sendNow=(Button)window.FindName("SendNow");
   atlas=LoadAtlas();
   if(atlas.PixelWidth!=1536||atlas.PixelHeight!=2288)throw new InvalidOperationException("Unexpected pet atlas dimensions.");
   mic.Click+=(s,e)=>Control(wantsMic?"mic_off":"mic_on");
   cancel.Click+=(s,e)=>Control("cancel_current");
   sendNow.Click+=(s,e)=>Control("send_now");
   ((Button)window.FindName("Compact")).Click+=(s,e)=>{compact=!compact;thought.Visibility=compact?Visibility.Hidden:Visibility.Visible;SavePosition();};
   sound.Click+=(s,e)=>Control(soundOn?"sound_off":"sound_on");
   var menu=new ContextMenu();
   AddMenu(menu,"Lưu cách làm…",()=>SaveRecipe());
   AddMenu(menu,"Tổng hợp hôm nay",()=>Control("summary"));
   AddMenu(menu,"Đọc kết quả",()=>Control("read_result"));
   AddMenu(menu,"Dừng nói",()=>Control("stop_speaking"));
   AddMenu(menu,"Chụp ảnh màn hình",()=>Control("quick_screenshot"));
   AddMenu(menu,"Khóa Windows",()=>Control("quick_lock"));
   AddMenu(menu,"Tắt hai màn hình",()=>Control("quick_screens_off"));
   AddMenu(menu,"Chi tiết…",()=>Control("show_details"));
   AddMenu(menu,"Bật/tắt đi dạo",()=>{walking=!walking;anchorLeft=window.Left;anchorTop=window.Top;SavePosition();});
   AddMenu(menu,"Bật/tắt ít chuyển động",()=>{reduced=!reduced;SavePosition();});
   AddMenu(menu,"Thoát pet (tắt mic)",()=>window.Close());
   ((Button)window.FindName("More")).Click+=(s,e)=>{menu.PlacementTarget=(Button)s;menu.IsOpen=true;};
   pet.MouseLeftButtonDown+=(s,e)=>{dragging=true;dragStart=pet.PointToScreen(e.GetPosition(pet));startLeft=window.Left;startTop=window.Top;pet.CaptureMouse();e.Handled=true;};
   pet.MouseMove+=(s,e)=>{
    if(!dragging)return;var current=pet.PointToScreen(e.GetPosition(pet));var source=(HwndSource)PresentationSource.FromVisual(window);
    var delta=source.CompositionTarget.TransformFromDevice.Transform(current-dragStart);
    SetRow(delta.X<0?2:1);window.Left=startLeft+delta.X;window.Top=startTop+delta.Y;Clamp();};
   pet.MouseLeftButtonUp+=(s,e)=>{dragging=false;pet.ReleaseMouseCapture();anchorLeft=window.Left;anchorTop=window.Top;SetPhase(phase);SavePosition();};
   pet.LostMouseCapture+=(s,e)=>{dragging=false;};
   window.SourceInitialized+=(s,e)=>{var h=new WindowInteropHelper(window).Handle;SetStyle(h,-20,GetStyle(h,-20)|0x08000000);HwndSource.FromHwnd(h).AddHook(Hook);window.Dispatcher.BeginInvoke(new Action(()=>Clamp()));};
   window.Closing+=(s,e)=>{
    if(closing)return;closing=true;if(animation!=null)animation.Stop();if(poller!=null)poller.Stop();SavePosition();
    if(!test){e.Cancel=true;window.Hide();Task.Factory.StartNew(()=>{try{Request("/api/pet/control",new {id=Guid.NewGuid().ToString("N"),action="mic_off",payload=new {}});}catch{}
      finally{window.Dispatcher.BeginInvoke(new Action(()=>window.Close()));}});}
   };
   window.Left=SystemParameters.WorkArea.Right-window.Width-24;window.Top=SystemParameters.WorkArea.Bottom-window.Height-20;
   LoadPosition();Clamp();anchorLeft=window.Left;anchorTop=window.Top;
   animation=new DispatcherTimer{Interval=TimeSpan.FromMilliseconds(60)};animation.Tick+=(s,e)=>Animate();animation.Start();
   poller=new DispatcherTimer{Interval=TimeSpan.FromMilliseconds(650)};poller.Tick+=(s,e)=>Poll();
   var before=GetForegroundWindow();
   window.ContentRendered+=(s,e)=>{GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();if(test){var timer=new DispatcherTimer{Interval=TimeSpan.FromMilliseconds(500)};timer.Tick+=(a,b)=>{timer.Stop();SelfTest(before);};timer.Start();}else{poller.Start();Poll();}};
   var app=new Application();app.Run(window);
  }
  BitmapSource LoadAtlas(){
   var sprite=Path.Combine(root,"assets/pet/spritesheet.webp");
   if(!File.Exists(sprite))return DrawFallbackAtlas();
   // Detach from the WebP decoder pipeline once: cropped animation frames then
   // share one immutable BGRA atlas, allowing codec/compile scratch to collect.
   var decoder=BitmapDecoder.Create(new Uri(sprite),BitmapCreateOptions.PreservePixelFormat,BitmapCacheOption.OnLoad);
   var source=new FormatConvertedBitmap(decoder.Frames[0],PixelFormats.Bgra32,null,0);
   int stride=source.PixelWidth*4;var pixels=new byte[stride*source.PixelHeight];source.CopyPixels(pixels,stride,0);
   var bitmap=BitmapSource.Create(source.PixelWidth,source.PixelHeight,96,96,PixelFormats.Bgra32,null,pixels,stride);bitmap.Freeze();return bitmap;
  }
  BitmapSource DrawFallbackAtlas(){
   // Original, code-drawn mascot for packages that cannot redistribute Sprig.
   const int width=1536,height=2288;
   var green=new SolidColorBrush(Color.FromRgb(158,217,173));green.Freeze();
   var belly=new SolidColorBrush(Color.FromRgb(220,244,215));belly.Freeze();
   var dark=new SolidColorBrush(Color.FromRgb(55,105,83));dark.Freeze();
   var cheek=new SolidColorBrush(Color.FromRgb(242,174,166));cheek.Freeze();
   var outline=new Pen(dark,3);outline.Freeze();
   var mouth=new Pen(dark,2.5);mouth.Freeze();
   var visual=new DrawingVisual();
   using(var dc=visual.RenderOpen()){
    for(int r=0;r<11;r++)for(int c=0;c<8;c++){
     double x=c*192+96+Math.Sin((r+c)*.7)*4,y=r*208+108+Math.Sin(c*1.1)*5;
     dc.DrawEllipse(green,outline,new Point(x+35,y+41),39,18);
     dc.DrawEllipse(green,outline,new Point(x,y+11),49,58);
     dc.DrawEllipse(belly,null,new Point(x,y+35),29,34);
     dc.DrawEllipse(dark,null,new Point(x-17,y-9),5,6);
     dc.DrawEllipse(dark,null,new Point(x+17,y-9),5,6);
     dc.DrawEllipse(cheek,null,new Point(x-26,y+3),8,5);
     dc.DrawEllipse(cheek,null,new Point(x+26,y+3),8,5);
     var smile=new StreamGeometry();
     using(var pen=smile.Open()){
      pen.BeginFigure(new Point(x-9,y+8),false,false);
      pen.BezierTo(new Point(x-4,y+19),new Point(x+5,y+19),new Point(x+10,y+8),true,false);
     }
     smile.Freeze();dc.DrawGeometry(null,mouth,smile);
    }
   }
   var image=new RenderTargetBitmap(width,height,96,96,PixelFormats.Pbgra32);
   image.Render(visual);image.Freeze();return image;
  }
  void AddMenu(ContextMenu menu,string title,Action action){var item=new MenuItem{Header=title};item.Click+=(s,e)=>action();menu.Items.Add(item);}
  void ShowError(string error){lastError=error.Length>160?error.Substring(0,160):error;errorUntil=DateTime.Now.AddSeconds(6);status.Text=lastError;thought.Visibility=Visibility.Visible;SetRow(5);}
  void Control(string action) {
   if(test&&!fixture){testActions.Add(action);return;}
   var id=Guid.NewGuid().ToString("N");var payload=new Dictionary<string,object>{{"epoch",epoch}};
   if(action=="cancel_current"&&lastJob.Length>0)payload["job_id"]=lastJob;
   if(test&&fixture){testActions.Add(action);Request("/api/pet/control",new{id=id,action=action,payload=payload});return;}
   Task.Factory.StartNew(()=>{
    try{Request("/api/pet/control",new {id=id,action=action,payload=payload});}
    catch(Exception e){window.Dispatcher.BeginInvoke(new Action(()=>ShowError("Chưa gửi được: "+e.Message)));}
   });
  }
  void Poll() {
   if(closing||Interlocked.CompareExchange(ref pollBusy,1,0)!=0)return;
   Task.Factory.StartNew(()=>{
    try{
     if(token.Length==0)token=Text(Obj(Request("/config",null)),"csrf_token");
     var snapshot=Obj(Request("/api/pet/state",null));
     window.Dispatcher.BeginInvoke(new Action(()=>{if(!closing)Update(snapshot);}));
    }catch(WebException e){token="";window.Dispatcher.BeginInvoke(new Action(()=>{if(!closing)ShowError("Mất kết nối Javis — chưa thể nghe. "+e.Message);}));}
    catch(Exception e){window.Dispatcher.BeginInvoke(new Action(()=>{if(!closing)ShowError("Kết nối lỗi: "+e.Message);}));}
    finally{Interlocked.Exchange(ref pollBusy,0);}
   });
  }
  void Update(Dictionary<string,object> value) {
   wantsMic=Flag(value,"wants_mic");soundOn=Flag(value,"sound_enabled");epoch=Text(value,"epoch");
   var currentPhase=Text(value,"phase");
   sendNow.IsEnabled=wantsMic&&(currentPhase=="task"||currentPhase=="busy-task"||currentPhase=="finalizing")&&Text(value,"request").Trim().Length>0;
   mic.Content=wantsMic?"Tắt mic":"Bật mic";sound.Content=soundOn?"♪":"×♪";
   var job=Obj(value.ContainsKey("job")?value["job"]:null);var jobState=Text(job,"state");
   bool busy=jobState=="queued"||jobState=="running"||jobState=="cancelling";
   lastJob=busy?Text(job,"id"):"";
   cancel.IsEnabled=busy||Flag(value,"dialogue_pending")||(wantsMic&&(Text(value,"phase")=="task"||Text(value,"phase")=="finalizing"||Text(value,"phase")=="tone"||Text(value,"phase")=="answer"));
   if(Text(value,"control_error").Length>0){ShowError(Text(value,"control_error"));return;}
   if(!Flag(value,"listener_connected")){status.Text="Trang giọng nói chưa kết nối";heard.Text="Bấm Chi tiết để mở hoặc cho phép mic.";SetPhase("waiting");return;}
   if(DateTime.Now<errorUntil)return;
   phase=Text(value,"phase");SetPhase(phase);status.Text=Text(value,"status");
   bool reading=phase=="speaking";status.FontSize=reading?13:16;status.MaxHeight=reading?20:44;
   heard.FontSize=reading?11:12;heard.MaxHeight=reading?60:35;
   heard.Text=busy&&Text(job,"current_step").Length>0?Text(job,"current_step"):Text(value,"heard");if(heard.Text.Length==0)heard.Text=busy?Text(job,"text"):wantsMic?"Gọi Bảo Bối hoặc Hi Javis, chờ Yes rồi nói nhiệm vụ.":"Bật mic khi muốn gọi Javis.";
   thought.Visibility=compact&&phase!="done"&&phase!="error"&&phase!="tone"&&phase!="speaking"&&phase!="answer"&&!Flag(value,"dialogue_pending")?Visibility.Hidden:Visibility.Visible;
   activity.Opacity=Flag(value,"listening")?1:.35;
  }
  void SetPhase(string name){if(dragging)return;SetRow(name=="done"?4:name=="tone"||name=="speaking"?3:name=="executing"?7:name=="error"?5:name=="wake"||name=="task"||name=="finalizing"||name=="waiting"||name=="answer"?6:0);}
  void SetRow(int value){if(row==value&&frame!=null)return;row=value;column=0;nextFrame=DateTime.MinValue;DrawFrame();}
  void DrawFrame(){frame=new CroppedBitmap(atlas,new Int32Rect(column*192,row*208,192,208));frame.Freeze();pet.Source=frame;}
  void Animate(){
   if(!reduced&&DateTime.Now>=nextFrame){column=(column+1)%Counts[row];DrawFrame();nextFrame=DateTime.Now.AddMilliseconds(column==Counts[row]-1?280:BaseDurations[row]);}
   if(walking&&!dragging&&!reduced&&!toolbar.IsMouseOver&&!pet.IsMouseOver){
    window.Left+=walkDirection*1.2;if(Math.Abs(window.Left-anchorLeft)>45)walkDirection=-walkDirection;SetRow(walkDirection<0?2:1);Clamp();
   }
  }
  void Clamp(){
   var source=PresentationSource.FromVisual(window);
   System.Drawing.Point point;
   if(source!=null){var physical=window.PointToScreen(new Point(window.Width/2,window.Height/2));point=new System.Drawing.Point((int)physical.X,(int)physical.Y);}
   else{double scale=System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width/SystemParameters.WorkArea.Width;point=ToPhysicalCenter(window.Left,window.Top,window.Width,window.Height,scale,scale);}
   var area=System.Windows.Forms.Screen.FromPoint(point).WorkingArea;
   Point a,b;
   if(source!=null){var localA=window.PointFromScreen(new Point(area.Left,area.Top));var localB=window.PointFromScreen(new Point(area.Right,area.Bottom));a=new Point(window.Left+localA.X,window.Top+localA.Y);b=new Point(window.Left+localB.X,window.Top+localB.Y);}
   else{double scale=System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width/SystemParameters.WorkArea.Width;a=new Point(area.Left/scale,area.Top/scale);b=new Point(area.Right/scale,area.Bottom/scale);}
   window.Left=Math.Max(a.X,Math.Min(window.Left,b.X-window.Width));window.Top=Math.Max(a.Y,Math.Min(window.Top,b.Y-window.Height));
  }
  public static System.Drawing.Point ToPhysicalCenter(double left,double top,double width,double height,double scaleX,double scaleY){return new System.Drawing.Point((int)((left+width/2)*scaleX),(int)((top+height/2)*scaleY));}
  void LoadPosition(){if(test)return;try{var v=Obj(json.DeserializeObject(File.ReadAllText(settingsPath)));double x=Convert.ToDouble(v["left"]),y=Convert.ToDouble(v["top"]);
    if(!Double.IsNaN(x)&&!Double.IsInfinity(x)&&!Double.IsNaN(y)&&!Double.IsInfinity(y)){window.Left=x;window.Top=y;}
    compact=Flag(v,"compact");walking=Flag(v,"walking");reduced=Flag(v,"reduced");}catch{}}
  void SavePosition(){if(test)return;try{Directory.CreateDirectory(Path.GetDirectoryName(settingsPath));File.WriteAllText(settingsPath,json.Serialize(new{left=window.Left,top=window.Top,compact=compact,walking=walking,reduced=reduced}),Encoding.UTF8);}catch{}}
  bool Inside(FrameworkElement element,Point point){if(element.Visibility!=Visibility.Visible)return false;var p=element.TranslatePoint(new Point(),window);return new Rect(p,element.RenderSize).Contains(point);}
  public bool IsInteractive(Point point){
   if(Inside(thought,point)||Inside(toolbar,point))return true;
   if(!Inside(pet,point)||frame==null)return false;
   var p=pet.TranslatePoint(new Point(),window);int x=(int)((point.X-p.X)*192/pet.ActualWidth),y=(int)((point.Y-p.Y)*208/pet.ActualHeight);
   if(x<0||y<0||x>=192||y>=208)return false;
   byte[] pixel=new byte[4];frame.CopyPixels(new Int32Rect(x,y,1,1),pixel,4,0);return pixel[3]>8;
  }
  IntPtr Hook(IntPtr h,int message,IntPtr w,IntPtr l,ref bool handled){
   if(message==0x21){handled=true;return new IntPtr(3);}
   if(message==0x84){long pos=l.ToInt64();var screen=new Point((short)(pos&65535),(short)((pos>>16)&65535));
    if(!IsInteractive(window.PointFromScreen(screen))){handled=true;return new IntPtr(-1);}}
   if(message==0x2E0||message==0x7E)window.Dispatcher.BeginInvoke(new Action(()=>Clamp()));
   return IntPtr.Zero;
  }
  void SaveRecipe(){
   if(test)return;
   if(lastJob.Length>0){ShowError("Chờ nhiệm vụ kết thúc trước khi lưu cách làm.");return;}
   var dialog=new Window{Title="Lưu cách làm",Width=380,Height=175,ResizeMode=ResizeMode.NoResize,Owner=window,Topmost=true,WindowStartupLocation=WindowStartupLocation.CenterOwner};
   var stack=new StackPanel{Margin=new Thickness(16)};var input=new TextBox{Margin=new Thickness(0,8,0,10),MaxLength=100};
   stack.Children.Add(new TextBlock{Text="Đặt tên để gọi lại cách làm vừa thành công:"});stack.Children.Add(input);
   var save=new Button{Content="Lưu cách làm",Padding=new Thickness(8,5,8,5)};stack.Children.Add(save);dialog.Content=stack;
   save.Click+=(s,e)=>{if(input.Text.Trim().Length==0)return;dialog.DialogResult=true;};dialog.Loaded+=(s,e)=>input.Focus();
   if(dialog.ShowDialog()!=true)return;
   var name=input.Text.Trim();Task.Factory.StartNew(()=>{try{Request("/api/recipes/save",new{name=name});window.Dispatcher.BeginInvoke(new Action(()=>{status.Text="Đã lưu cách làm: "+name;errorUntil=DateTime.Now.AddSeconds(4);thought.Visibility=Visibility.Visible;SetRow(4);}));}
    catch(Exception e){window.Dispatcher.BeginInvoke(new Action(()=>ShowError("Chưa lưu: "+e.Message)));}});
  }
  void SelfTest(IntPtr before){
   try{
    if(fixture){token=Text(Obj(Request("/config",null)),"csrf_token");Update(Obj(Request("/api/pet/state",null)));if(lastJob.Length==0)throw new Exception("Fixture must have a real owned worker running");}
    var hwnd=new WindowInteropHelper(window).Handle;int style=GetStyle(hwnd,-20);
    if((style&0x80000)==0||(style&8)==0||(style&0x08000000)==0)throw new Exception("Missing transparent/topmost/nonactivate styles");
    if(IsInteractive(new Point(0,0)))throw new Exception("Transparent corner must click through");
    if(!IsInteractive(toolbar.TranslatePoint(new Point(8,8),window)))throw new Exception("Toolbar must accept clicks");
    SetRow(1);if(row!=1)throw new Exception("Right movement animation missing");SetRow(2);if(row!=2)throw new Exception("Left movement animation missing");
    mic.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));Control("cancel_current");if(testActions.Count!=2)throw new Exception("Controls missing");
    SetRow(0);status.Text="Đang lắng nghe…";heard.Text="Hi Javis, mở bộ công việc hằng ngày";window.UpdateLayout();
    var image=new RenderTargetBitmap((int)window.Width,(int)window.Height,96,96,PixelFormats.Pbgra32);image.Render((Visual)window.Content);
    var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(image));using(var stream=File.Create(Path.Combine(root,"state/pet-native-check.png")))encoder.Save(stream);
    if(GetForegroundWindow()!=before)throw new Exception("Pet stole keyboard focus");
    Console.WriteLine(json.Serialize(new{passed=true,transparent=true,pinned=true,focus_kept=true,controls=testActions.ToArray(),atlas_width=atlas.PixelWidth,atlas_height=atlas.PixelHeight}));
   }catch(Exception e){Console.Error.WriteLine(e.ToString());Environment.ExitCode=1;}
   finally{window.Close();}
  }
 }
}
