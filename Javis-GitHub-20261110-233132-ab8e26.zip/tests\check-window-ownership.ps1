$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
Add-Type -Path (Join-Path $root 'tools\jarvis_windows.cs')
Add-Type -AssemblyName System.Windows.Forms
$guard=New-Object JarvisWindowGuard(-1800,70,800,500,([string[]]@('powershell')),'WindowsForms10.Window',([uint32[]]@()))
$form=New-Object System.Windows.Forms.Form
try {
    $form.Text='Jarvis temporary ownership test'
    $form.StartPosition='Manual'
    $form.SetBounds(400,200,400,250)
    $form.Show()
    $until=(Get-Date).AddMilliseconds(250)
    while((Get-Date) -lt $until) { [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 20 }
    $before=[JarvisWindowGuard]::Bounds($form.Handle)
    if($before[0] -ne 400) { throw 'Unapproved process window was moved' }
    $guard.AllowProcess([uint32]$PID)
    $until=(Get-Date).AddSeconds(2)
    while((Get-Date) -lt $until) { [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 20 }
    $after=[JarvisWindowGuard]::Bounds($form.Handle)
    if($after[0] -ne -1800 -or $after[1] -ne 70) { throw 'Owned process window was not positioned' }
    'PASS: unapproved process is left untouched; explicitly owned process is managed.'
} finally { $guard.Dispose(); $form.Dispose() }
