import json
from pathlib import Path
import tempfile
import unittest
from fast_actions import FastActionCatalog
from desktop_tasks import DesktopRouter


class FastActionsTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.opened=[];self.done=[]
        class OS:
            def screens_off(inner):self.done.append('screens_off');return True
            def lock(inner):self.done.append('lock');return True
            def screenshot(inner):self.done.append('screenshot');return str(self.root/'state/screenshots/test.png')
        self.catalog=FastActionCatalog(self.root,open_url=lambda url:self.opened.append(url) or {'current_url':url,'target_id':'A'*32,'visibility_verified':True},os_ops=OS())
    def tearDown(self):self.temp.cleanup()
    def test_missing_urls_ask_instead_of_opening_or_calling_model(self):
        value=self.catalog.run('mở nhạc yêu thích')
        self.assertEqual(value.outcome,'needs_input');self.assertEqual(self.opened,[])
        self.assertIsNone(self.catalog.run('mở nhạc yêu thích rồi xóa file'))
    def test_saved_urls_aliases_survive_restart_and_are_exact(self):
        value=self.catalog.list_actions();self.assertEqual(value['version'],1)
        for action in value['actions']:
            if action['id']=='favorites':action.update(url='https://www.youtube.com/playlist?list=PL123',aliases=['mở nhạc yêu thích','favorite songs'])
            if action['id']=='today':action['url']='http://localhost:47131/'
        self.catalog.save(value)
        again=FastActionCatalog(self.root,open_url=lambda url:self.opened.append(url) or {'current_url':url,'visibility_verified':True},os_ops=self.catalog.os_ops)
        self.assertEqual(again.run('favorite songs').outcome,'success')
        self.assertEqual(again.run('mở công việc hôm nay').outcome,'success')
        self.assertEqual(self.opened,['https://www.youtube.com/playlist?list=PL123','http://localhost:47131/'])
        self.assertIsNone(again.run('favorite song'))
    def test_youtube_watch_link_with_playlist_is_saved_and_preserves_start_video(self):
        url='https://www.youtube.com/watch?v=ExampleVid1&list=PLexample001&index=1'
        config=self.catalog.list_actions();config['actions'][0]['url']=url
        self.catalog.save(config)
        again=FastActionCatalog(self.root,open_url=lambda target:self.opened.append(target) or {'current_url':target,'visibility_verified':True},os_ops=self.catalog.os_ops)
        self.assertEqual(again.run('mở nhạc yêu thích').outcome,'success')
        self.assertEqual(self.opened,[url])
        for bad in ('https://www.youtube.com/watch?v=ExampleVid1',
                    'http://www.youtube.com/watch?v=x&list=PL123',
                    'https://evil.example/watch?v=x&list=PL123'):
            config['actions'][0]['url']=bad
            with self.subTest(url=bad),self.assertRaises(ValueError):self.catalog.save(config)
    def test_added_web_shortcut_and_editable_system_aliases_remain_typed(self):
        config=self.catalog.list_actions()
        config['actions'].append({'id':'project-docs','type':'web','name':'Project Docs','aliases':['open project docs'],'url':'https://docs.example.com/start'})
        next(a for a in config['actions'] if a['id']=='screenshot')['aliases'].append('save screen')
        next(a for a in config['actions'] if a['id']=='lock')['aliases'].append('lock my computer')
        self.catalog.save(config)
        again=FastActionCatalog(self.root,open_url=lambda url:self.opened.append(url) or {'current_url':url,'visibility_verified':True},os_ops=self.catalog.os_ops)
        self.assertEqual(again.run('open project docs').outcome,'success')
        self.assertEqual(again.run('save screen').outcome,'success')
        self.assertEqual(again.run('lock my computer').outcome,'success')
        self.assertEqual(self.opened,['https://docs.example.com/start'])
        self.assertEqual(self.done,['screenshot','lock'])
        self.assertEqual(again.run_id('screenshot').outcome,'success')
        self.assertEqual(self.done[-1],'screenshot')
        with self.assertRaises(ValueError):again.run_id('unknown-action')
        for bad in ('javascript:alert(1)','file:///C:/secret','http://evil.example/','https://user:pass@example.com/'):
            config['actions'][-1]['url']=bad
            with self.subTest(url=bad),self.assertRaises(ValueError):self.catalog.save(config)
    def test_invalid_url_reserved_alias_and_raw_command_rejected(self):
        config=self.catalog.list_actions();playlist=config['actions'][0]
        for url in ('https://example.com/playlist?list=PL123','http://example.com/','https://user:pass@www.youtube.com/playlist?list=PL123'):
            playlist['url']=url
            with self.assertRaises(ValueError):self.catalog.save(config)
        playlist['url']=None;playlist['aliases']=['Cancel']
        with self.assertRaises(ValueError):self.catalog.save(config)
        playlist['aliases']=['favorite songs'];playlist['command']='powershell.exe'
        with self.assertRaises(ValueError):self.catalog.save(config)
    def test_system_actions_are_typed_and_do_not_require_browser(self):
        for text,name in [('tắt màn hình','screens_off'),('khóa màn hình','lock'),('chụp ảnh màn hình','screenshot')]:
            result=self.catalog.run(text)
            self.assertEqual(result.outcome,'success');self.assertEqual(self.done[-1],name)
        self.assertEqual(self.opened,[])
    def test_desktop_router_prefers_fast_alias_before_model(self):
        router=DesktopRouter(self.root,fast_actions=self.catalog)
        self.assertEqual(router.run('tắt màn hình').outcome,'success')
        self.assertEqual(self.done,['screens_off'])
