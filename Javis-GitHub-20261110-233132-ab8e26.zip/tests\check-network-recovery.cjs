const assert=require('node:assert/strict');
const {setup,flush}=require('./check-webspeech-ui.cjs');

(async()=>{
  let app=setup({nativePet:true});await flush();await app.node('start').onclick();
  for(const delay of [1000,2000,4000]){
    app.instances.at(-1).onerror({error:'network'});await flush();
    assert.equal(app.state.phase,'reconnecting','wake network error should keep mic intent');
    assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);
    const count=app.instances.length;await app.advance(delay-1);assert.equal(app.instances.length,count);
    await app.advance(1);assert.equal(app.instances.length,count+1);
  }
  app.instances.at(-1).onerror({error:'network'});await flush();
  assert.equal(app.state.phase,'error','repeated network errors should stop retrying');
  app.stop();
  app=setup({nativePet:true});await flush();await app.node('start').onclick();
  app.instances.at(-1).final('Hey Javis');await flush();assert.equal(app.state.phase,'task');
  app.instances.at(-1).onerror({error:'network'});await flush();
  assert.equal(app.state.phase,'error','a task capture must not silently restart after network failure');
  assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);
  console.log('PASS: bounded wake reconnect, no task replay after network error.');
})().catch(error=>{console.error(error);process.exitCode=1;});
