"""One local audio owner; fixed clips, bounded deduplication, interruptible."""
from collections import OrderedDict
from pathlib import Path
import threading
import wave
import array
import math
import tempfile


class AudioService:
    def __init__(self,root,player=None):
        self.root=Path(root);self.player=player or self._windows_play
        self.lock=threading.RLock();self.seen=OrderedDict();self.cancelled=OrderedDict();self.active=None
    @staticmethod
    def _windows_play(path,event):
        import winsound
        with wave.open(str(path),'rb') as wav:duration=wav.getnframes()/wav.getframerate()
        winsound.PlaySound(str(path),winsound.SND_FILENAME|winsound.SND_ASYNC|winsound.SND_NODEFAULT)
        event.wait(min(duration+.1,5))
        winsound.PlaySound(None,0)
    def play(self,cue_id,clip,generation,gain=1):
        if type(gain) not in (int,float) or not math.isfinite(gain) or not 0<=gain<=1:raise ValueError('Invalid cue gain')
        if clip not in ('yes','done') or not isinstance(cue_id,str) or not 1<=len(cue_id)<=140 or not isinstance(generation,str) or len(generation)>120:raise ValueError('Invalid audio cue')
        with self.lock:
            if cue_id in self.seen or generation in self.cancelled:return False
            if self.active:raise ValueError('Audio is busy')
            self.seen[cue_id]=True
            while len(self.seen)>200:self.seen.popitem(last=False)
            event=threading.Event();self.active=(generation,event)
        temporary=None
        try:
            path=self.root/'webspeech-probe'/f'{clip}.wav'
            if gain!=1:
                with wave.open(str(path),'rb') as wav:
                    params=wav.getparams();samples=array.array('h',wav.readframes(wav.getnframes()))
                if params.sampwidth!=2:raise ValueError('Cue must use 16-bit PCM')
                samples=array.array('h',(round(v*gain) for v in samples))
                folder=self.root/'state/audio-temp';folder.mkdir(parents=True,exist_ok=True)
                with tempfile.NamedTemporaryFile(dir=folder,suffix='.wav',delete=False) as stream:temporary=Path(stream.name)
                with wave.open(str(temporary),'wb') as wav:wav.setparams(params);wav.writeframes(samples.tobytes())
                path=temporary
            self.player(path,event)
            return not event.is_set()
        finally:
            if temporary:temporary.unlink(missing_ok=True)
            with self.lock:self.active=None
    def stop(self,generation=None):
        with self.lock:
            if generation is not None:
                self.cancelled[generation]=True
                while len(self.cancelled)>200:self.cancelled.popitem(last=False)
            if self.active and (generation is None or self.active[0]==generation):self.active[1].set()
