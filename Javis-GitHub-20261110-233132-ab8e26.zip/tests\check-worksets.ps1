$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
$tool=Join-Path $root 'tools/Open-Workset.ps1'
if(-not(Test-Path -LiteralPath $tool)){throw 'Workset opening is not implemented.'}
. (Join-Path $root 'tools/Chrome-Cdp.ps1')
Add-Type -Path (Join-Path $root 'tools/jarvis_windows.cs')
$anchor=[JarvisWindowGuard]::Foreground()
$fixtureDir=Join-Path $root ('state/workset-test-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $fixtureDir|Out-Null
$configPath=Join-Path $fixtureDir 'workspaces.json'
$id='test-'+[guid]::NewGuid().ToString('N').Substring(0,12)
@{version=1;default=$id;workspaces=@(@{id=$id;name='Fixture';enabled=$true;tabs=@(
    @{id='one';name='One';url='about:blank'},@{id='two';name='Two';url='about:blank'})})}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $configPath -Encoding UTF8
$owned=@();$client=$null
try {
    $first=& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $tool -WorkspaceId $id -ConfigPath $configPath
    if($LASTEXITCODE -ne 0){throw 'First workset launch failed.'}
    $first=$first|ConvertFrom-Json
    $owned=@($first.tabs|ForEach-Object {$_.target_id})
    if(-not $first.focus_kept){throw 'Initial launch stole foreground focus.'}
    if($owned.Count -ne 2 -or @($owned|Select-Object -Unique).Count -ne 2){throw 'Expected two distinct owned targets.'}
    if(@($first.tabs|Where-Object state -ne opened).Count){throw 'Blank tabs did not open successfully.'}
    if(-not $first.placement_verified){throw 'Secondary monitor placement not verified.'}
    $endpoint=Get-JarvisChromeEndpoint $root
    $client=Connect-JarvisCdp $endpoint.webSocketDebuggerUrl
    $before=@((Invoke-JarvisCdp $client 'Target.getTargets' @{}).targetInfos|Where-Object type -eq page)
    $roles=Get-Content -LiteralPath (Join-Path $root 'state/webspeech-live-browser.json') -Raw|ConvertFrom-Json
    $voice=$before|Where-Object targetId -eq $roles.voice_target
    if(-not $voice){throw 'Voice target missing before test.'}
    $voiceWindow=(Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$voice.targetId}).windowId
    foreach($targetId in $owned){
        if((Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$targetId}).windowId -eq $voiceWindow){throw 'Workset entered voice window.'}
    }
    $attached=(Invoke-JarvisCdp $client 'Target.attachToTarget' @{targetId=$owned[0];flatten=$true}).sessionId
    [void](Invoke-JarvisCdp $client 'Runtime.evaluate' @{expression='window.javisPreserved = "draft survives"';returnByValue=$true} $attached)
    for($iteration=0;$iteration -lt 10;$iteration++){
        $again=& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $tool -WorkspaceId $id -ConfigPath $configPath
        if($LASTEXITCODE -ne 0){throw 'Workset reuse failed.'}
        $again=$again|ConvertFrom-Json
        if(-not $again.focus_kept){throw "Reuse $iteration changed foreground focus: $($again|ConvertTo-Json -Depth 6 -Compress)"}
        if(($again.tabs.target_id -join ',') -ne ($owned -join ',')){throw 'Reopening replaced an existing target.'}
        if(@($again.tabs|Where-Object state -ne reused).Count){throw 'Existing tabs were not reused.'}
    }
    $after=@((Invoke-JarvisCdp $client 'Target.getTargets' @{}).targetInfos|Where-Object type -eq page)
    if($after.Count -ne $before.Count){throw 'Reopening created extra tabs.'}
    $workWindow=Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$owned[0]}
    # Migration: old saved worksets have no native window identity yet.
    $statePath=Join-Path $root 'state/worksets.json'
    $saved=Get-Content -LiteralPath $statePath -Raw|ConvertFrom-Json
    foreach($row in $saved.tabs|Where-Object workspace_id -eq $id){
        $row.PSObject.Properties.Remove('hwnd');$row.PSObject.Properties.Remove('window_id')
    }
    $saved|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $statePath -Encoding UTF8
    [void](Invoke-JarvisCdp $client 'Browser.setWindowBounds' @{windowId=$workWindow.windowId;bounds=@{windowState='minimized'}})
    $restored=& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $tool -WorkspaceId $id -ConfigPath $configPath
    if($LASTEXITCODE -ne 0){throw 'Minimized workset restore failed.'}
    $restored=$restored|ConvertFrom-Json
    if(-not $restored.focus_kept){throw 'Legacy minimized restoration stole foreground focus.'}
    if(-not $restored.placement_verified -or -not $restored.visibility_verified){throw 'Reopening left the workset minimized or hidden.'}
    if((Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$owned[0]}).bounds.windowState -eq 'minimized'){throw 'Work window is still minimized.'}
    $draft=Invoke-JarvisCdp $client 'Runtime.evaluate' @{expression='window.javisPreserved';returnByValue=$true} $attached
    if($draft.result.value -ne 'draft survives'){throw 'Reopening reloaded the existing tab and lost its contents.'}
    [void](Invoke-JarvisCdp $client 'Target.detachFromTarget' @{sessionId=$attached})
    $browserState=Join-Path $root 'state/browser.json'
    @{target_id=$owned[0];endpoint=$endpoint.http}|ConvertTo-Json|Set-Content -LiteralPath $browserState -Encoding UTF8
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'tools/Open-Chrome.ps1') -Inspect|Out-Null
    if($LASTEXITCODE -ne 0){throw 'Default browser helper failed.'}
    $default=(Get-Content -LiteralPath $browserState -Raw|ConvertFrom-Json).target_id
    if($default -in $owned){throw 'Default navigation can take over a workspace tab.'}
    # Simulate interruption after Chrome creates a marker but before ownership/navigation is committed.
    $statePath=Join-Path $root 'state/worksets.json'
    $saved=Get-Content -LiteralPath $statePath -Raw|ConvertFrom-Json
    $pending=$saved.tabs|Where-Object {$_.workspace_id -eq $id -and $_.id -eq 'one'}|Select-Object -First 1
    $session=(Invoke-JarvisCdp $client 'Target.attachToTarget' @{targetId=$owned[0];flatten=$true}).sessionId
    [void](Invoke-JarvisCdp $client 'Page.navigate' @{url=$pending.marker} $session)
    [void](Invoke-JarvisCdp $client 'Target.detachFromTarget' @{sessionId=$session})
    $pending.target_id=$null
    $saved|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $statePath -Encoding UTF8
    @{target_id='missing';endpoint=$endpoint.http}|ConvertTo-Json|Set-Content -LiteralPath $browserState -Encoding UTF8
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'tools/Open-Chrome.ps1') -Inspect|Out-Null
    $default=(Get-Content -LiteralPath $browserState -Raw|ConvertFrom-Json).target_id
    if($default -in $owned){throw 'Default navigation adopted a pending workset marker.'}
    $recovered=& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $tool -WorkspaceId $id -ConfigPath $configPath
    if($LASTEXITCODE -ne 0){throw 'Pending-tab recovery failed.'}
    $recovered=$recovered|ConvertFrom-Json
    if($recovered.tabs[0].target_id -ne $owned[0] -or $recovered.tabs[0].current_url -ne 'about:blank'){
        throw 'Pending marker was not recovered and navigated in the same tab.'
    }
    [void](Invoke-JarvisCdp $client 'Target.closeTarget' @{targetId=$owned[1]})
    # Legacy window A remains alive while a missing tab creates same-sized B.
    $saved=Get-Content -LiteralPath $statePath -Raw|ConvertFrom-Json
    foreach($row in $saved.tabs|Where-Object workspace_id -eq $id){
        $row.PSObject.Properties.Remove('hwnd');$row.PSObject.Properties.Remove('window_id')
    }
    $saved|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $statePath -Encoding UTF8
    $repaired=& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $tool -WorkspaceId $id -ConfigPath $configPath
    if($LASTEXITCODE -ne 0){throw 'Missing-tab repair failed.'}
    $repaired=$repaired|ConvertFrom-Json
    if(-not $repaired.focus_kept){throw 'Missing-tab repair stole foreground focus.'}
    $owned+=@($repaired.tabs|ForEach-Object {$_.target_id})
    if(-not $repaired.visibility_verified -or @($repaired.windows).Count -ne 2 -or @($repaired.windows.hwnd|Select-Object -Unique).Count -ne 2){throw 'Legacy and repaired windows were not identified/shown separately.'}
    if($repaired.tabs[0].target_id -ne $first.tabs[0].target_id -or $repaired.tabs[1].target_id -eq $first.tabs[1].target_id){throw 'Missing-tab repair changed the wrong target.'}
    $voiceAfter=(Invoke-JarvisCdp $client 'Target.getTargetInfo' @{targetId=$voice.targetId}).targetInfo
    if($voiceAfter.url -ne $voice.url){throw 'Voice listener was navigated away.'}
    if([JarvisWindowGuard]::Foreground() -ne $anchor){throw 'Workset operations stole foreground focus.'}
    'PASS: ten reopens, exact missing-tab repair, no duplicate tabs, voice isolation, secondary placement and foreground preservation.'
} finally {
    if($client){
        foreach($targetId in @($owned|Select-Object -Unique)){
            try{[void](Invoke-JarvisCdp $client 'Target.closeTarget' @{targetId=$targetId})}catch{}
        }
        $client.socket.Dispose()
    }
    # Keep the tiny fixture/state for diagnosis. No personal tabs are closed.
}
