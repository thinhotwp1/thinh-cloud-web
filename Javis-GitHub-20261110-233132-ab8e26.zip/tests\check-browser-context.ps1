param([string]$SourcePath)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
if(-not $SourcePath){$SourcePath=Join-Path $root 'tools/Open-Chrome.ps1'}
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($SourcePath,[ref]$tokens,[ref]$errors)
if($errors){throw ($errors|Out-String)}
$function=$ast.Find({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Save-BrowserObservation'},$true)
if(-not $function){throw 'Browser observations are not recorded.'}
. ([ScriptBlock]::Create($function.Extent.Text))
$fixture=Join-Path $root ('state/browser-context-test-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $fixture|Out-Null
$browserState=Join-Path $fixture 'browser.json'
$target=@{id='fixture-target'};$endpoint='http://127.0.0.1:12345';$VoicePage=$false
Save-BrowserObservation 'http://user:pass@localhost:47131/a?token=private#x' 'Dashboard token=private'
$saved=Get-Content $browserState -Raw -Encoding UTF8|ConvertFrom-Json
if($saved.current_url -ne 'http://localhost:47131/a' -or $saved.target_id -ne 'fixture-target' -or -not $saved.observed_at){throw 'Observed browser identity/context was not saved.'}
if((Get-Content $browserState -Raw) -match 'private|user:pass'){throw 'Browser context leaked URL/title credentials.'}
$before=[IO.File]::ReadAllText($browserState);$VoicePage=$true
Save-BrowserObservation 'http://127.0.0.1:8766/' 'Voice listener'
if([IO.File]::ReadAllText($browserState) -ne $before){throw 'Voice page replaced work context.'}
$VoicePage=$false;$browserState=Join-Path $fixture 'missing-directory/browser.json'
Save-BrowserObservation 'http://localhost:47131/' 'Dashboard'
'PASS: browser URL/title/target context saved, redacted, and isolated from voice page.'
