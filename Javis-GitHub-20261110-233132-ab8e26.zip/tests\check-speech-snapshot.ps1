# Explicit live HTTP integration. Synthetic speech/audio adapters exist ONLY in
# this temporary test target; no real mic, audio device or Codex request is used.
param([string]$FixtureUrl='http://127.0.0.1:8766/')
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
. (Join-Path $root 'tools/Chrome-Cdp.ps1')
Add-Type -Path (Join-Path $root 'tools/jarvis_windows.cs')
$config=Invoke-RestMethod ($FixtureUrl.TrimEnd('/')+'/config') -TimeoutSec 3
$current=Invoke-RestMethod ($FixtureUrl.TrimEnd('/')+'/api/state') -Headers @{'X-Jarvis-Token'=$config.csrf_token} -TimeoutSec 3
if($current.active){throw 'Do not run this integration while a user task is active.'}
if($config.wake_aliases -notcontains 'David'){throw 'Restart the owned broker to load the updated aliases first.'}
$endpoint=Get-JarvisChromeEndpoint $root
$client=Connect-JarvisCdp $endpoint.webSocketDebuggerUrl
$target='';$session='';$anchor=[JarvisWindowGuard]::Foreground()
function Evaluate-Snapshot([string]$Expression){
    $value=Invoke-JarvisCdp $client 'Runtime.evaluate' @{expression=$Expression;returnByValue=$true;awaitPromise=$true} $session
    if($value.exceptionDetails){throw ($value.exceptionDetails|ConvertTo-Json -Depth 6 -Compress)}
    return $value.result.value
}
try{
    $target=(Invoke-JarvisCdp $client 'Target.createTarget' @{url='about:blank';newWindow=$true;background=$true;focus=$false;left=-1800;top=80;width=800;height=700}).targetId
    $session=(Invoke-JarvisCdp $client 'Target.attachToTarget' @{targetId=$target;flatten=$true}).sessionId
    [void](Invoke-JarvisCdp $client 'Page.enable' @{} $session)
    $adapter=@'
try {
window.__testSpeech=[];
window.__spoken=[];
Object.defineProperty(window,'speechSynthesis',{value:{getVoices:()=>[{name:'Microsoft David fixture',lang:'en-US',localService:true}],addEventListener(){},cancel(){},speak(u){window.__spoken.push(u.text);queueMicrotask(()=>u.onend?.());}}});
window.SpeechSynthesisUtterance=class {constructor(text){this.text=text;}};
window.SpeechRecognition=class SnapshotTestSpeech {
  constructor(){window.__testSpeech.push(this);}
  start(){queueMicrotask(()=>this.onstart?.());}
  abort(){queueMicrotask(()=>this.onend?.());}
  stop(){queueMicrotask(()=>this.onend?.());}
};
window.AudioContext=class SnapshotTestAudio {
  constructor(){this.state='running';this.currentTime=0;this.destination={};}
  resume(){return Promise.resolve();}
  decodeAudioData(){return Promise.resolve({duration:.3});}
  createBufferSource(){const source={connect(){},disconnect(){},stop(){},start(){queueMicrotask(()=>source.onended?.());}};return source;}
  createGain(){return {gain:{setValueAtTime(){},linearRampToValueAtTime(){}},connect(){},disconnect(){}};}
  createOscillator(){return {frequency:{},connect(){},disconnect(){},start(){},stop(){queueMicrotask(()=>this.onended?.());}};}
};
navigator.mediaDevices.getUserMedia=async()=>({getAudioTracks:()=>[{label:'Synthetic test input; no hardware'}],getTracks:()=>[{stop(){}}]});
navigator.mediaDevices.getUserMedia.__syntheticSnapshotTest=true;
window.__snapshot=(items,index=0)=>{
  const speech=window.__testSpeech.at(-1);
  const results=items.map(([text,final])=>{const result=[{transcript:text}];result.isFinal=final;return result;});
  speech.onresult({resultIndex:index,results});
};
} catch (error) { window.__testAdapterError=String(error.stack); }
'@
    [void](Invoke-JarvisCdp $client 'Page.addScriptToEvaluateOnNewDocument' @{source=$adapter} $session)
    [void](Invoke-JarvisCdp $client 'Page.navigate' @{url=$FixtureUrl} $session)
    $deadline=(Get-Date).AddSeconds(6)
    do{
        Start-Sleep -Milliseconds 100
        try{$ready=Evaluate-Snapshot 'Boolean(window.jarvisProbeState?.live && typeof window.__snapshot === "function" && window.SpeechRecognition.name === "SnapshotTestSpeech" && window.AudioContext.name === "SnapshotTestAudio" && navigator.mediaDevices.getUserMedia.__syntheticSnapshotTest && !document.getElementById("start").disabled)'}catch{$ready=$false}
        if($ready){break}
    }while((Get-Date) -lt $deadline)
    if(-not $ready){throw ('Synthetic adapters were not verified; Start was not clicked: '+(Evaluate-Snapshot 'window.__testAdapterError || "adapter did not run"'))}
    [void](Evaluate-Snapshot 'document.title="Javis — synthetic result snapshot test"; document.getElementById("start").click(); true')
    Start-Sleep -Milliseconds 100
    [void](Evaluate-Snapshot 'window.__snapshot([["Hi David",true]]); true')
    $deadline=(Get-Date).AddSeconds(4)
    do{
        Start-Sleep -Milliseconds 100
        $phase=Evaluate-Snapshot 'window.jarvisProbeState.phase'
        if($phase -eq 'task'){break}
    }while((Get-Date) -lt $deadline)
    if($phase -ne 'task'){throw ('Hi David did not receive a real backend wake grant: '+(Evaluate-Snapshot 'JSON.stringify(window.jarvisProbeState)'))}
    [void](Evaluate-Snapshot 'window.__testSpeech.at(-1).onspeechstart(); window.__snapshot([["calculate 2 + 3 * 4",false],["temporary tail",false]]); window.__snapshot([["calculate 2 + 3 * 4",true]],0); window.__testSpeech.at(-1).onspeechend(); true')
    $deadline=(Get-Date).AddSeconds(16)
    do{
        Start-Sleep -Milliseconds 150
        $value=Evaluate-Snapshot 'JSON.stringify({job:window.jarvisProbeState.job,error:window.jarvisProbeState.error})'
        $result=$value|ConvertFrom-Json
        if($result.job.state -in @('completed','failed') -or $result.error){break}
    }while((Get-Date) -lt $deadline)
    if($result.error -or $result.job.state -ne 'completed' -or $result.job.executor -ne 'local' -or $result.job.reply -ne '14'){
        throw ('Snapshot integration failed: '+$value)
    }
    $deadline=(Get-Date).AddSeconds(3)
    do{Start-Sleep -Milliseconds 100;$spoken=Evaluate-Snapshot 'window.__spoken.includes("14") && !jobBusy'}while(-not $spoken -and (Get-Date) -lt $deadline)
    if(-not $spoken){throw 'Local calculation was not spoken as an answer.'}
    if(-not (Evaluate-Snapshot 'window.__spoken.includes("Yes")')){throw 'Selected-voice acknowledgement was not spoken.'}
    [void](Evaluate-Snapshot 'document.getElementById("manual-input").value="format json {\"a\":1}"; document.getElementById("manual-send").onclick().then(()=>true)')
    if([JarvisWindowGuard]::Foreground() -ne $anchor){throw 'Temporary test target changed foreground focus.'}
    'PASS: Hi David -> real one-use grant -> shrinking speech results -> configured silence -> real local execution -> reply 14; no mic/AI used.'
}finally{
    if($session){
        try{[void](Evaluate-Snapshot 'document.getElementById("stop")?.click(); true')}catch{}
        try{[void](Invoke-JarvisCdp $client 'Target.detachFromTarget' @{sessionId=$session})}catch{}
    }
    if($target){[void](Invoke-JarvisCdp $client 'Target.closeTarget' @{targetId=$target})}
    $client.socket.Dispose()
}
