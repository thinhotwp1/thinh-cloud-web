param([string]$OutputRoot,[switch]$IncludePetSprite)
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($PSScriptRoot)
if(-not $OutputRoot){$OutputRoot=Join-Path $root 'dist'}
$output=[IO.Path]::GetFullPath($OutputRoot)
[void][IO.Directory]::CreateDirectory($output)
$name='Javis-GitHub-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,6)
$package=Join-Path $output $name
[void][IO.Directory]::CreateDirectory($package)

function Copy-PackageFile([string]$Relative,[string]$As=$Relative){
    $source=Join-Path $root $Relative
    if(-not(Test-Path -LiteralPath $source -PathType Leaf)){throw "Required source file missing: $Relative"}
    $item=Get-Item -LiteralPath $source -Force
    if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw "Symlink/reparse source is not allowed: $Relative"}
    $target=Join-Path $package $As
    [void][IO.Directory]::CreateDirectory((Split-Path -Parent $target))
    Copy-Item -LiteralPath $source -Destination $target -ErrorAction Stop
}

$files=@(
    'README.md','.vscode/tasks.json','Jarvis.code-workspace',
    'Setup-Javis.ps1','Package-Javis.ps1',
    'packaging/.gitignore.public','packaging/AGENTS.public.md',
    'Start-Codex.ps1','Start-Pet.ps1','Start-Pet.cmd',
    'Start-Jarvis.cmd','Start-WebSpeech.ps1','Start-WebSpeech.cmd',
    'Open-Workspace.ps1','voice-config.example.json','workspaces.example.json',
    'audio_service.py','browser_completion.py','desktop_tasks.py','dialogue.py',
    'execution_result.py','fast_actions.py','memory_store.py','pet_hub.py',
    'process_control.py','recipe_memory.py','session_lock.py','voice_core.py',
    'web_bridge.py','work_memory.py','desktop/PetHost.cs','desktop/PetWindow.xaml',
    'webspeech-probe/app.js','webspeech-probe/index.html',
    'webspeech-probe/speech.js','webspeech-probe/style.css',
    'webspeech-probe/yes.wav','webspeech-probe/done.wav',
    'tools/Chrome-Cdp.ps1','tools/jarvis_windows.cs',
    'tools/Open-Chrome.ps1','tools/Open-Voice-Page.ps1',
    'tools/Open-Workset.ps1','tools/Reveal-WorkTarget.ps1',
    'tools/Show-VoiceDetails.ps1','tools/Show-WorkWindow.ps1',
    'tools/Take-Screenshot.ps1','tools/webspeech_live_server.py',
    'tools/build-completion-cue.py'
)
foreach($relative in $files){Copy-PackageFile $relative}
Copy-PackageFile 'packaging/.gitignore.public' '.gitignore'
Copy-PackageFile 'packaging/AGENTS.public.md' 'AGENTS.md'

$tests=Get-ChildItem -LiteralPath (Join-Path $root 'tests') -Recurse -File |
    Where-Object {$_.Extension -in @('.py','.ps1','.cjs','.js')}
foreach($item in $tests){
    $relative=$item.FullName.Substring($root.Length+1)
    Copy-PackageFile $relative
}
if($IncludePetSprite){
    Copy-PackageFile 'assets/pet/spritesheet.webp'
    Copy-PackageFile 'assets/pet/PROVENANCE.md'
    Copy-PackageFile 'assets/pet/pet.json'
}

foreach($item in Get-ChildItem -LiteralPath $package -Recurse -File){
    $relative=$item.FullName.Substring($package.Length+1).Replace('\','/')
    if($relative -match '^(state|\.venv|dist|tasks)/' -or $relative -in @('voice-config.json','workspaces.json','TASKS.md')){
        throw "Private file unexpectedly included: $relative"
    }
    if(-not $IncludePetSprite -and $relative -eq 'assets/pet/spritesheet.webp'){
        throw 'Private pet sprite unexpectedly included'
    }
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive=Join-Path $output ($name+'.zip')
[IO.Compression.ZipFile]::CreateFromDirectory($package,$archive,[IO.Compression.CompressionLevel]::Optimal,$false)
[pscustomobject]@{
    folder=$package
    zip=$archive
    files=(Get-ChildItem -LiteralPath $package -Recurse -File | Measure-Object).Count
    zip_bytes=(Get-Item -LiteralPath $archive).Length
    includes_pet_sprite=$IncludePetSprite.IsPresent
} | ConvertTo-Json -Compress
