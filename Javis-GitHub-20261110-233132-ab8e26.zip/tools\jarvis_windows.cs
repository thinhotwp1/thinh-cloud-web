using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

// Only windows absent from the launch snapshot are managed. Existing work stays put.
public sealed class JarvisWindowGuard : IDisposable {
    delegate bool EnumProc(IntPtr hwnd, IntPtr data);
    [StructLayout(LayoutKind.Sequential)] struct Rect { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] struct Point { public int X,Y; }
    [StructLayout(LayoutKind.Sequential)] struct Placement { public int Length,Flags,Show; public Point Min,Max; public Rect Normal; }
    [DllImport("user32.dll")] static extern bool GetWindowPlacement(IntPtr hwnd,ref Placement placement);
    [DllImport("user32.dll")] static extern bool SetWindowPlacement(IntPtr hwnd,ref Placement placement);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc fn, IntPtr data);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr hwnd);
    [DllImport("user32.dll")] static extern bool IsWindow(IntPtr hwnd);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr hwnd);
    [DllImport("user32.dll")] static extern bool IsZoomed(IntPtr hwnd);
    [DllImport("user32.dll", EntryPoint="GetWindowLongW")] static extern int GetWindowStyle(IntPtr hwnd, int index);
    [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr hwnd, uint cmd);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr hwnd, StringBuilder text, int size);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr hwnd, out Rect rect);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int w, int h, uint flags);
    [DllImport("user32.dll")] static extern bool ShowWindowAsync(IntPtr hwnd, int cmd);
    [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    readonly HashSet<IntPtr> before = new HashSet<IntPtr>();
    readonly HashSet<IntPtr> placed = new HashSet<IntPtr>();
    readonly HashSet<string> processNames;
    readonly ConcurrentDictionary<uint,bool> allowedProcesses = new ConcurrentDictionary<uint,bool>();
    readonly bool restrictProcesses;
    readonly string classPrefix;
    readonly int x, y, width, height;
    readonly Thread worker;
    readonly ConcurrentQueue<string> messages = new ConcurrentQueue<string>();
    volatile bool stopping;
    IntPtr anchor;
    public bool IsRunning { get { return worker.IsAlive; } }
    public IntPtr[] ManagedHandles() {
        var live = new List<IntPtr>();
        foreach(var h in placed) if(IsWindow(h) && IsWindowVisible(h)) live.Add(h);
        return live.ToArray();
    }
    public static IntPtr Foreground() { return GetForegroundWindow(); }
    public static IntPtr UsePhysicalCoordinates() { return SetThreadDpiAwarenessContext(new IntPtr(-4)); }
    public static void RestoreCoordinates(IntPtr previous) { if(previous!=IntPtr.Zero) SetThreadDpiAwarenessContext(previous); }
    public static bool NearBounds(int[] r,int x,int y,int w,int h) {
        // Chrome rounds DIP/physical conversions at mixed display scales.
        return Math.Abs(r[0]-x)<=2 && Math.Abs(r[1]-y)<=2 && Math.Abs(r[2]-w)<=2 && Math.Abs(r[3]-h)<=2;
    }
    public static int[] CdpBounds(IntPtr hwnd) {
        // CDP reports logical window coordinates. The caller can still use
        // physical coordinates for monitor placement across mixed DPI screens.
        IntPtr previous=SetThreadDpiAwarenessContext(new IntPtr(-1));
        try { return IsIconic(hwnd) ? RestoredBounds(hwnd) : Bounds(hwnd); }
        finally { if(previous!=IntPtr.Zero) SetThreadDpiAwarenessContext(previous); }
    }
    public static bool Pinned(IntPtr hwnd) { return (GetWindowStyle(hwnd,-20)&8)!=0; }
    public static int[] Bounds(IntPtr hwnd) {
        Rect r; GetWindowRect(hwnd, out r);
        return new int[] { r.Left, r.Top, r.Right-r.Left, r.Bottom-r.Top };
    }
    public static bool OwnedChromeWindow(IntPtr hwnd, uint[] pids) {
        if(!IsWindow(hwnd)) return false;
        uint pid; GetWindowThreadProcessId(hwnd,out pid);
        if(Array.IndexOf(pids,pid)<0) return false;
        var name=new StringBuilder(256); GetClassName(hwnd,name,256);
        return name.ToString().StartsWith("Chrome_WidgetWin_",StringComparison.Ordinal);
    }
    public static IntPtr FindChromeWindow(uint[] pids, int x, int y, int w, int h) {
        IntPtr found=IntPtr.Zero; int count=0;
        EnumWindows((window,p) => {
            if(!OwnedChromeWindow(window,pids) || Pinned(window)) return true;
            var r=Bounds(window);
            if(r[0]==x && r[1]==y && r[2]==w && r[3]==h) {found=window; count++;}
            return true;
        },IntPtr.Zero);
        return count==1 ? found : IntPtr.Zero;
    }
    public static IntPtr[] ChromeWindows(uint[] pids) {
        var found=new List<IntPtr>();
        EnumWindows((h,p)=>{if(OwnedChromeWindow(h,pids) && IsWindowVisible(h) && !Pinned(h) && GetWindow(h,4)==IntPtr.Zero) found.Add(h); return true;},IntPtr.Zero);
        return found.ToArray();
    }
    public static bool Minimized(IntPtr hwnd) { return IsIconic(hwnd); }
    public static bool Maximized(IntPtr hwnd) { return IsZoomed(hwnd); }
    public static int[] RestoredBounds(IntPtr hwnd) {
        var p=new Placement();p.Length=Marshal.SizeOf(p);
        if(!GetWindowPlacement(hwnd,ref p)) return Bounds(hwnd);
        return new int[]{p.Normal.Left,p.Normal.Top,p.Normal.Right-p.Normal.Left,p.Normal.Bottom-p.Normal.Top};
    }
    // Change only geometry, including a minimized window's restore rectangle.
    // SW_SHOWMINNOACTIVE keeps an iconic window minimized without activation.
    public static bool MarkGeometry(IntPtr hwnd,int x,int y,int w,int h) {
        if(Pinned(hwnd)) return false;
        if(!IsIconic(hwnd)) return SetWindowPos(hwnd,IntPtr.Zero,x,y,w,h,0x0010|0x0004);
        var p=new Placement();p.Length=Marshal.SizeOf(p);
        if(!GetWindowPlacement(hwnd,ref p)) return false;
        p.Show=7;p.Normal=new Rect{Left=x,Top=y,Right=x+w,Bottom=y+h};
        return SetWindowPlacement(hwnd,ref p);
    }
    public static bool RevealWorkWindow(IntPtr hwnd,uint[] pids,int x,int y,int w,int h) {
        if(!OwnedChromeWindow(hwnd,pids) || Pinned(hwnd)) return false;
        if(IsIconic(hwnd)) {
            var p=new Placement();p.Length=Marshal.SizeOf(p);
            if(GetWindowPlacement(hwnd,ref p)) {
                p.Flags &= ~2; // Clear WPF_RESTORETOMAXIMIZED before normal restore.
                p.Show=7;SetWindowPlacement(hwnd,ref p);
            }
        }
        ShowWindowAsync(hwnd,4); // Restore/show without activating or changing the foreground.
        for(int i=0;i<25 && (IsIconic(hwnd) || IsZoomed(hwnd));i++) Thread.Sleep(20);
        bool placed=false;int[] r=Bounds(hwnd);
        for(int i=0;i<10;i++) {
            placed=SetWindowPos(hwnd,IntPtr.Zero,x,y,w,h,0x0010|0x0040);
            r=Bounds(hwnd);
            if(r[0]==x && r[1]==y && r[2]==w && r[3]==h) break;
            Thread.Sleep(30); // Allow WM_DPICHANGED before final physical placement.
        }
        return placed && IsWindowVisible(hwnd) && !IsIconic(hwnd) && r[0]==x && r[1]==y && r[2]==w && r[3]==h;
    }
    public static IntPtr[] RevealChrome(uint[] pids) {
        var allowed = new HashSet<uint>(pids);
        var result = new List<IntPtr>();
        EnumWindows((h,p) => {
            uint pid; GetWindowThreadProcessId(h,out pid);
            if(!allowed.Contains(pid) || GetWindow(h,4)!=IntPtr.Zero || Pinned(h)) return true;
            var text=new StringBuilder(256); GetClassName(h,text,256);
            if(!text.ToString().StartsWith("Chrome_WidgetWin_",StringComparison.Ordinal)) return true;
            if(!IsWindowVisible(h)) return true;
            ShowWindowAsync(h,4);
            SetWindowPos(h,IntPtr.Zero,0,0,0,0,0x0001|0x0002|0x0010|0x0040);
            result.Add(h);
            return true;
        },IntPtr.Zero);
        return result.ToArray();
    }
    public JarvisWindowGuard(int x, int y, int width, int height, string[] names, string prefix)
        : this(x,y,width,height,names,prefix,null) { }
    public JarvisWindowGuard(int x, int y, int width, int height, string[] names, string prefix, uint[] allowedPids) {
        this.x=x; this.y=y; this.width=width; this.height=height;
        classPrefix=prefix; processNames=new HashSet<string>(names, StringComparer.OrdinalIgnoreCase);
        restrictProcesses=allowedPids!=null;
        if(allowedPids!=null) foreach(uint pid in allowedPids) allowedProcesses[pid]=true;
        anchor=GetForegroundWindow();
        EnumWindows((h,p) => { before.Add(h); return true; }, IntPtr.Zero);
        worker=new Thread(Watch); worker.IsBackground=true; worker.Start();
    }
    public void AllowProcess(uint pid) { allowedProcesses[pid]=true; }
    bool IsTarget(IntPtr h) {
        if (before.Contains(h) || GetWindow(h,4)!=IntPtr.Zero || Pinned(h)) return false;
        var text=new StringBuilder(256); GetClassName(h,text,256);
        if (!text.ToString().StartsWith(classPrefix, StringComparison.Ordinal)) return false;
        uint pid; GetWindowThreadProcessId(h,out pid);
        if(restrictProcesses && !allowedProcesses.ContainsKey(pid)) return false;
        try { using(var p=Process.GetProcessById((int)pid)) return processNames.Contains(p.ProcessName); }
        catch { return false; }
    }
    void Watch() {
        IntPtr dpi=SetThreadDpiAwarenessContext(new IntPtr(-4));
        var elapsed=Stopwatch.StartNew();
        try {
            while(!stopping && elapsed.Elapsed.TotalSeconds < 20) {
                EnumWindows((h,p) => {
                    if(!IsTarget(h)) return true;
                    bool first=placed.Add(h);
                    if(IsIconic(h) || IsZoomed(h)) ShowWindowAsync(h,4); // SW_SHOWNOACTIVATE
                    Rect r; GetWindowRect(h,out r);
                    if(first || r.Left!=x || r.Top!=y || r.Right-r.Left!=width || r.Bottom-r.Top!=height) {
                        // Raise within the current band without activating the window.
                        bool ok=SetWindowPos(h,IntPtr.Zero,x,y,width,height,0x0010|0x0040|0x0200|0x4000);
                        if(first) messages.Enqueue("PLACED hwnd="+h+" at "+x+","+y+" size="+width+"x"+height+" requested="+ok);
                    }
                    return true;
                },IntPtr.Zero);
                IntPtr current=GetForegroundWindow();
                if(placed.Contains(current)) {
                    if(anchor!=IntPtr.Zero && IsWindow(anchor) && current!=anchor) {
                        bool ok=SetForegroundWindow(anchor);
                        if(ok) messages.Enqueue("FOCUS RESTORED hwnd="+anchor);
                    }
                } else if(current!=IntPtr.Zero) {
                    // Follow voluntary switches to other existing apps during launch.
                    anchor=current;
                }
                Thread.Sleep(20);
            }
        } catch(Exception e) { messages.Enqueue("WINDOW GUARD ERROR: "+e.Message); }
        finally { if(dpi!=IntPtr.Zero) SetThreadDpiAwarenessContext(dpi); }
    }
    public string[] Drain() {
        var result=new List<string>(); string s;
        while(messages.TryDequeue(out s)) result.Add(s);
        return result.ToArray();
    }
    public void Dispose() { stopping=true; worker.Join(2000); }
}
