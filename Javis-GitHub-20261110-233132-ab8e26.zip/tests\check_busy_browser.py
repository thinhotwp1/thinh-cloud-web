"""Real Chrome and HTTP with fake worker; verifies busy-voice replacement end to end."""
from contextlib import nullcontext
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'tools')]
from web_bridge import VoiceBridge
from webspeech_live_server import make_server
from process_control import TaskCancelled

with tempfile.TemporaryDirectory() as folder:
    fixture=Path(folder);(fixture/'state').mkdir();(fixture/'webspeech-probe').mkdir();(fixture/'desktop').mkdir()
    (fixture/'desktop/PetHost.cs').write_text('// Native feature fixture')
    shutil.copy2(ROOT/'voice-config.json',fixture/'voice-config.json')
    for name in ('index.html','app.js','speech.js','style.css','yes.wav','done.wav'):shutil.copy2(ROOT/'webspeech-probe'/name,fixture/'webspeech-probe'/name)
    calls=[];released=threading.Event();current=[0];maximum=[0]
    class Runner:
        def __init__(self,on_event):pass
        def run(self,text):
            current[0]+=1;maximum[0]=max(maximum[0],current[0]);calls.append(text)
            try:
                if text.startswith('investigate old work'):
                    released.wait(15);raise TaskCancelled('old worker stopped')
                return json.dumps(dict(version=2,outcome='success',reply='New task complete.',response_kind='action',spoken_reply='',steps=[dict(label='New task',state='success',evidence='verified')]))
            finally:current[0]-=1
        def cancel(self):released.set();return True
    bridge=VoiceBridge(fixture,aliases=json.loads((fixture/'voice-config.json').read_text(encoding='utf-8-sig'))['wake_aliases'],runner_factory=Runner,mutex_factory=nullcontext)
    server=make_server(fixture,0,bridge);server.audio.player=lambda path,event:None
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'tests/check-dialogue-browser.ps1'),'-FixtureUrl',f'http://127.0.0.1:{server.server_port}/','-BusyMode','-WakeText','Hey Bảo Bói'],capture_output=True,encoding='utf-8-sig',errors='replace',timeout=45)
        print(result.stdout.strip());assert result.returncode==0,result.stderr
        assert len(calls)==2 and maximum[0]==1,(calls,maximum)
        old_ids=[identifier for identifier,job in bridge.jobs.items() if job['text'].startswith('investigate old work')]
        assert len(old_ids)==1 and bridge.status(old_ids[0])['outcome']=='cancelled'
        assert bridge.active is None and bridge.pending_id is None
        print('PASS: exact two fake-agent turns, max one active worker, no paid model or real mic.')
    finally:released.set();bridge.close();server.shutdown();server.server_close();thread.join()
