param([Parameter(Mandatory=$true)][string]$FixtureUrl,[Parameter(Mandatory=$true)][string]$GuardRoot)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
. (Join-Path $root 'tools/Chrome-Cdp.ps1')
$endpoint=Get-JarvisChromeEndpoint $root
$client=Connect-JarvisCdp $endpoint.webSocketDebuggerUrl
$target='';$session='';$generalTarget=''
function Evaluate([string]$Expression,[bool]$Gesture=$false){
    $reply=Invoke-JarvisCdp $client 'Runtime.evaluate' @{expression=$Expression;returnByValue=$true;awaitPromise=$true;userGesture=$Gesture} $session
    if($reply.exceptionDetails){throw ($reply.exceptionDetails|ConvertTo-Json -Depth 8 -Compress)}
    return $reply.result.value
}
try{
    $target=(Invoke-JarvisCdp $client 'Target.createTarget' @{url='about:blank';newWindow=$true;background=$true;focus=$false;left=-1800;top=100;width=540;height=400}).targetId
    $session=(Invoke-JarvisCdp $client 'Target.attachToTarget' @{targetId=$target;flatten=$true}).sessionId
    [void](Invoke-JarvisCdp $client 'Page.enable' @{} $session)
    [void](Invoke-JarvisCdp $client 'Page.navigate' @{url=$FixtureUrl} $session)
    $deadline=(Get-Date).AddSeconds(6)
    do{
        Start-Sleep -Milliseconds 100
        try{$ready=Evaluate 'Boolean(window.jarvisProbeState?.live && typeof cancelCurrent === "function")'}catch{$ready=$false}
        if($ready){break}
    }while((Get-Date) -lt $deadline)
    if(-not $ready){throw 'Fixture UI did not initialize.'}
    $size=Evaluate 'JSON.stringify({compact:document.body.dataset.compact,hidden:getComputedStyle(document.getElementById("expanded-content")).display,scroll:document.getElementById("mini-panel").scrollWidth,width:document.getElementById("mini-panel").clientWidth})'|ConvertFrom-Json
    if($size.compact -ne 'true' -or $size.hidden -ne 'none' -or $size.scroll -gt $size.width){throw 'Compact panel is not usable at the small width.'}
    [void](Evaluate 'document.getElementById("manual-input").value="BLOCK"; document.getElementById("manual-send").click(); true')
    $deadline=(Get-Date).AddSeconds(5)
    do{
        Start-Sleep -Milliseconds 100
        $job=Evaluate 'JSON.stringify(window.jarvisProbeState.job)'|ConvertFrom-Json
        if($job.state -eq 'running' -and $job.executor -eq 'codex'){break}
    }while((Get-Date) -lt $deadline)
    if($job.state -ne 'running'){throw 'Owned fake CLI did not start.'}
    $hasPip=Evaluate 'Boolean(window.documentPictureInPicture?.requestWindow)'
    if($hasPip){
        [void](Evaluate 'openFloating().then(()=>true)' $true)
        Start-Sleep -Milliseconds 500
        [void](Evaluate 'floatingWindow.document.getElementById("pip-toggle").click(); true' $true)
        Start-Sleep -Milliseconds 500
        $panel=Evaluate 'JSON.stringify({open:Boolean(floatingWindow&&!floatingWindow.closed),cancelEnabled:floatingWindow&&!floatingWindow.closed&&!floatingWindow.document.getElementById("mini-cancel").disabled,width:floatingWindow?.innerWidth,height:floatingWindow?.innerHeight,outerWidth:floatingWindow?.outerWidth,outerHeight:floatingWindow?.outerHeight,parentWidth:innerWidth,overflow:floatingWindow&&floatingWindow.document.body.scrollWidth>floatingWindow.innerWidth})'|ConvertFrom-Json
        $panel|ConvertTo-Json -Compress
        if(-not $panel.open -or -not $panel.cancelEnabled -or $panel.overflow){throw 'Floating controls did not bind to the active job.'}
        if($panel.width -gt 500 -or $panel.height -gt 350){throw 'Floating controls opened too large for a corner panel.'}
        $pipTarget=(Invoke-JarvisCdp $client 'Target.getTargets' @{}).targetInfos|Where-Object {$_.openerId -eq $target -and $_.type -eq 'page'}|Select-Object -First 1
        if(-not $pipTarget){throw 'Floating target could not be identified.'}
        try{
            $imageSession=(Invoke-JarvisCdp $client 'Target.attachToTarget' @{targetId=$pipTarget.targetId;flatten=$true}).sessionId
            [void](Invoke-JarvisCdp $client 'Page.enable' @{} $imageSession)
            Start-Sleep -Milliseconds 150
            $shot=Invoke-JarvisCdp $client 'Page.captureScreenshot' @{format='png';captureBeyondViewport=$false;clip=@{x=0;y=0;width=360;height=205;scale=1}} $imageSession
            [IO.File]::WriteAllBytes((Join-Path $root 'state/compact-panel-check.png'),[Convert]::FromBase64String($shot.data))
            [void](Invoke-JarvisCdp $client 'Target.detachFromTarget' @{sessionId=$imageSession})
        }catch{Write-Verbose 'PiP screenshot not available; DOM layout checks still apply.'}
        $generalTarget=(Invoke-JarvisCdp $client 'Target.createTarget' @{url='about:blank';newWindow=$true;background=$true;focus=$false}).targetId
        New-Item -ItemType Directory -Path (Join-Path $GuardRoot 'state/chrome-profile') -Force|Out-Null
        New-Item -ItemType Directory -Path (Join-Path $GuardRoot 'tools') -Force|Out-Null
        foreach($name in @('Open-Chrome.ps1','Open-Voice-Page.ps1','Chrome-Cdp.ps1','jarvis_windows.cs','Show-WorkWindow.ps1')){
            Copy-Item -LiteralPath (Join-Path $root ('tools/'+$name)) -Destination (Join-Path $GuardRoot ('tools/'+$name))
        }
        Copy-Item -LiteralPath (Join-Path $root 'state/chrome-profile/DevToolsActivePort') -Destination (Join-Path $GuardRoot 'state/chrome-profile/DevToolsActivePort')
        @{voice_target=$target;work_target=$pipTarget.targetId}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $GuardRoot 'state/webspeech-live-browser.json') -Encoding UTF8
        @{target_id=$pipTarget.targetId;endpoint=$endpoint.http}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $GuardRoot 'state/browser.json') -Encoding UTF8
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $GuardRoot 'tools/Open-Chrome.ps1') -Inspect -NoReveal|Out-Null
        if($LASTEXITCODE -ne 0){throw 'Browser ownership check failed.'}
        $selected=(Get-Content -LiteralPath (Join-Path $GuardRoot 'state/browser.json') -Raw|ConvertFrom-Json).target_id
        if($selected -eq $pipTarget.targetId){throw 'Browser helper can take over the floating controls as a work tab.'}
        $beforeCancel=Evaluate 'JSON.stringify({disabled:floatingWindow.document.getElementById("mini-cancel").disabled,handler:typeof floatingWindow.document.getElementById("mini-cancel").onclick,busy:jobBusy,cancelPending,phase:window.jarvisProbeState.phase})'
        Write-Output ('Before cancel '+$beforeCancel)
        [void](Evaluate 'floatingWindow.document.getElementById("mini-cancel").click(); true' $true)
    }else{
        [void](Evaluate 'document.getElementById("mini-cancel").click(); true')
    }
    $deadline=(Get-Date).AddSeconds(8)
    do{
        Start-Sleep -Milliseconds 150
        $state=Evaluate 'JSON.stringify({job:window.jarvisProbeState.job,busy:jobBusy,canStart:!document.getElementById("mini-mic").disabled,listening:window.jarvisProbeState.listening,cancelPending,error:window.jarvisProbeState.error,status:document.getElementById("status").textContent})'|ConvertFrom-Json
        if($state.job.state -eq 'cancelled' -and -not $state.busy){break}
    }while((Get-Date) -lt $deadline)
    if($state.job.state -ne 'cancelled' -or -not $state.canStart -or $state.listening){throw ('Cancellation did not stop the worker and preserve the paused microphone: '+($state|ConvertTo-Json -Depth 8 -Compress))}
    # Inspect how Chrome exposes the PiP document to protect browser-helper ownership.
    $targets=(Invoke-JarvisCdp $client 'Target.getTargets' @{}).targetInfos
    $targets|Where-Object {$_.targetId -eq $target -or ($_.openerId -eq $target)}|Select-Object type,url,title|ConvertTo-Json -Depth 4
    if($hasPip){[void](Evaluate 'floatingWindow.close(); true')}
    'PASS: real compact layout, floating controls (when supported), actual fake-CLI cancellation, worker exit and mic remains off.'
}finally{
    if($session){try{[void](Evaluate 'if(floatingWindow&&!floatingWindow.closed)floatingWindow.close(); document.getElementById("stop").click(); true')}catch{}}
    if($target){[void](Invoke-JarvisCdp $client 'Target.closeTarget' @{targetId=$target})}
    if($generalTarget){[void](Invoke-JarvisCdp $client 'Target.closeTarget' @{targetId=$generalTarget})}
    $client.socket.Dispose()
}
