"""Source-labelled work facts. No page scraping, background sync or model calls."""
from datetime import datetime,timezone,timedelta
import json
import re
import sqlite3
import time
import uuid
from urllib.parse import urlsplit

from desktop_tasks import normalized
from execution_result import ExecutionResult,clean


class WorkMemory:
    def __init__(self,memory,clock=time.time,local_tz=None):
        self.memory=memory
        self.clock=clock
        self.local_tz=local_tz or datetime.now().astimezone().tzinfo
        self._last_pruned_at=0
        with memory.connection() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS work_items(source TEXT NOT NULL,item_id TEXT NOT NULL,title TEXT NOT NULL,status TEXT NOT NULL,observed_at REAL NOT NULL,source_ref TEXT NOT NULL,PRIMARY KEY(source,item_id));
                CREATE TABLE IF NOT EXISTS work_snapshots(source TEXT NOT NULL,item_id TEXT NOT NULL,observed_at REAL NOT NULL,status TEXT NOT NULL,reason TEXT NOT NULL,source_ref TEXT NOT NULL,PRIMARY KEY(source,item_id,observed_at),FOREIGN KEY(source,item_id) REFERENCES work_items(source,item_id) ON DELETE CASCADE);
                CREATE TABLE IF NOT EXISTS work_goals(id TEXT PRIMARY KEY,name TEXT NOT NULL,criteria TEXT NOT NULL,source TEXT NOT NULL,item_id TEXT,created_at REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS work_decisions(id TEXT PRIMARY KEY,source TEXT NOT NULL,item_id TEXT NOT NULL,note TEXT NOT NULL,origin TEXT NOT NULL,created_at REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS work_source_sync(source TEXT PRIMARY KEY,last_seen REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS work_source_policy(source TEXT PRIMARY KEY,allow_ai INTEGER NOT NULL,changed_at REAL NOT NULL);
                CREATE INDEX IF NOT EXISTS work_snapshots_recent ON work_snapshots(source,item_id,observed_at DESC);
            ''')
            try:db.execute('CREATE VIRTUAL TABLE IF NOT EXISTS work_fts USING fts5(source UNINDEXED,item_id UNINDEXED,title)')
            except sqlite3.OperationalError:self.fts=False
            else:self.fts=True
        self.prune()
    def prune(self,now=None):
        now=self.clock() if now is None else now
        cutoff=now-90*86400
        with self.memory.connection() as db:
            old=[row[0] for row in db.execute('SELECT rowid FROM work_items WHERE observed_at<?',(cutoff,))]
            if self.fts:
                for rowid in old:db.execute('DELETE FROM work_fts WHERE rowid=?',(rowid,))
            db.execute('DELETE FROM work_items WHERE observed_at<?',(cutoff,))
            db.execute('DELETE FROM work_snapshots WHERE observed_at<?',(cutoff,))
            db.execute('DELETE FROM work_decisions WHERE created_at<?',(cutoff,))
            db.execute('DELETE FROM work_goals WHERE created_at<?',(cutoff,))
            db.execute('DELETE FROM work_source_sync WHERE last_seen<?',(cutoff,))
            db.execute('DELETE FROM work_source_policy WHERE changed_at<?',(cutoff,))
        self._last_pruned_at=now
    def _maybe_prune(self):
        if self.clock()-self._last_pruned_at>=86400:self.prune()
    def ai_allowed(self,source):
        self._maybe_prune()
        with self.memory.connection() as db:
            row=db.execute('SELECT allow_ai FROM work_source_policy WHERE source=?',(source,)).fetchone()
        return bool(row and row[0])
    def set_ai_permission(self,source,allowed):
        if not isinstance(source,str) or not re.fullmatch('[a-z][a-z0-9-]{0,63}',source) or type(allowed) is not bool:
            raise ValueError('A valid source and explicit true/false permission are required')
        self._maybe_prune()
        with self.memory.connection() as db:
            db.execute('INSERT INTO work_source_policy VALUES(?,?,?) ON CONFLICT(source) DO UPDATE SET allow_ai=excluded.allow_ai,changed_at=excluded.changed_at',
                       (source,int(allowed),self.clock()))
        return {'source':source,'allow_ai':allowed}
    @staticmethod
    def _time(value):
        if not isinstance(value,str):raise ValueError('Observation needs a timestamp')
        try:dt=datetime.fromisoformat(value.replace('Z','+00:00'))
        except ValueError as error:raise ValueError('Invalid observation time') from error
        if not dt.tzinfo:raise ValueError('Observation timezone is required')
        return dt.timestamp()
    @staticmethod
    def _source_ref(value):
        if not isinstance(value,str) or len(value)>2048:raise ValueError('Valid source URL required')
        url=urlsplit(value)
        if url.scheme not in ('http','https') or not url.hostname or url.username or url.password:raise ValueError('Only HTTP(S) source links without credentials are allowed')
        try:port=url.port
        except ValueError as error:raise ValueError('Invalid source URL port') from error
        if url.hostname in ('localhost','127.0.0.1','::1') and port in (8765,8766):
            raise ValueError('The Javis voice page is not a work-data source')
        return clean(value,2048)
    def import_items(self,source,records):
        if not isinstance(source,str) or not re.fullmatch('[a-z][a-z0-9-]{0,63}',source):raise ValueError('Invalid source ID')
        if not isinstance(records,list) or not 1<=len(records)<=50 or len(json.dumps(records,ensure_ascii=False).encode())>64000:raise ValueError('Import must contain 1-50 bounded records')
        values=[]
        for row in records:
            if not isinstance(row,dict) or set(row)-{'item_id','title','status','observed_at','source_ref','reason'}:raise ValueError('Invalid work fields')
            identifier=row.get('item_id');title=row.get('title');status=row.get('status')
            if not isinstance(identifier,str) or not re.fullmatch('[A-Za-z0-9][A-Za-z0-9._-]{0,63}',identifier):raise ValueError('Invalid work ID')
            if not isinstance(title,str) or not 1<=len(title.strip())<=180 or not isinstance(status,str) or not 1<=len(status.strip())<=48:raise ValueError('Invalid title/status')
            reason=row.get('reason','')
            if not isinstance(reason,str) or len(reason)>500:raise ValueError('Reason too long')
            values.append((source,identifier,title.strip(),status.strip(),self._time(row.get('observed_at')),self._source_ref(row.get('source_ref')),clean(reason,500)))
        with self.memory.connection() as db:
            for source,identifier,title,status,observed,ref,reason in values:
                existing=db.execute('SELECT observed_at FROM work_items WHERE source=? AND item_id=?',(source,identifier)).fetchone()
                if not existing:db.execute('INSERT INTO work_items VALUES(?,?,?,?,?,?)',(source,identifier,title,status,observed,ref))
                elif observed>=existing[0]:db.execute('UPDATE work_items SET title=?,status=?,observed_at=?,source_ref=? WHERE source=? AND item_id=?',(title,status,observed,ref,source,identifier))
                db.execute('INSERT OR REPLACE INTO work_snapshots VALUES(?,?,?,?,?,?)',(source,identifier,observed,status,reason,ref))
                if self.fts:
                    rowid=db.execute('SELECT rowid FROM work_items WHERE source=? AND item_id=?',(source,identifier)).fetchone()[0]
                    db.execute('DELETE FROM work_fts WHERE rowid=?',(rowid,))
                    db.execute('INSERT INTO work_fts(rowid,source,item_id,title) VALUES(?,?,?,?)',(rowid,source,identifier,title))
            db.execute('INSERT INTO work_source_sync VALUES(?,?) ON CONFLICT(source) DO UPDATE SET last_seen=excluded.last_seen',(source,max(v[4] for v in values)))
        self.prune()
        return {'source':source,'imported':len(values)}
    def save_goal(self,name,criteria,source,item_id=None):
        self._maybe_prune()
        if not isinstance(name,str) or not 1<=len(name.strip())<=180 or not isinstance(criteria,str) or not 1<=len(criteria.strip())<=500 or source not in ('user','dashboard'):
            raise ValueError('Explicit bounded goal required')
        identifier=uuid.uuid4().hex;created=self.clock()
        with self.memory.connection() as db:db.execute('INSERT INTO work_goals VALUES(?,?,?,?,?,?)',(identifier,clean(name,180),clean(criteria,500),source,item_id,created))
        return {'id':identifier,'name':name.strip(),'criteria':criteria.strip()}
    def get_goal(self,identifier):
        self._maybe_prune()
        with self.memory.connection() as db:row=db.execute('SELECT name,criteria,source,item_id FROM work_goals WHERE id=?',(identifier,)).fetchone()
        if not row:raise ValueError('Goal not found')
        return dict(id=identifier,name=row[0],criteria=row[1],source=row[2],item_id=row[3])
    def list_goals(self):
        self._maybe_prune()
        with self.memory.connection() as db:rows=db.execute('SELECT id,name,criteria,source,item_id FROM work_goals ORDER BY created_at DESC LIMIT 25').fetchall()
        return [dict(id=r[0],name=r[1],criteria=r[2],source=r[3],item_id=r[4]) for r in rows]
    def delete_goal(self,identifier):
        self._maybe_prune()
        with self.memory.connection() as db:
            if db.execute('DELETE FROM work_goals WHERE id=?',(identifier,)).rowcount!=1:raise ValueError('Goal not found')
    def save_decision(self,source,item_id,note,origin):
        self._maybe_prune()
        if not isinstance(source,str) or not re.fullmatch('[a-z][a-z0-9-]{0,63}',source) or not isinstance(item_id,str) or not re.fullmatch('[A-Za-z0-9][A-Za-z0-9._-]{0,63}',item_id) or not isinstance(note,str) or not 1<=len(note.strip())<=500 or origin not in ('user','dashboard'):
            raise ValueError('Explicit bounded decision required')
        identifier=uuid.uuid4().hex
        with self.memory.connection() as db:db.execute('INSERT INTO work_decisions VALUES(?,?,?,?,?,?)',(identifier,source,item_id,clean(note,500),origin,self.clock()))
        return {'id':identifier,'source':source,'item_id':item_id}
    def delete_decision(self,identifier):
        self._maybe_prune()
        with self.memory.connection() as db:
            if db.execute('DELETE FROM work_decisions WHERE id=?',(identifier,)).rowcount!=1:raise ValueError('Decision not found')
    def list_decisions(self,source,item_id):
        self._maybe_prune()
        with self.memory.connection() as db:rows=db.execute('SELECT id,note,origin,created_at FROM work_decisions WHERE source=? AND item_id=? ORDER BY created_at DESC LIMIT 25',(source,item_id)).fetchall()
        return [dict(id=r[0],note=r[1],origin=r[2],created_at=datetime.fromtimestamp(r[3],timezone.utc).isoformat()) for r in rows]
    @staticmethod
    def _subject(text):
        value=normalized(text)
        match=re.search(r'\b(?:viec|task)\s+([a-z0-9._-]+)',value)
        return match[1] if match and match[1] not in {'chua','dang','hom','nay','nhieu','nao','unfinished','pending','status','progress'} else None
    def _day_window(self,text):
        value=normalized(text)
        if not any(word in value for word in ('hom qua','yesterday')):return None
        today=datetime.fromtimestamp(self.clock(),self.local_tz).date()
        start=datetime.combine(today-timedelta(days=1),datetime.min.time(),self.local_tz)
        return start.timestamp(),(start+timedelta(days=1)).timestamp()
    def _matches(self,text):
        self._maybe_prune()
        subject=self._subject(text)
        window=self._day_window(text)
        with self.memory.connection() as db:
            if subject:
                rows=db.execute('SELECT source,item_id,title,status,observed_at,source_ref FROM work_items WHERE lower(item_id)=? OR lower(title)=? LIMIT 6',(subject,subject)).fetchall()
                if not rows and self.fts:
                    ids=[r[0] for r in db.execute('SELECT rowid FROM work_fts WHERE work_fts MATCH ? LIMIT 6',('"'+subject.replace('"','""')+'"',))]
                    rows=[r for identifier in ids for r in db.execute('SELECT source,item_id,title,status,observed_at,source_ref FROM work_items WHERE rowid=?',(identifier,))]
            else:
                rows=db.execute('SELECT source,item_id,title,status,observed_at,source_ref FROM work_items ORDER BY observed_at DESC LIMIT 100').fetchall()
                value=normalized(text)
                if any(token in value for token in ('chua xong','chua hoan thanh','unfinished','pending','blocked')):
                    rows=[row for row in rows if normalized(row[3]) not in {'done','complete','completed','closed','resolved','finished','xong','hoan thanh'}]
                rows=rows[:6]
            if window:
                dated=[]
                for source,identifier,title,*_ in rows:
                    snapshot=db.execute('SELECT status,observed_at,source_ref FROM work_snapshots WHERE source=? AND item_id=? AND observed_at>=? AND observed_at<? ORDER BY observed_at DESC LIMIT 1',
                                        (source,identifier,*window)).fetchone()
                    if snapshot:dated.append((source,identifier,title,*snapshot))
                rows=dated
        return rows
    def evidence(self,text):
        if not any(v in normalized(text) for v in ('tai sao','vi sao','why')):return []
        rows=self._matches(text);subject=self._subject(text)
        if subject and len(rows)!=1:return []
        evidence=[]
        with self.memory.connection() as db:
            for source,identifier,title,status,observed,ref in rows[:5]:
                history=db.execute('SELECT status,reason,observed_at,source_ref FROM work_snapshots WHERE source=? AND item_id=? AND observed_at<=? ORDER BY observed_at DESC LIMIT 2',(source,identifier,observed)).fetchall()
                cutoff=self._day_window(text)
                note=db.execute('SELECT note,created_at FROM work_decisions WHERE source=? AND item_id=? AND created_at<? ORDER BY created_at DESC LIMIT 1',
                                (source,identifier,cutoff[1] if cutoff else self.clock()+1)).fetchone()
                reason=history[0][1] if history else ''
                if not reason and not note:continue
                record=dict(source=source,item_id=identifier,title=title,status=status,observed_at=datetime.fromtimestamp(observed,timezone.utc).isoformat(),source_ref=ref,reason=reason,previous_status=history[1][0] if len(history)>1 else None)
                if reason:
                    record['reason_observed_at']=datetime.fromtimestamp(history[0][2],timezone.utc).isoformat()
                    record['reason_status']=history[0][0]
                if note:
                    record['decision']=note[0]
                    record['decision_recorded_at']=datetime.fromtimestamp(note[1],timezone.utc).isoformat()
                evidence.append(record)
        return evidence
    def answer(self,text):
        self._maybe_prune()
        value=normalized(text);subject=self._subject(text)
        wants_why=any(v in value for v in ('tai sao','vi sao','why'))
        wants_status=bool(subject and any(v in value for v in ('toi dau','den dau','status','progress','chua xong','chua hoan thanh')))
        if not wants_why and not wants_status and 'muc tieu ban dau' not in value:return None
        if 'muc tieu ban dau' in value:
            with self.memory.connection() as db:row=db.execute('SELECT name,criteria FROM work_goals ORDER BY created_at DESC LIMIT 1').fetchone()
            if not row:return ExecutionResult('Chưa có mục tiêu được bạn lưu.','needs_input',spoken_reply='No initial goal has been saved yet. Which goal should I remember?')
            return ExecutionResult(f'Mục tiêu: {row[0]}. Tiêu chí: {row[1]}','success',[{'label':'Mục tiêu đã lưu','state':'success','evidence':row[0]}],'answer',f'The saved goal is {row[0]}.')
        matches=self._matches(text)
        if not matches:
            message='Không có bản ghi cho ngày hôm qua.' if self._day_window(text) else 'Chưa có dữ liệu công việc từ dashboard được kết nối.'
            return ExecutionResult(message,'needs_input',spoken_reply='No dated work record is available. Which source should I use?')
        if subject and len(matches)!=1:return ExecutionResult('Có nhiều việc trùng tên; cần ID hoặc nguồn cụ thể.','needs_input',spoken_reply='Several tasks match. Which task ID or source do you mean?')
        if wants_why:
            evidence=self.evidence(text)
            if evidence:
                missing=[row for row in matches[:5] if (row[0],row[1]) not in {(item['source'],item['item_id']) for item in evidence}]
                if len(matches)<=5 and not missing and all(self.ai_allowed(row['source']) for row in evidence):return None
                lines=[];steps=[]
                for row in evidence:
                    reason=row.get('reason') or row.get('decision','')
                    reason_time=row.get('reason_observed_at') or row.get('decision_recorded_at')
                    lines.append(f"Việc {row['item_id']}: {row['status']} (ghi nhận {row['observed_at']}). Lý do/quyết định được lưu {reason_time}: {reason}. Nguồn: {row['source_ref']}.")
                    steps.append({'label':'Đối chiếu nguồn công việc','state':'success','evidence':row['source_ref']+' '+row['observed_at']})
                for source,identifier,title,status,observed,ref in missing:
                    lines.append(f"Việc {identifier}: {status} (ghi nhận {datetime.fromtimestamp(observed,timezone.utc).isoformat()}); chưa có lý do được lưu. Nguồn: {ref}.")
                    steps.append({'label':'Thiếu lý do công việc','state':'partial','evidence':ref})
                if len(matches)>5:lines.append('Chỉ đối chiếu 5 việc gần nhất trong nhóm được tìm thấy.')
                spoken=f"Task {evidence[0]['item_id']} is {evidence[0]['status']}. The recorded reason is {evidence[0].get('reason') or evidence[0].get('decision')}."
                return ExecutionResult('\n'.join(lines),'partial' if missing or len(matches)>5 else 'success',steps,'answer',spoken)
            return ExecutionResult('Trạng thái đã được lưu nhưng chưa có bằng chứng về lý do chưa hoàn thành.','partial',
                [{'label':'Đối chiếu trạng thái','state':'partial','evidence':matches[0][5]}],'answer','I can see the status, but no recorded reason yet.')
        source,identifier,title,status,observed,ref=matches[0]
        date=datetime.fromtimestamp(observed,timezone.utc).isoformat()
        return ExecutionResult(f'Việc {identifier}: {status} (ghi nhận {date}; nguồn: {ref}).','success',
            [{'label':'Trạng thái công việc','state':'success','evidence':ref+' '+date}],'answer',f'Task {identifier} is {status}.')
