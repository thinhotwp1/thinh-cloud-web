$ErrorActionPreference='Stop'
& (Join-Path (Split-Path $PSScriptRoot) 'Start-Pet.ps1') -SelfTest
$point=[JavisDesktop.PetHost]::ToPhysicalCenter(1300,100,352,300,1.5,1.5)
if($point.X -ne 2214 -or $point.Y -ne 375){throw 'DIP coordinates were passed to a physical monitor lookup.'}
'PASS: 150% DIP center maps to physical monitor coordinates.'
