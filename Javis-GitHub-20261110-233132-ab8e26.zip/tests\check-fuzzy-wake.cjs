const assert=require('node:assert/strict');
const vm=require('node:vm');
const {setup,flush}=require('./check-webspeech-ui.cjs');

(async()=>{
  const app=setup();await flush();
  for(const [said,accepted] of [
    ['Hey Darvis',true],['Hi Jarviss',true],['Hey Davis',true],['Hey Dávis',true],
    ['Bảo Bối',true],['Bao Boi',true],['Chào Bảo Bối ơi',true],
    ['Hey Bảo Bói',true],['Hi Bao Boii',true],
    ['Darvis',false],['I met Darvis',false],['Hey JavaScript',false],
    ['Hey Davidson',false],['Hey Devil',false],['Tôi yêu Bảo Bối',false],
    ['Bảo Bói',false],['Hey bảo vệ',false]
  ]){
    const parsed=vm.runInContext(`parseWake(${JSON.stringify(said)})`,app.context);
    assert.equal(parsed.matched,accepted,said);
    if(accepted)assert.equal(parsed.remaining,'',said);
  }
  await app.node('start').onclick();
  assert.equal(app.instances.at(-1).lang,'vi-VN','Vietnamese task mode should recognize the Vietnamese wake name');
  app.instances.at(-1).final('Hey Bảo Bói');await flush();
  assert.equal(app.calls.filter(c=>c.path==='/api/arm').length,1);
  assert.equal(app.calls.find(c=>c.path==='/api/arm').body.wake,'Hey Bảo Bói');
  assert.equal(app.state.phase,'task');app.stop();
  const english=setup();await flush();english.node('task-language').value='en-US';
  await english.node('start').onclick();assert.equal(english.instances.at(-1).lang,'en-US');
  english.instances.at(-1).final('Hey Jarvis');await flush();
  assert.equal(english.state.phase,'task');assert.equal(english.instances.at(-1).lang,'en-US');english.stop();
  console.log('PASS: bounded near-wake matching reaches the normal one-use grant.');
})().catch(error=>{console.error(error);process.exitCode=1;});
