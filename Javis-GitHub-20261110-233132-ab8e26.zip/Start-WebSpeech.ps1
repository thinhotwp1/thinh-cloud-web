param([ValidateSet(8766)][int]$Port=8766,[switch]$Describe,[switch]$NoBrowser)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
if($Describe) {
    @{Mode='live-execution';Url="http://127.0.0.1:$Port/";SessionFile=(Join-Path $root 'state\session.json');LocalModelLoaded=$false;IdleCodexRequests=0}|ConvertTo-Json
    exit 0
}
if(-not(Test-Path -LiteralPath (Join-Path $root 'state\session.json'))) {throw 'Saved session missing. Run Start-Codex.ps1 -InitializeOnly first.'}
$statePath=Join-Path $root 'state\webspeech-live.json'
$state=$null
if(Test-Path -LiteralPath $statePath) {
    try {
        $candidate=Get-Content -Raw -Encoding UTF8 -LiteralPath $statePath|ConvertFrom-Json
        if($candidate.url -eq "http://127.0.0.1:$Port/") {
            $health=Invoke-RestMethod ($candidate.url+'health') -TimeoutSec 1
            if($health.app -eq 'jarvis-webspeech-live' -and $health.server_id -eq $candidate.server_id -and $health.pid -eq $candidate.pid) {$state=$candidate}
        }
    } catch {}
}
if(-not $state) {
    $python=Join-Path $root '.venv\Scripts\python.exe'
    $server=Join-Path $root 'tools\webspeech_live_server.py'
    $process=Start-Process $python -ArgumentList ('"{0}" --port {1}' -f $server,$Port) -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput (Join-Path $root 'state\webspeech-live.stdout.log') `
        -RedirectStandardError (Join-Path $root 'state\webspeech-live.stderr.log')
    $until=(Get-Date).AddSeconds(10)
    do {
        Start-Sleep -Milliseconds 150
        try {
            $candidate=Get-Content -Raw -LiteralPath $statePath -ErrorAction Stop|ConvertFrom-Json
            if($candidate.url -eq "http://127.0.0.1:$Port/" -and $candidate.port -eq $Port) {
                $health=Invoke-RestMethod ($candidate.url+'health') -TimeoutSec 1
                if($health.app -eq 'jarvis-webspeech-live' -and $health.server_id -eq $candidate.server_id -and $health.pid -eq $candidate.pid) {$state=$candidate;break}
            }
        } catch {}
        if($process.HasExited) {throw 'Live voice server exited. See state/webspeech-live.stderr.log.'}
    } while((Get-Date) -lt $until)
    $process.Dispose()
    if(-not $state) {throw 'Live voice server did not start.'}
}
Write-Host ('JARVIS LIVE VOICE: '+$state.url) -ForegroundColor Green
Write-Host 'Full Access execution after wake + task. Click Start and allow mic manually. Idle listening does not call Codex.'
if(-not $NoBrowser) {
    & (Join-Path $root 'tools\Open-Chrome.ps1') -Inspect | Out-Null
    & (Join-Path $root 'tools\Open-Voice-Page.ps1') -VoiceUrl $state.url
}
