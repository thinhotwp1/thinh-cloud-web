import json
from pathlib import Path
import sys
import tempfile
import concurrent.futures
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from voice_core import WakeGate, VoiceControl, SpeechSegmenter, CodexRunner

class WakeTests(unittest.TestCase):
    def test_vietnamese_bao_boi_wake_exact_and_near_without_ambient_match(self):
        aliases=json.loads((Path(__file__).resolve().parents[1]/'voice-config.json').read_text(encoding='utf-8-sig'))['wake_aliases']
        gate=WakeGate(aliases=aliases)
        for text in ('Bảo Bối','Bao Boi','Hey Bảo Bối','Chào Bảo Bối ơi',
                     'Hey Bảo Bói','Hi Bao Boii','Hay Báo Bối'):
            gate.reset()
            with self.subTest(text=text):self.assertEqual(gate.accept(text,now=1),('armed',None))
        gate.reset()
        self.assertEqual(gate.accept('Hey Bảo Bói, mở dashboard',now=1),('request','mở dashboard'))
        for text in ('Tôi yêu Bảo Bối','Bảo BốiHóa','Bảo Bói','Hey bảo vệ','Hey Bảo BốiHóa'):
            gate.reset()
            with self.subTest(text=text):self.assertEqual(gate.accept(text,now=1),('ignored',None))
    def test_near_wake_spelling_requires_greeting_and_short_distance(self):
        gate=WakeGate(aliases=['jarvis','davis'])
        self.assertEqual(gate.accept('Hey Darvis',now=1),('armed',None))
        gate.reset()
        self.assertEqual(gate.accept('Hi Jarviss',now=2),('armed',None))
        gate.reset()
        self.assertEqual(gate.accept('Hey Dávis',now=2.5),('armed',None))
        gate.reset()
        self.assertEqual(gate.accept('Hey Darvis, open YouTube',now=3),('request','open YouTube'))
        for text in ('Darvis','I met Darvis','Hey JavaScript','Hey Davidson','Hey Devil'):
            gate.reset()
            with self.subTest(text=text):self.assertEqual(gate.accept(text,now=4),('ignored',None))
    def test_configured_david_variants_arm_but_do_not_match_middle_or_longer_names(self):
        aliases=json.loads((Path(__file__).resolve().parents[1]/'voice-config.json').read_text(encoding='utf-8-sig'))['wake_aliases']
        for name in ('Jarvis','Javis','David','Dave','Davie','Davids','Devis','Jervis','Jarvies'):
            for greeting in ('Hi','Hey'):
                with self.subTest(name=name,greeting=greeting):
                    self.assertEqual(WakeGate(aliases=aliases).accept(greeting+' '+name,now=1),('armed',None))
        for text in ('Tôi gặp David hôm qua','Hey Davidson','Hey Daveville'):
            self.assertEqual(WakeGate(aliases=aliases).accept(text,now=1),('ignored',None))
    def test_configured_similar_names_and_repeated_calls_arm_without_sending_names(self):
        aliases=['davis','jarvist','tavis','jarves','jarvice']
        for text in ('Hey Davis!','Hi Jarvist.','Hey Tavis.','Jarves','Jarvice',
                     'Davis Javis Davis','Hey Davis, Javis, Davis!'):
            with self.subTest(text=text):
                self.assertEqual(WakeGate(aliases=aliases).accept(text,now=1),('armed',None))

    def test_repeated_aliases_are_removed_and_task_unicode_is_preserved(self):
        gate=WakeGate(aliases=['davis','tavis'])
        self.assertEqual(gate.accept('Hey Davis, Javis, Davis, mở YouTube bài Sóng Gió.',now=1),
                         ('request','mở YouTube bài Sóng Gió.'))
        self.assertEqual(gate.accept('Hi Tavis, open YouTube.',now=2),('request','open YouTube.'))

    def test_aliases_do_not_match_middle_mentions_or_longer_words(self):
        gate=WakeGate(aliases=['davis'])
        for text in ('Tôi gặp Davis hôm qua.','David mở YouTube','Hey Davisville, open YouTube.',
                     'Hey JavaScript, open YouTube.'):
            with self.subTest(text=text):
                self.assertEqual(gate.accept(text,now=1),('ignored',None))

    def test_aliases_are_literal_and_invalid_config_fails_clearly(self):
        gate=WakeGate(aliases=['da.vis'])
        self.assertEqual(gate.accept('Hey daxvis',now=1),('ignored',None))
        with self.assertRaises(ValueError):
            WakeGate(aliases='davis')

    def test_observed_javist_spelling_keeps_the_whole_task(self):
        self.assertEqual(WakeGate().accept('Hi Javist, open YouTube.',now=1),
                         ('request','open YouTube.'))
        self.assertEqual(WakeGate().accept('Hi JavaScript, open YouTube.',now=1),
                         ('ignored',None))

    def test_vietnamese_spelling_of_hey_keeps_request(self):
        self.assertEqual(WakeGate().accept('Hay Jarvis, Mở Bài, Sóng Gió, YouTube.', now=1),
                         ('request', 'Mở Bài, Sóng Gió, YouTube.'))

    def test_request_started_in_armed_window_can_finish_after_deadline(self):
        gate = WakeGate(arm_seconds=20)
        gate.accept('Jarvis', now=10)
        self.assertEqual(gate.accept('Mở YouTube.', now=38, recorded_at=25),
                         ('request', 'Mở YouTube.'))

    def test_ambient_speech_does_not_dispatch(self):
        gate = WakeGate()
        self.assertEqual(gate.accept('Mở YouTube bài Sóng Gió', now=1), ('ignored', None))

    def test_natural_vietnamese_after_wake_is_preserved(self):
        gate = WakeGate()
        self.assertEqual(gate.accept('Hey Jarvis, mở YouTube bài Sóng Gió.', now=1),
                         ('request', 'mở YouTube bài Sóng Gió.'))

    def test_wake_then_request_arms_once_and_expires(self):
        gate = WakeGate(arm_seconds=20)
        self.assertEqual(gate.accept('Hey Javis!', now=10), ('armed', None))
        self.assertEqual(gate.accept('Kiểm tra backend như lần trước.', now=12),
                         ('request', 'Kiểm tra backend như lần trước.'))
        self.assertEqual(gate.accept('Mở trình duyệt.', now=13), ('ignored', None))
        gate.accept('Jarvis', now=20)
        self.assertEqual(gate.accept('Mở trình duyệt.', now=41), ('ignored', None))

    def test_mention_in_middle_is_not_wake(self):
        self.assertEqual(WakeGate().accept('Tôi nói về Jarvis hôm qua.', now=1), ('ignored', None))

    def test_speech_recorded_before_ready_does_not_consume_armed_slot(self):
        gate=WakeGate()
        gate.accept('Jarvis',now=10)
        self.assertEqual(gate.accept('Mở ứng dụng.',now=12,recorded_at=9), ('ignored',None))
        self.assertEqual(gate.accept('Mở YouTube.',now=13,recorded_at=11), ('request','Mở YouTube.'))

class VoiceControlTests(unittest.TestCase):
    def test_configured_alias_reaches_voice_dispatch_without_wake_names(self):
        control=VoiceControl(aliases=['davis'])
        sent=[]
        result=control.accept_voice('Hey Davis, Javis, open YouTube.',0,1,2,3,lambda *a:sent.append(a))
        self.assertEqual(result,('request','open YouTube.'))
        self.assertEqual(sent,[('open YouTube.',0,2)])

    def test_logged_valid_request_survives_medium_decode_queue_delay(self):
        control=VoiceControl(max_transcript_age=45)
        sent=[]
        outcome=control.accept_voice('Hi Javis, open YouTube.',0,1,4,25,lambda *a:sent.append(a))
        self.assertEqual(outcome,('request','open YouTube.'))
        self.assertEqual(sent,[('open YouTube.',0,4)])
        self.assertEqual(control.accept_voice('Hi Javis, open YouTube.',0,1,4,50,lambda *a:sent.append(a)),
                         ('stale',None))
        self.assertEqual(len(sent),1)

    def test_ready_deadline_begins_after_audio_feedback_and_drops_old_clips(self):
        control=VoiceControl()
        control.gate.accept('Javis',now=10)
        self.assertTrue(control.acknowledge(0,now=11))
        self.assertTrue(control.predates_ready(10.5))
        self.assertFalse(control.predates_ready(11.5))
        self.assertTrue(control.is_armed_for(30.5))
        self.assertFalse(control.is_armed_for(31))

    def test_mute_during_ack_cannot_rearm(self):
        control=VoiceControl()
        control.gate.accept('Javis',now=10)
        control.set_muted(True)
        self.assertFalse(control.acknowledge(0,now=11))
        self.assertFalse(control.is_armed_for(12))

    def test_capture_inside_armed_window_remains_a_request_after_deadline(self):
        control=VoiceControl()
        control.gate.accept('Jarvis',now=10)
        self.assertTrue(control.is_armed_for(25))
        self.assertFalse(control.is_armed_for(9))
        self.assertFalse(control.is_armed_for(31))
        control.set_muted(True)
        self.assertFalse(control.is_armed_for(25))

    def test_mute_and_unmute_invalidate_inflight_old_transcript(self):
        control=VoiceControl()
        epoch=control.epoch
        sent=[]
        control.set_muted(True)
        control.set_muted(False)
        result=control.accept_voice('Jarvis, mở YouTube',epoch,1,2,3,lambda *args:sent.append(args))
        self.assertEqual(result,('invalidated',None))
        self.assertEqual(sent,[])

    def test_slow_decode_is_rejected_after_transcription(self):
        control=VoiceControl()
        sent=[]
        self.assertEqual(control.accept_voice('Jarvis, mở YouTube',0,1,2,18,lambda *a:sent.append(a)),('stale',None))
        self.assertEqual(sent,[])

    def test_request_capture_time_is_not_refreshed_at_enqueue(self):
        control=VoiceControl()
        sent=[]
        control.accept_voice('Jarvis, mở YouTube',0,1,2,3,lambda *a:sent.append(a))
        self.assertEqual(sent,[('mở YouTube',0,2)])

    def test_muted_or_stopped_job_cannot_start(self):
        import time
        control=VoiceControl()
        control.set_muted(True)
        with self.assertRaisesRegex(RuntimeError,'invalidated'):
            with control.authorize(0,time.monotonic(),120):
                self.fail('Muted voice job started')
        control.stop()
        with self.assertRaisesRegex(RuntimeError,'stopping'):
            with control.authorize(None,time.monotonic(),120):
                self.fail('Stopped typed job started')

    def test_expired_job_cannot_start(self):
        import time
        with self.assertRaisesRegex(RuntimeError,'expired'):
            with VoiceControl().authorize(0,time.monotonic()-121,120):
                self.fail('Expired job started')

class SegmentationTests(unittest.TestCase):
    def test_silence_and_short_noise_do_not_make_utterance(self):
        s = SpeechSegmenter(sample_rate=100, min_speech_seconds=.25, silence_seconds=.3)
        self.assertIsNone(s.feed([0]*10, 0))
        s.feed([.1]*10, .1)
        s.feed([.1]*10, .1)
        results = [s.feed([0]*10, 0) for _ in range(5)]
        self.assertTrue(all(value is None for value in results))

    def test_speech_emits_once_after_silence(self):
        s = SpeechSegmenter(sample_rate=100, min_speech_seconds=.25, silence_seconds=.3)
        output = []
        for _ in range(5):
            output.append(s.feed([.1]*10, .1))
        for _ in range(6):
            output.append(s.feed([0]*10, 0))
        clips = [item for item in output if item is not None]
        self.assertEqual(len(clips), 1)
        self.assertGreaterEqual(sum(map(len, clips[0])), 50)

class RunnerTests(unittest.TestCase):
    def test_contract_returns_final_agent_message_without_progress(self):
        from execution_result import parse_codex_result
        final={'version':1,'outcome':'success','reply':'Opened YouTube','steps':[{'label':'Open page','state':'success','evidence':'https://www.youtube.com/'}]}
        source='import json\n'
        for text in ('Opening YouTube in the Jarvis work tab.',json.dumps(final)):
            event={'type':'item.completed','item':{'type':'agent_message','text':text}}
            source+='print('+repr(json.dumps(event))+')\n'
        self.cli.write_text(source,encoding='utf-8')
        events=[]
        runner=CodexRunner(self.root,cli=[sys.executable,str(self.cli)],result_contract=True,on_event=events.append)
        reply=runner.run('open YouTube')
        self.assertEqual(reply,json.dumps(final))
        self.assertEqual(parse_codex_result(reply).outcome,'success')
        self.assertEqual(len(events),2)
    def test_contract_does_not_reuse_an_earlier_success_if_final_message_is_unknown(self):
        from execution_result import parse_codex_result
        messages=[json.dumps(dict(version=1,outcome='success',reply='old',steps=[dict(label='old',state='success',evidence='old')])), 'Could not verify the requested result.']
        self.cli.write_text('import json\n'+'\n'.join('print('+repr(json.dumps(dict(type='item.completed',item=dict(type='agent_message',text=text))))+')' for text in messages),encoding='utf-8')
        reply=CodexRunner(self.root,cli=[sys.executable,str(self.cli)],result_contract=True).run('work')
        self.assertEqual(parse_codex_result(reply).outcome,'unknown')
    def test_reasoning_override_is_process_scoped_and_keeps_exact_prompt(self):
        runner=CodexRunner(self.root,cli=[sys.executable,str(self.cli)],reasoning_effort='medium')
        runner.run('Mở YouTube')
        args=json.loads((self.root/'received.json').read_text(encoding='utf-8'))['args']
        self.assertIn('model_reasoning_effort="medium"',args)
        self.assertIn(self.thread_id,args)
        self.assertNotIn('--model',args)
        with self.assertRaises(ValueError):
            CodexRunner(self.root,cli=[sys.executable,str(self.cli)],reasoning_effort='arbitrary')

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root/'state').mkdir()
        self.thread_id = '11111111-2222-4333-8444-555555555555'
        (self.root/'state/session.json').write_text(json.dumps({'thread_id': self.thread_id}), encoding='utf-8')
        self.cli = self.root/'fake_cli.py'
        self.cli.write_text('''import sys,json,pathlib
import time
text=sys.stdin.read()
with pathlib.Path("sequence.jsonl").open("a",encoding="utf-8") as log: log.write(json.dumps(["start",text])+"\\n")
time.sleep(.05)
pathlib.Path("received.json").write_text(json.dumps({"args":sys.argv[1:],"text":text}),encoding="utf-8")
if text=="FAIL":
 print("backend unavailable",file=sys.stderr);sys.exit(7)
if text=="BLOCK":
 time.sleep(60)
if text=="SOFT_FAIL":
 print(json.dumps({"type":"turn.failed","error":{"message":"backend turn failed"}}));sys.exit(0)
print(json.dumps({"type":"thread.started","thread_id":"11111111-2222-4333-8444-555555555555"}))
print(json.dumps({"type":"item.completed","item":{"type":"agent_message","text":"Đã nhận: "+text}}))
with pathlib.Path("sequence.jsonl").open("a",encoding="utf-8") as log: log.write(json.dumps(["end",text])+"\\n")
''', encoding='utf-8')
        self.runner = CodexRunner(self.root, cli=[sys.executable, str(self.cli)])

    def tearDown(self):
        self.temp.cleanup()

    def test_unicode_and_shell_characters_are_exact_stdin_same_session(self):
        text = 'Mở bài Sóng Gió & giữ nguyên "$HOME"; không đổi tên.'
        reply = self.runner.run(text)
        received = json.loads((self.root/'received.json').read_text(encoding='utf-8'))
        self.assertEqual(received['text'], text)
        self.assertIn(self.thread_id, received['args'])
        self.assertIn('resume', received['args'])
        self.assertNotIn('--last', received['args'])
        self.assertIn('danger-full-access', received['args'])
        self.assertIn(text, reply)

    def test_failure_does_not_replace_session(self):
        before = (self.root/'state/session.json').read_bytes()
        with self.assertRaisesRegex(RuntimeError, '7'):
            self.runner.run('FAIL')
        self.assertEqual((self.root/'state/session.json').read_bytes(), before)

    def test_sourced_analysis_can_run_read_only_without_changing_saved_session(self):
        self.runner.sandbox='read-only'
        self.runner.run('Summarize sourced work facts')
        received=json.loads((self.root/'received.json').read_text())
        self.assertIn('read-only',received['args'])
        self.assertNotIn('danger-full-access',received['args'])
        self.assertEqual(self.runner.session_id(),self.thread_id)

    def test_cli_events_and_stderr_are_not_persisted_as_unbounded_raw_logs(self):
        self.runner.run('PRIVATE TASK CONTENT')
        self.assertFalse((self.root/'state/voice-codex-events.jsonl').exists())
        self.assertFalse((self.root/'state/codex-stderr.log').exists())

    def test_two_calls_are_serialized_on_same_runner(self):
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            replies=list(pool.map(self.runner.run, ['first', 'second']))
        events=[json.loads(line) for line in (self.root/'sequence.jsonl').read_text().splitlines()]
        self.assertEqual([e[0] for e in events], ['start','end','start','end'])
        self.assertIn('first', replies[0])
        self.assertIn('second', replies[1])

    def test_failed_turn_is_error_even_when_cli_exit_is_zero(self):
        with self.assertRaisesRegex(RuntimeError, 'backend turn failed'):
            self.runner.run('SOFT_FAIL')

    def test_invalid_saved_id_does_not_start_another_conversation(self):
        (self.root/'state/session.json').write_text('{"thread_id":"broken"}',encoding='utf-8')
        with self.assertRaises(ValueError):
            self.runner.run('test')
        self.assertFalse((self.root/'received.json').exists())

    def test_shutdown_prevents_any_later_child_start(self):
        self.runner.cancel()
        with self.assertRaisesRegex(RuntimeError,'cancelled'):
            self.runner.run('Should not launch')
        self.assertFalse((self.root/'received.json').exists())

    def test_mute_authorization_is_checked_at_process_creation(self):
        import time
        control=VoiceControl()
        guard=control.authorize(0,time.monotonic(),120)
        control.set_muted(True)
        with self.assertRaisesRegex(RuntimeError,'invalidated'):
            self.runner.run('Should not launch',start_guard=guard)
        self.assertFalse((self.root/'received.json').exists())

    def test_shutdown_terminates_active_child_and_execution_thread(self):
        import threading,time
        errors=[]
        def execute():
            try:self.runner.run('BLOCK')
            except RuntimeError as error:errors.append(error)
        thread=threading.Thread(target=execute)
        thread.start()
        deadline=time.monotonic()+3
        while not (self.root/'received.json').exists() and time.monotonic()<deadline:
            time.sleep(.01)
        self.assertTrue((self.root/'received.json').exists())
        self.runner.cancel()
        thread.join(timeout=3)
        self.assertFalse(thread.is_alive())
        self.assertTrue(errors)
        self.assertIsNone(self.runner.process)

if __name__ == '__main__':
    unittest.main()
