$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot
Add-Type -Path (Join-Path $root 'tools\jarvis_windows.cs')
$anchor = [JarvisWindowGuard]::Foreground()
$tool = Join-Path $root 'tools\Open-Chrome.ps1'
$first = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $tool -Url about:blank
if ($LASTEXITCODE -ne 0) { throw 'First navigation failed' }
$first = $first | ConvertFrom-Json
$state = Get-Content -Raw -LiteralPath (Join-Path $root 'state\browser.json') | ConvertFrom-Json
$beforeCount = @((Invoke-RestMethod "$($state.endpoint)/json/list") | Where-Object type -eq page).Count
$second = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $tool -Url https://example.com
if ($LASTEXITCODE -ne 0) { throw 'Second navigation failed' }
$second = $second | ConvertFrom-Json
$pages = @((Invoke-RestMethod "$($state.endpoint)/json/list") | Where-Object type -eq page)
if ($first.target_id -ne $second.target_id) { throw 'Navigation created/replaced the remembered tab' }
if ($pages.Count -ne $beforeCount) { throw 'Navigation changed the number of tabs' }
if ([JarvisWindowGuard]::Foreground() -ne $anchor) { throw 'Browser navigation stole foreground focus' }
$until = (Get-Date).AddSeconds(10)
do {
    $text = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $tool -Expression 'location.href'
    if ($LASTEXITCODE -ne 0) { throw 'Page inspection failed' }
    if ($text -like 'https://example.com*') { break }
    Start-Sleep -Milliseconds 200
} while ((Get-Date) -lt $until)
if ($text -notlike 'https://example.com*') { throw "Unexpected page URL: $text" }
'PASS: two navigations reused one target, added no tabs, kept foreground, and page inspection returned the expected URL.'
