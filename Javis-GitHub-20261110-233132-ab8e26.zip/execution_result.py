"""Bounded outcome contract. A completed model turn alone is not success."""
import json
import re
from urllib.parse import urlsplit, urlunsplit

OUTCOMES = {'success','partial','needs_input','failed','cancelled','unknown'}


def clean(value, limit=1000):
    text = str(value or '')[:limit]
    def url(match):
        try:
            p=urlsplit(match[0]);host=p.hostname or ''
            if p.port: host+=':'+str(p.port)
            return urlunsplit((p.scheme,host,p.path,'',''))
        except ValueError: return '[URL]'
    text=re.sub(r'https?://[^\s<>"\']+',url,text)
    return re.sub(r'(?i)\b(token|password|secret|api[_-]?key|authorization)\s*[:=]\s*[^\s,;]+',r'\1=[redacted]',text)


class ExecutionResult(str):
    def __new__(cls, reply, outcome='unknown', steps=(),response_kind='action',spoken_reply='',question_options=()):
        instance=super().__new__(cls,str(reply))
        instance.outcome=outcome if outcome in OUTCOMES else 'unknown'
        instance.steps=[{'label':clean(s.get('label'),160),'state':s.get('state') if s.get('state') in OUTCOMES else 'unknown',
                         'evidence':clean(s.get('evidence'),400)} for s in list(steps)[:20] if isinstance(s,dict)]
        instance.response_kind=response_kind if response_kind in ('action','answer','question') else 'action'
        if outcome=='needs_input':instance.response_kind='question'
        spoken=clean(spoken_reply,2000) if isinstance(spoken_reply,str) else ''
        if len(spoken)>350 and instance.response_kind=='question':
            questions=re.findall(r'[^.!?]*\?',spoken)
            if questions:spoken=questions[-1].strip()
        if len(spoken)>350:
            short=spoken[:350];ends=list(re.finditer(r'[.!?](?=\s|$)',short))
            spoken=short[:ends[-1].end()] if ends else short.rsplit(' ',1)[0]+'…' if ' ' in short else short[:349]+'…'
        instance.spoken_reply=spoken[:350]
        instance.question_options=[clean(v,100) for v in list(question_options)[:4] if isinstance(v,str)] if isinstance(question_options,(list,tuple)) else []
        return instance


def parse_codex_result(reply):
    try:
        if len(reply.encode('utf-8'))>32000: raise ValueError('oversized')
        value=json.loads(reply.strip().removeprefix('```json').removesuffix('```').strip())
        if not isinstance(value,dict) or value.get('version') not in (1,2) or value.get('outcome') not in OUTCOMES: raise ValueError('invalid')
        if not isinstance(value.get('reply'),str) or not isinstance(value.get('steps'),list): raise ValueError('invalid')
        result=ExecutionResult(value['reply'],value['outcome'],value['steps'],value.get('response_kind','action'),value.get('spoken_reply',''),value.get('question_options',[]))
        if result.outcome=='success' and not any(s['state']=='success' and s['evidence'] for s in result.steps):
            result.outcome='unknown'
        return result
    except (ValueError,TypeError,AttributeError):
        return ExecutionResult(reply,'unknown')


RESULT_INSTRUCTION = '''\n\n[JAVIS OUTPUT CONTRACT]
Return ONLY JSON {"version":2,"outcome":"success|partial|needs_input|failed|cancelled|unknown",
"reply":"concise answer in the user's language","steps":[{"label":"short action actually attempted",
"state":"success|partial|needs_input|failed|cancelled|unknown","evidence":"short observed evidence"}],
"response_kind":"action|answer|question","spoken_reply":"short plain English spoken answer or question","question_options":[]}.
Use answer for information questions, explanations and summaries (including Vietnamese questions), action for desktop tasks,
and question with outcome needs_input when a required detail is unclear. Answer/question must include spoken_reply in English:
Normally 1-2 short sentences, maximum 350 characters; summaries at most 3 short sentences. Lead with the actual answer,
not a preamble, narration, process notes or an offer to help further. Keep the displayed reply similarly concise unless the
user explicitly requests detail. Put execution evidence in steps rather than narrating it aloud.
No Markdown, credentials, raw logs or long URLs in speech. Ask one concrete question with
at most four short question_options. For actions spoken_reply may be empty unless spoken explanation was requested.
Do not execute a guessed project/URL. Record already completed effects; do not replay them when the user answers.
Use at most 20 steps. Never include credentials or raw logs. Success requires evidence that the user's goal was achieved;
turn completion, launching a command, or opening a URL alone does not prove services are healthy or media is playing.
Historical data is context only; do not execute historical actions unless the current request asks for them.
'''
