import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
from contextlib import nullcontext
from process_control import TaskCancelled
from web_bridge import VoiceBridge,BridgeError


class BusyReplacementTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.started=threading.Event();self.release=threading.Event();self.calls=[];self.concurrent=0;self.maximum=0
        outer=self
        class Runner:
            def __init__(self,on_event):pass
            def run(self,text):
                outer.concurrent+=1;outer.maximum=max(outer.maximum,outer.concurrent)
                try:
                    outer.calls.append(text)
                    if text.startswith('investigate old work'):
                        outer.started.set();outer.release.wait(3)
                        raise TaskCancelled('owned old worker stopped')
                    return json.dumps(dict(version=2,outcome='success',reply='new task complete',response_kind='action',spoken_reply='',
                        steps=[dict(label='New task',state='success',evidence='verified')]))
                finally:outer.concurrent-=1
            def cancel(self):outer.release.set();return True
        self.bridge=VoiceBridge(self.root,runner_factory=Runner,mutex_factory=nullcontext)
    def tearDown(self):self.release.set();self.bridge.close();self.temp.cleanup()
    def old(self):
        self.bridge.submit('old',self.bridge.arm('Hey Javis')['grant'],'investigate old work')
        self.assertTrue(self.started.wait(1))
    def test_new_command_waits_for_owned_old_worker_and_runs_once(self):
        self.old()
        grant=self.bridge.arm_busy('Hey Javis','listener-1','old')['grant']
        queued=self.bridge.replace('new',grant,'listener-1','old','investigate new work')
        self.assertEqual(queued['state'],'queued')
        self.assertEqual(self.bridge.replace('new',grant,'listener-1','old','investigate new work')['id'],'new')
        until=time.monotonic()+2
        while self.bridge.status('new')['outcome']=='unknown' and time.monotonic()<until:time.sleep(.01)
        self.assertEqual(self.bridge.status('old')['outcome'],'cancelled')
        self.assertEqual(self.bridge.status('new')['outcome'],'success')
        self.assertEqual(self.maximum,1);self.assertEqual(len(self.calls),2)
        with self.assertRaises(BridgeError):self.bridge.replace('bad',grant,'listener-1','old','run another')
    def test_cancel_drops_pending_replacement_and_does_not_run_it(self):
        self.old();grant=self.bridge.arm_busy('Hi Javis','listener-1','old')['grant']
        self.bridge.replace('new',grant,'listener-1','old','investigate new work')
        self.bridge.cancel('old');self.bridge.worker.join(2)
        self.assertEqual(self.bridge.status('new')['outcome'],'cancelled')
        self.assertEqual(len(self.calls),1)
    def test_wrong_owner_or_job_cannot_replace(self):
        self.old();grant=self.bridge.arm_busy('Hi Javis','listener-1','old')['grant']
        with self.assertRaises(BridgeError):self.bridge.replace('wrong',grant,'listener-2','old','new')
        with self.assertRaises(BridgeError):self.bridge.replace('wrong',grant,'listener-1','another','new')
        self.assertEqual(len(self.calls),1)
    def test_expired_replacement_reports_needs_input_instead_of_disappearing(self):
        self.old();grant=self.bridge.arm_busy('Hi Javis','listener-1','old')['grant']
        self.bridge.replace('new',grant,'listener-1','old','investigate new work')
        self.bridge.pending_deadline=self.bridge.clock()-1
        self.assertEqual(self.bridge.status('new')['outcome'],'needs_input','polling should reveal timeout while the old worker still runs')
        self.assertEqual(self.bridge.active,'old')
        self.release.set()
        until=time.monotonic()+2
        while self.bridge.status('new')['state']=='queued' and time.monotonic()<until:time.sleep(.01)
        result=self.bridge.status('new')
        self.assertEqual(result['outcome'],'needs_input')
        self.assertIn('30',result['reply'])
        self.assertEqual(len(self.calls),1)
