from pathlib import Path
import array
import math
import subprocess
import sys
import tempfile
import unittest
import wave
from audio_service import AudioService


class CueTests(unittest.TestCase):
    def test_generated_chime_is_three_ascending_unclipped_notes(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'done.wav'
            result=subprocess.run([sys.executable,str(Path(__file__).resolve().parents[1]/'tools/build-completion-cue.py'),str(path)],capture_output=True)
            self.assertEqual(result.returncode,0,result.stderr.decode())
            with wave.open(str(path),'rb') as wav:
                rate=wav.getframerate();self.assertEqual(wav.getnchannels(),1);self.assertEqual(wav.getsampwidth(),2)
                self.assertAlmostEqual(wav.getnframes()/rate,1.5,places=2);samples=array.array('h',wav.readframes(wav.getnframes()))
            self.assertLess(max(map(abs,samples)),32767);self.assertGreater(max(map(abs,samples)),16000)
            frequencies=[]
            for start in (.06,.49,.92):
                clip=samples[int(rate*start):int(rate*(start+.2))]
                crossings=sum(a<=0<b for a,b in zip(clip,clip[1:]));frequencies.append(crossings/.2)
            self.assertTrue(frequencies[0]<frequencies[1]<frequencies[2],frequencies)
    def test_gain_scales_only_the_played_clip_and_rejects_invalid_values(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'webspeech-probe').mkdir()
            path=root/'webspeech-probe/done.wav'
            with wave.open(str(path),'wb') as wav:
                wav.setparams((1,2,22050,0,'NONE','not compressed'));wav.writeframes(array.array('h',[12000,-12000]*100).tobytes())
            heard=[]
            def player(path,event):
                with wave.open(str(path),'rb') as wav:heard.append(array.array('h',wav.readframes(wav.getnframes()))[0])
            audio=AudioService(root,player=player)
            self.assertTrue(audio.play('cue','done','generation',gain=.25));self.assertEqual(heard,[3000])
            with wave.open(str(path),'rb') as wav:self.assertEqual(array.array('h',wav.readframes(1))[0],12000)
            for gain in (-1,2,float('nan')):
                with self.assertRaises(ValueError):audio.play('bad','done','g',gain=gain)
