param([Parameter(Mandatory=$true)][ValidatePattern('^[a-z][a-z0-9-]{0,31}$')][string]$WorkspaceId,[string]$ConfigPath)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
$root=Split-Path $PSScriptRoot
. (Join-Path $PSScriptRoot 'Chrome-Cdp.ps1')
. (Join-Path $PSScriptRoot 'Show-WorkWindow.ps1')
if(-not $ConfigPath){$ConfigPath=Join-Path $root 'workspaces.json'}
$ConfigPath=[IO.Path]::GetFullPath($ConfigPath)
if(-not $ConfigPath.StartsWith($root+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase) -or
   [IO.Path]::GetExtension($ConfigPath) -ne '.json'){throw 'Manifest must be a JSON file inside Jarvis.'}
if((Get-Item -LiteralPath $ConfigPath).Length -gt 65536){throw 'Manifest exceeds 64 KB.'}
$config=Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8|ConvertFrom-Json
$matching=@($config.workspaces|Where-Object id -eq $WorkspaceId)
if($config.version -ne 1 -or $matching.Count -ne 1){throw 'Unknown or duplicate workspace ID.'}
$workspace=$matching[0]
if($workspace.enabled -ne $true){throw 'Workspace is not configured/enabled.'}
if(@($workspace.tabs).Count -gt 6){throw 'At most six tabs per workspace are supported.'}
$tabIds=@{}
foreach($tab in $workspace.tabs){
    if($tab.id -notmatch '^[a-z][a-z0-9-]{0,31}$' -or $tabIds.ContainsKey($tab.id)){throw 'Invalid or duplicate tab ID.'}
    $tabIds[$tab.id]=$true
    if($null -eq $tab.url){continue}
    $uri=$null
    if($tab.url -isnot [string] -or $tab.url.Length -gt 2048 -or -not [uri]::TryCreate($tab.url,[UriKind]::Absolute,[ref]$uri) -or
       ($uri.Scheme -notin @('http','https') -and $tab.url -ne 'about:blank') -or $uri.UserInfo){throw 'Only http/https URLs without credentials are supported.'}
    if($uri.Host -in @('localhost','127.0.0.1','[::1]','::1') -and $uri.Port -in @(8765,8766)){throw 'Voice origins cannot be used as work tabs.'}
}
Add-Type -AssemblyName System.Windows.Forms
Add-Type -Path (Join-Path $PSScriptRoot 'jarvis_windows.cs')
$dpiContext=[JarvisWindowGuard]::UsePhysicalCoordinates()
$screen=[Windows.Forms.Screen]::AllScreens|Where-Object {-not $_.Primary}|Select-Object -First 1
if(-not $screen){$screen=[Windows.Forms.Screen]::PrimaryScreen}
$area=$screen.WorkingArea
$profile=Join-Path $root 'state/chrome-profile'
try{$endpoint=Get-JarvisChromeEndpoint $root}
catch{
    # Bootstrap before acquiring the same mutex used by Open-Chrome.
    & (Join-Path $PSScriptRoot 'Open-Chrome.ps1') -Inspect|Out-Null
    $endpoint=Get-JarvisChromeEndpoint $root
}
$mutex=New-Object Threading.Mutex($false,'Local\JarvisChromePage')
$owned=$false;$client=$null;$guard=$null
$statePath=Join-Path $root 'state/worksets.json'
$pendingPath=Join-Path $root 'state/workset-pending.html'
if(-not(Test-Path -LiteralPath $pendingPath)){
    [IO.File]::WriteAllText($pendingPath,'<!doctype html><meta charset="utf-8"><title>Javis workset</title><p>Preparing work tabs...</p>',[Text.UTF8Encoding]::new($false))
}
$pendingUrl=([uri]$pendingPath).AbsoluteUri
function Save-Worksets {
    $temporary=$statePath+'.tmp'
    [IO.File]::WriteAllText($temporary,($script:worksetState|ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $temporary -Destination $statePath -Force
}
function Get-WorksetPages {
    return @((Invoke-JarvisCdp $client 'Target.getTargets' @{}).targetInfos|Where-Object type -eq page)
}
try{
    try{$owned=$mutex.WaitOne(15000)}catch [Threading.AbandonedMutexException] {$owned=$true}
    if(-not $owned){throw 'Another Jarvis browser action is running.'}
    $endpoint=Get-JarvisChromeEndpoint $root
    $client=Connect-JarvisCdp $endpoint.webSocketDebuggerUrl
    $script:worksetState=@{browser_id=$endpoint.webSocketDebuggerUrl;tabs=@()}
    if(Test-Path -LiteralPath $statePath){
        $saved=Get-Content -LiteralPath $statePath -Raw -Encoding UTF8|ConvertFrom-Json
        if($saved.browser_id -eq $endpoint.webSocketDebuggerUrl){
            $script:worksetState.tabs=@(foreach($row in $saved.tabs){$record=@{};foreach($property in $row.PSObject.Properties){$record[$property.Name]=$property.Value};$record})
        }
    }
    $rolesPath=Join-Path $root 'state/webspeech-live-browser.json'
    $voiceId='';$defaultId=''
    if(Test-Path -LiteralPath $rolesPath){$roles=Get-Content -LiteralPath $rolesPath -Raw|ConvertFrom-Json;$voiceId=$roles.voice_target;$defaultId=$roles.work_target}
    $defaultPath=Join-Path $root 'state/browser.json'
    if(Test-Path -LiteralPath $defaultPath){$defaultId=(Get-Content -LiteralPath $defaultPath -Raw|ConvertFrom-Json).target_id}
    $pages=Get-WorksetPages
    if($voiceId -and -not ($pages|Where-Object targetId -eq $voiceId)){$voiceId=''}
    $missing=@();$navigate=@();$results=@();$usedTargets=@{}
    foreach($entry in $script:worksetState.tabs){
        if($entry.target_id){
            if($usedTargets.ContainsKey($entry.target_id)){throw 'Duplicate target ownership in worksets state.'}
            $usedTargets[$entry.target_id]=$true
        }
    }
    foreach($tab in $workspace.tabs){
        if($null -eq $tab.url){$results+=@{id=$tab.id;name=$tab.name;state='unconfigured';target_id=$null};continue}
        $entry=$script:worksetState.tabs|Where-Object {$_.workspace_id -eq $WorkspaceId -and $_.id -eq $tab.id}|Select-Object -First 1
        $target=$null
        if($entry){
            $target=$pages|Where-Object {$_.targetId -eq $entry.target_id -and $_.targetId -notin @($voiceId,$defaultId) -and (-not $voiceId -or $_.openerId -ne $voiceId) -and $_.url -notmatch '^http://(?:localhost|127\.0\.0\.1):876[56](?:/|$)'}|Select-Object -First 1
            if(-not $target -and $entry.marker){
                $target=$pages|Where-Object {$_.url -eq $entry.marker -and $_.targetId -notin @($voiceId,$defaultId) -and (-not $voiceId -or $_.openerId -ne $voiceId)}|Select-Object -First 1
            }
        }
        if($target){
            $entry.target_id=$target.targetId
            if($target.url -eq $entry.marker){
                $navigate+=@{tab=$tab;entry=$entry}
            }else{
                $results+=@{id=$tab.id;name=$tab.name;state='reused';target_id=$target.targetId;current_url=$target.url}
            }
        }else{
            $script:worksetState.tabs=@($script:worksetState.tabs|Where-Object {-not($_.workspace_id -eq $WorkspaceId -and $_.id -eq $tab.id)})
            $entry=@{workspace_id=$WorkspaceId;id=$tab.id;target_id=$null;marker=($pendingUrl+'#jarvis-'+$WorkspaceId+'-'+$tab.id+'-'+[guid]::NewGuid().ToString('N'))}
            $script:worksetState.tabs+=,$entry
            $missing+=@{tab=$tab;entry=$entry}
            $navigate+=@{tab=$tab;entry=$entry}
        }
    }
    Save-Worksets
    $focusBefore=[JarvisWindowGuard]::Foreground()
    $pids=[uint32[]]@(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'"|Where-Object {
        $_.CommandLine -and $_.CommandLine.Contains($profile) -and $_.CommandLine -notmatch '\s--type='
    }|ForEach-Object {$_.ProcessId})
    if(-not $pids.Count){throw 'Owned Jarvis browser process not found.'}
    $voiceWidth=if($voiceId){[Math]::Min(700,[int]($area.Width*.4))}else{0}
    $workX=$area.X+$voiceWidth;$workWidth=$area.Width-$voiceWidth
    if($missing.Count){
        $chrome=@("$env:ProgramFiles\Google\Chrome\Application\chrome.exe","${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe","$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")|Where-Object {Test-Path -LiteralPath $_}|Select-Object -First 1
        if(-not $chrome){throw 'Google Chrome is not installed.'}
        $guard=New-Object JarvisWindowGuard($workX,$area.Y,$workWidth,$area.Height,([string[]]@('chrome')),'Chrome_WidgetWin_',$pids)
        $arguments='--user-data-dir="{0}" --new-window --window-position={1},{2} --window-size={3},{4} {5}' -f $profile,$workX,$area.Y,$workWidth,$area.Height,($missing.entry.marker -join ' ')
        Write-Verbose $arguments
        $launched=Start-Process -FilePath $chrome -ArgumentList $arguments -WindowStyle Minimized -PassThru
        $launched.Dispose()
        $deadline=(Get-Date).AddSeconds(12)
        do{
            $pages=Get-WorksetPages
            $found=0
            foreach($item in $missing){
                $created=$pages|Where-Object url -eq $item.entry.marker|Select-Object -First 1
                if($created){$item.entry.target_id=$created.targetId;$found++}
            }
            Save-Worksets
            if($found -eq $missing.Count){break}
            Start-Sleep -Milliseconds 150
        }while((Get-Date) -lt $deadline)
        Start-Sleep -Milliseconds 350
        $guard.Dispose()
        $guard=$null
    }
        foreach($item in $navigate){
            if(-not $item.entry.target_id){$results+=@{id=$item.tab.id;name=$item.tab.name;state='error';error='Chrome did not expose the new tab.'};continue}
            $result=@{id=$item.tab.id;name=$item.tab.name;state='opened';target_id=$item.entry.target_id}
            $session=''
            try{
                $session=(Invoke-JarvisCdp $client 'Target.attachToTarget' @{targetId=$item.entry.target_id;flatten=$true}).sessionId
                $navigation=Invoke-JarvisCdp $client 'Page.navigate' @{url=$item.tab.url} $session
                if($navigation.errorText){throw $navigation.errorText}
                $until=(Get-Date).AddSeconds(5)
                $ready=$false;$status=$null
                do{
                    $tree=Invoke-JarvisCdp $client 'Page.getFrameTree' @{} $session
                    if(-not $navigation.loaderId -or $tree.frameTree.frame.loaderId -eq $navigation.loaderId){
                        $page=Invoke-JarvisCdp $client 'Runtime.evaluate' @{expression='JSON.stringify({url:location.href,ready:document.readyState})';returnByValue=$true} $session
                        $status=$page.result.value|ConvertFrom-Json
                        $urlReady=if($item.tab.url -eq 'about:blank'){$status.url -eq 'about:blank'}else{
                            $status.url -ne $item.entry.marker -and $status.url -notlike 'about:blank*' -and $status.url -notlike 'chrome-error:*'
                        }
                        if($urlReady -and $status.ready -in @('interactive','complete')){$ready=$true;break}
                    }
                    Start-Sleep -Milliseconds 100
                }while((Get-Date) -lt $until)
                if(-not $ready){throw 'Navigation is still loading; tab was retained for inspection.'}
                $result.current_url=$status.url
            }catch{$result.state='error';$result.error=$_.Exception.Message}
            finally{if($session){[void](Invoke-JarvisCdp $client 'Target.detachFromTarget' @{sessionId=$session})}}
            $results+=,$result
        }
    $placement=$true;$visible=$true;$shownWindows=@{}
    foreach($result in $results|Where-Object target_id){
        $window=Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$result.target_id}
        if(-not $shownWindows.ContainsKey([string]$window.windowId)){
            if($voiceId){
                $listenerWindow=Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$voiceId}
                if($window.windowId -eq $listenerWindow.windowId){throw 'Workset must stay separate from the voice window.'}
            }
            $entries=@($script:worksetState.tabs|Where-Object {$_.target_id -and $_.target_id -in $results.target_id})
            $revealed=Show-JarvisWorkWindow $client $result.target_id $pids $workX $area.Y $workWidth $area.Height
            $shown=$revealed.visible
            $shownWindows[[string]$window.windowId]=$revealed
            if($shown){
                foreach($entry in $entries){
                    $entryWindow=Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$entry.target_id}
                    if($entryWindow.windowId -eq $window.windowId){$entry.window_id=$revealed.window_id;$entry.hwnd=$revealed.hwnd}
                }
            }
            if(-not $shown){$visible=$false}
        }
        $window=Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$result.target_id}
        $bounds=$window.bounds
        if($bounds.left -lt $area.Left -or $bounds.top -lt $area.Top -or
           ($bounds.left+$bounds.width) -gt $area.Right -or ($bounds.top+$bounds.height) -gt $area.Bottom -or $bounds.windowState -eq 'minimized'){$placement=$false}
        if($voiceId){
            $voiceWindow=Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$voiceId}
            if($window.windowId -eq $voiceWindow.windowId){throw 'Workset must stay separate from the voice window.'}
        }
    }
    Save-Worksets
    $ordered=@(foreach($tab in $workspace.tabs){$results|Where-Object id -eq $tab.id|Select-Object -First 1})
    @{workspace_id=$WorkspaceId;tabs=$ordered;windows=@($shownWindows.Values);visibility_verified=$visible;placement_verified=$placement;focus_kept=([JarvisWindowGuard]::Foreground() -eq $focusBefore)}|ConvertTo-Json -Depth 10 -Compress
}finally{
    if($guard){$guard.Dispose()}
    if($client){$client.socket.Dispose()}
    if($owned){$mutex.ReleaseMutex()}
    $mutex.Dispose()
    [JarvisWindowGuard]::RestoreCoordinates($dpiContext)
}
