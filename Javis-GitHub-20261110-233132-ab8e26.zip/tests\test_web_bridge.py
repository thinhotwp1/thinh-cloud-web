import concurrent.futures
from contextlib import nullcontext
import json
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from web_bridge import VoiceBridge, BridgeError

class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        (self.root/'state').mkdir()
        self.clock=[100.0]
        self.calls=[]
        self.started=threading.Event()
        self.release=threading.Event()
        outer=self
        class Runner:
            def __init__(self,on_event): self.on_event=on_event
            def run(self,text):
                outer.calls.append(text); outer.started.set(); outer.release.wait(3)
                self.on_event({'type':'item.completed','item':{'type':'agent_message','text':'Đã nhận: '+text}})
                return 'Đã nhận: '+text
            def cancel(self): outer.release.set()
        self.bridge=VoiceBridge(self.root,aliases=['davis'],runner_factory=Runner,
                                mutex_factory=nullcontext,clock=lambda:self.clock[0])
    def tearDown(self):
        self.release.set(); self.bridge.close(); self.temp.cleanup()
    def arm(self): return self.bridge.arm('Hey Davis')['grant']
    def wait_done(self,job):
        until=time.monotonic()+3
        while time.monotonic()<until:
            value=self.bridge.status(job['id'])
            if value['state'] in ('completed','failed','cancelled'): return value
            time.sleep(.01)
        self.fail('Job did not finish')
    def test_no_wake_no_request_and_grants_expire(self):
        with self.assertRaises(BridgeError): self.bridge.arm('Tôi gặp Davis hôm qua')
        with self.assertRaises(BridgeError): self.bridge.submit('r1','missing','open YouTube')
        grant=self.arm(); self.clock[0]+=61
        with self.assertRaises(BridgeError): self.bridge.submit('r1',grant,'open YouTube')
        self.assertEqual(self.calls,[])
    def test_unicode_once_only_retry_and_single_use_grant(self):
        grant=self.arm(); text='Mở YouTube bài Sóng Gió; $() "nguyên văn"'
        first=self.bridge.submit('r1',grant,text)
        self.assertEqual(self.bridge.submit('r1',grant,text)['id'],first['id'])
        with self.assertRaises(BridgeError): self.bridge.submit('r1',grant,'changed')
        with self.assertRaises(BridgeError): self.bridge.submit('r2',grant,text)
        self.release.set(); done=self.wait_done(first)
        self.assertEqual(done['state'],'completed'); self.assertIn('Sóng Gió',done['reply'])
        self.assertEqual(self.calls,[text])
    def test_concurrent_retry_executes_once_and_busy_rejects_next_job(self):
        grant=self.arm()
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            jobs=list(pool.map(lambda _:self.bridge.submit('r1',grant,'open YouTube'),range(6)))
        self.assertEqual(len({j['id'] for j in jobs}),1)
        self.assertTrue(self.started.wait(1))
        with self.assertRaises(BridgeError): self.bridge.arm('Hey Javis')
        self.assertEqual(self.calls,['open YouTube'])
    def test_disarm_stop_and_failure_do_not_silently_execute(self):
        grant=self.arm(); self.bridge.disarm()
        with self.assertRaises(BridgeError): self.bridge.submit('r1',grant,'task')
        self.bridge.close()
        with self.assertRaises(BridgeError): self.bridge.arm('Hey Jarvis')
        self.assertEqual(self.calls,[])
    def test_stale_disarm_does_not_invalidate_a_newer_wake(self):
        old=self.arm(); current=self.arm()
        self.bridge.disarm(old)
        self.release.set(); done=self.wait_done(self.bridge.submit('r1',current,'current task'))
        self.assertEqual(done['state'],'completed')
        self.assertEqual(self.calls,['current task'])
    def test_mutex_failure_is_visible_and_runner_not_called(self):
        class Locked:
            def __enter__(self): raise RuntimeError('Jarvis terminal already open')
            def __exit__(self,*a): pass
        self.bridge.mutex_factory=Locked
        first=self.bridge.submit('r1',self.arm(),'open YouTube')
        self.release.set(); done=self.wait_done(first)
        self.assertEqual(done['state'],'failed'); self.assertIn('already open',done['error'])
        self.assertEqual(self.calls,[])
    def test_close_cancels_worker_and_rejects_later_submission(self):
        first=self.bridge.submit('r1',self.arm(),'task'); self.assertTrue(self.started.wait(1))
        self.bridge.close()
        self.assertFalse(self.bridge.worker.is_alive())
        with self.assertRaises(BridgeError): self.bridge.submit('r2','none','task')
    def test_invalid_inputs_do_not_consume_a_valid_grant(self):
        grant=self.arm()
        for text in ('',42,'x'*9000):
            with self.assertRaises(BridgeError): self.bridge.submit('r1',grant,text)
        self.release.set(); self.wait_done(self.bridge.submit('r1',grant,'valid'))
        self.assertEqual(self.calls,['valid'])
    def test_local_utility_executes_once_without_constructing_codex_or_its_mutex(self):
        class NoCodex:
            def __enter__(self): raise AssertionError('Local action must not acquire the Codex session')
            def __exit__(self,*args): pass
        self.bridge.mutex_factory=NoCodex
        grant=self.arm()
        job=self.bridge.submit('local',grant,'Tính 2 + 3 * 4')
        done=self.wait_done(job)
        self.assertEqual(done['state'],'completed')
        self.assertEqual(done['reply'],'14')
        self.assertEqual(done['executor'],'local')
        self.assertEqual(self.bridge.submit('local',grant,'Tính 2 + 3 * 4')['reply'],'14')
        self.assertEqual(self.calls,[])
    def test_configured_fast_url_has_cancellation_state_in_bridge_worker(self):
        from unittest.mock import patch
        config=self.bridge.desktop.fast.list_actions()
        next(action for action in config['actions'] if action['id']=='today')['url']='http://localhost:47131/'
        self.bridge.desktop.fast.save(config)
        opened=[]
        def process(args,timeout,encoding):
            opened.append(args[-1])
            return type('Result',(),{'returncode':0,'stdout':json.dumps({'current_url':args[-1],'visibility_verified':True}),'stderr':''})()
        with patch.object(self.bridge.desktop,'_run_process',side_effect=process):
            result=self.wait_done(self.bridge.submit('fast-url',self.arm(),'mở công việc hôm nay'))
        self.assertEqual(result['outcome'],'success',result.get('error'))
        self.assertEqual(opened,['http://localhost:47131/'])
    def test_invalid_local_json_reports_result_without_codex_fallback(self):
        job=self.bridge.submit('badjson',self.arm(),'format json {')
        done=self.wait_done(job)
        self.assertEqual(done['state'],'completed')
        self.assertIn('JSON không hợp lệ',done['reply'])
        self.assertEqual(self.calls,[])
    def test_outcomes_history_and_summary_are_distinct(self):
        good=self.wait_done(self.bridge.submit('good',self.arm(),'calculate 2+2'))
        self.assertEqual(good['outcome'],'success')
        bad=self.wait_done(self.bridge.submit('bad',self.arm(),'format json {'))
        self.assertNotEqual(bad['outcome'],'success')
        self.release.set()
        summary=self.wait_done(self.bridge.submit('summary',self.arm(),'summarize today'))
        self.assertIn('HISTORICAL DATA',self.calls[-1])
        self.assertIn('good',self.calls[-1])
        self.assertEqual(summary['outcome'],'unknown')
        self.assertEqual(self.bridge.memory.get_job('good')['outcome'],'success')
    def test_saved_recipe_executes_locally_and_explicit_save_remembers_previous(self):
        self.bridge.recipes.save_recipe(dict(id='calc',name='Calculator',aliases=['my calculation'],executor='local',actions=[dict(type='calculate',expression='2+3')]),'user')
        first=self.wait_done(self.bridge.submit('recipe',self.arm(),'my calculation'))
        self.assertEqual(first['reply'],'5');self.assertEqual(first['recipe_version'],1)
        saved=self.wait_done(self.bridge.submit('save',self.arm(),'lưu tác vụ tính nhanh'))
        self.assertEqual(saved['outcome'],'success')
        self.assertIsNotNone(self.bridge.recipes.resolve_recipe('tính nhanh'))
        self.assertEqual(self.calls,[])
    def test_failed_memory_write_does_not_dispatch(self):
        from unittest.mock import patch
        import sqlite3
        with patch.object(self.bridge.memory,'begin_job',side_effect=sqlite3.OperationalError('disk full')):
            with self.assertRaises(BridgeError):self.bridge.submit('dbfail',self.arm(),'open anything')
        self.assertEqual(self.calls,[])
        self.assertIsNone(self.bridge.active)
    def test_observed_steps_are_durable_before_runner_finishes(self):
        outer=self
        class Stepping:
            def __init__(self,on_event):self.event=on_event
            def run(self,text):
                self.event({'type':'item.started','item':{'id':'cmd','type':'command_execution','command':'powershell.exe password=private'}})
                outer.started.set();outer.release.wait(2);return 'plain answer'
            def cancel(self):outer.release.set()
        self.bridge.runner_factory=Stepping
        job=self.bridge.submit('steps',self.arm(),'new task');self.assertTrue(self.started.wait(1))
        saved=self.bridge.memory.get_job(job['id'])
        self.assertTrue(saved['steps']);self.assertNotIn('private',json.dumps(saved))
        self.release.set();self.wait_done(job)
    def test_cancelled_job_stays_busy_until_worker_really_exits_and_can_listen_again(self):
        job=self.bridge.submit('cancel-me',self.arm(),'blocking task')
        self.assertTrue(self.started.wait(1))
        self.assertTrue(callable(getattr(self.bridge,'cancel',None)), 'Cancel endpoint is not implemented')
        self.bridge.cancel(job['id'])
        done=self.wait_done(job)
        self.assertEqual(done['state'],'cancelled')
        self.assertEqual(self.bridge.cancel(job['id'])['state'],'cancelled')
        self.assertIn('grant',self.bridge.arm('Hi Davis'))
    def test_cancellation_keeps_a_stubborn_worker_busy_and_does_not_cancel_newer_job(self):
        self.assertTrue(callable(getattr(self.bridge,'cancel',None)), 'Cancel endpoint is not implemented')
        self.bridge.runner_factory=lambda on_event:type('Stubborn',(),{
            'run':lambda _,text:(self.started.set(),self.release.wait(2),'late reply')[-1],
            'cancel':lambda _:None})()
        job=self.bridge.submit('slow',self.arm(),'blocking task')
        self.assertTrue(self.started.wait(1))
        self.assertEqual(self.bridge.cancel('slow')['state'],'cancelling')
        with self.assertRaises(BridgeError):self.bridge.arm('Hi Davis')
        self.release.set()
        self.assertEqual(self.wait_done(job)['state'],'cancelled')
        self.assertEqual(self.bridge.cancel('slow')['state'],'cancelled')
        self.release.clear();self.started.clear()
        newer=self.bridge.submit('newer',self.arm(),'next task')
        self.assertTrue(self.started.wait(1))
        self.bridge.cancel('slow')
        self.assertEqual(self.bridge.status('newer')['state'],'running')
        self.release.set()
        self.assertEqual(self.wait_done(newer)['state'],'completed')
        with self.assertRaises(BridgeError):self.bridge.cancel('missing')
    def test_cancel_after_runner_finalized_keeps_success_instead_of_claiming_cancelled(self):
        self.bridge.runner_factory=lambda on_event:type('Finalized',(),{
            'run':lambda _,text:(self.started.set(),self.release.wait(2),'already done')[-1],
            'cancel':lambda _:False})()
        job=self.bridge.submit('finalized',self.arm(),'task')
        self.assertTrue(self.started.wait(1))
        self.assertNotEqual(self.bridge.cancel('finalized')['state'],'cancelling')
        self.release.set()
        self.assertEqual(self.wait_done(job)['state'],'completed')

if __name__=='__main__': unittest.main()
