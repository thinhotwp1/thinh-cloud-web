"""Task-scoped owned browser receipts and non-navigating final visibility."""
import json
from pathlib import Path
import re
from datetime import datetime
from process_control import run_cancellable


def completed_browser_targets(root,event,not_before=None):
    item=event.get('item',{})
    if event.get('type')!='item.completed' or item.get('type')!='command_execution' or item.get('exit_code')!=0:return []
    command=re.sub('/+','/',str(item.get('command','')).replace('\\','/'))
    if re.search(r'(?i)(?:^|\s)-(?:VoicePage|NoReveal)\b',command):return []
    scripts=[(Path(root)/'tools'/name).as_posix() for name in ('Open-Chrome.ps1','Open-Workset.ps1')]
    if not any(re.search(r'''(?i)(?:^|\s)-File\s+["']?'''+re.escape(path)+r'''(?=["'\s]|$)''',command) for path in scripts):return []
    records=[]
    try:
        value=json.JSONDecoder().raw_decode(str(item.get('aggregated_output','')).lstrip()[:32000])[0]
        if isinstance(value,dict):records=[value]+(value.get('tabs',[]) if isinstance(value.get('tabs'),list) else [])
    except (ValueError,TypeError):pass
    # Page-controlled expression results are not helper receipts, even if they
    # contain target_id. Read the helper's private observation independently.
    if re.search(r'(?i)\s-Expression(?:File)?\b',command):
        records=[]
        try:
            path=Path(root)/'state/browser.json'
            if path.stat().st_size<=16384:
                value=json.loads(path.read_text(encoding='utf-8-sig'))
                observed=datetime.fromisoformat(value.get('observed_at','').replace('Z','+00:00'))
                if observed.tzinfo and (not not_before or observed>=datetime.fromisoformat(not_before)):
                    records=[value]
        except (OSError,ValueError,TypeError,AttributeError):pass
    result=[]
    for record in records:
        target=record.get('target_id') if isinstance(record,dict) else None
        if isinstance(target,str) and re.fullmatch('[A-Fa-f0-9]{32}',target) and target not in result:result.append(target)
    return result[-6:]


def reveal_completed_targets(root,targets,cancellation):
    result=run_cancellable(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',
        str(Path(root)/'tools/Reveal-WorkTarget.ps1'),'-TargetIds',','.join(targets)],cancellation,20,encoding='utf-8-sig')
    if result.returncode:raise RuntimeError((result.stderr or result.stdout)[-1000:])
    return json.loads(result.stdout)
