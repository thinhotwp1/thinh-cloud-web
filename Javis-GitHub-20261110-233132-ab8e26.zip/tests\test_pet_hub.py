import tempfile
import threading
import unittest
from pathlib import Path
from pet_hub import PetHub
from audio_service import AudioService


class PetTests(unittest.TestCase):
    def test_typed_quick_buttons_are_allowed_but_arbitrary_keyboard_action_is_not(self):
        hub=PetHub();lease=hub.claim_listener('listener')
        for action in ('quick_screenshot','quick_lock','quick_screens_off'):
            hub.enqueue_control(action,action,{})
        self.assertEqual([item['action'] for item in hub.poll_controls(lease)],['quick_screenshot','quick_lock','quick_screens_off'])
        with self.assertRaises(ValueError):hub.enqueue_control('keys','press_keys',{'keys':'Win+L'})
    def test_leases_sequences_control_ack_ttl_and_health(self):
        now=[0.0];hub=PetHub(clock=lambda:now[0])
        lease=hub.claim_listener('one')
        hub.publish(lease,1,{'phase':'wake','listening':True,'heard':'hello'})
        self.assertTrue(hub.snapshot()['listener_connected'])
        with self.assertRaises(ValueError):hub.publish(lease,1,{})
        hub.enqueue_control('c','mic_off',{})
        self.assertEqual(len(hub.poll_controls(lease)),1)
        hub.enqueue_control('c','mic_off',{})
        hub.ack_control(lease,'c');self.assertEqual(hub.poll_controls(lease),[])
        new=hub.claim_listener('two')
        with self.assertRaises(ValueError):hub.publish(lease,2,{})
        hub.enqueue_control('late','mic_on',{})
        now[0]=11
        self.assertEqual(hub.poll_controls(new),[])
        self.assertFalse(hub.snapshot()['listener_connected'])
        with self.assertRaises(ValueError):hub.enqueue_control('x','shell',{})

    def test_audio_dedup_and_stopped_generation_does_not_play(self):
        calls=[]
        with tempfile.TemporaryDirectory() as tmp:
            audio=AudioService(Path(tmp),player=lambda p,event:calls.append(p.name))
            self.assertTrue(audio.play('one','yes','g'))
            self.assertFalse(audio.play('one','yes','g'))
            audio.stop('g')
            self.assertFalse(audio.play('two','done','g'))
            self.assertEqual(calls,['yes.wav'])
            with self.assertRaises(ValueError):audio.play('three','../../private','new')
