param([switch]$Describe, [switch]$InitializeOnly)
$ErrorActionPreference = 'Stop'
$OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$root = $PSScriptRoot
$statePath = Join-Path $root 'state\session.json'
$candidate = Get-ChildItem -LiteralPath (Join-Path $env:USERPROFILE '.vscode\extensions') -Directory |
    Where-Object Name -Like 'openai.chatgpt-*-win32-x64' |
    Sort-Object LastWriteTime -Descending |
    ForEach-Object { Join-Path $_.FullName 'bin\windows-x86_64\codex.exe' } |
    Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $candidate) { throw 'Installed Codex CLI not found. Install/sign in to the Codex extension manually.' }
$common = @('-C', $root, '-s', 'danger-full-access', '-a', 'never')
$sessionId = $null
if (Test-Path -LiteralPath $statePath) {
    $session = Get-Content -Raw -Encoding UTF8 -LiteralPath $statePath | ConvertFrom-Json
    $sessionId = [string]$session.thread_id
    $parsed = [guid]::Empty
    if (-not [guid]::TryParse($sessionId, [ref]$parsed)) { throw 'Invalid saved session ID. Keep session.json for diagnosis; do not silently create a new conversation.' }
}
if ($Describe) {
    [pscustomobject]@{
        Executable = $candidate
        WorkingDirectory = $root
        SessionId = $sessionId
        Arguments = $common + $(if ($sessionId) { @('resume', $sessionId, '--no-alt-screen', '--no-daemon') } else { @('exec', '--json', '--skip-git-repo-check', '-') })
        GlobalConfigEdited = $false
        InputMode = 'text'
        NativeVoiceVerified = $false
    } | ConvertTo-Json -Depth 4
    exit 0
}
$mutex = New-Object System.Threading.Mutex($false, 'Local\JarvisNativeCodexTerminal')
$ownsMutex = $false
try {
    try { $ownsMutex = $mutex.WaitOne(0) } catch [System.Threading.AbandonedMutexException] { $ownsMutex = $true }
    if (-not $ownsMutex) { throw 'Jarvis Codex is already running. Use the existing Jarvis terminal.' }
    Set-Location -LiteralPath $root
    if (-not $sessionId) {
        Write-Host 'Creating the dedicated Jarvis session (no desktop task will run)...' -ForegroundColor Cyan
        $bootstrap = 'Bootstrap only. The workspace instructions are already provided in AGENTS.md. Do not inspect additional files, run desktop tasks, open applications, execute commands, or modify files. Reply exactly JARVIS_READY.'
        $previousPreference = $ErrorActionPreference
        try {
            # Windows PowerShell treats redirected native stderr as ErrorRecords,
            # even when a CLI succeeds. Decide from its actual process exit code.
            $ErrorActionPreference = 'Continue'
            $lines = @($bootstrap | & $candidate @common exec --json --skip-git-repo-check - 2> (Join-Path $root 'state\bootstrap-stderr.log'))
            $exitCode = $LASTEXITCODE
        } finally { $ErrorActionPreference = $previousPreference }
        $lines | Set-Content -LiteralPath (Join-Path $root 'state\bootstrap-events.jsonl') -Encoding UTF8
        foreach ($line in $lines) {
            try { $event = $line | ConvertFrom-Json } catch { continue }
            if ($event.type -eq 'thread.started') { $sessionId = [string]$event.thread_id }
        }
        # Persist a created session even if the first turn fails; never create duplicates on retries.
        if ($sessionId) {
            [pscustomobject]@{ thread_id=$sessionId; cwd=$root; created_at=(Get-Date -Format o) } |
                ConvertTo-Json | Set-Content -LiteralPath $statePath -Encoding UTF8
        }
        if ($exitCode -ne 0 -or -not $sessionId) {
            throw 'Codex initialization failed. Inspect state/bootstrap-events.jsonl and state/bootstrap-stderr.log. No new conversation will be silently substituted.'
        }
    }
    Write-Host "JARVIS SESSION: $sessionId" -ForegroundColor Green
    Write-Host 'Full Access applies to this process only. Global configuration is unchanged.' -ForegroundColor Yellow
    if ($InitializeOnly) { exit 0 }
    Write-Host 'TEXT INPUT READY. This installed CLI does not recognize /voice; F8 voice is not verified.' -ForegroundColor Cyan
    Write-Host 'This is the text-only fallback. For Chrome microphone input run the Jarvis: Talk to Codex task.' -ForegroundColor Yellow
    Write-Host 'No microphone is being recorded by this text launcher.' -ForegroundColor Yellow
    # The extension ships an executable without the standalone daemon package.
    # Keep the interactive runtime in this terminal instead of spawning a daemon.
    & $candidate @common resume $sessionId --no-alt-screen --no-daemon
    if ($LASTEXITCODE -ne 0) { throw "Codex exited with code $LASTEXITCODE" }
} finally {
    if ($ownsMutex) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
}
