"""Ephemeral listener lease and finite, idempotent desktop controls."""
from collections import OrderedDict
import json
import secrets
import threading
import time


class PetHub:
    ACTIONS={'mic_on','mic_off','cancel_current','show_details','show_pet','stop_speaking','sound_on','sound_off','summary','read_result','send_now','quick_screenshot','quick_lock','quick_screens_off'}
    def __init__(self,clock=time.monotonic):
        self.clock=clock;self.lock=threading.RLock();self.lease='';self.owner='';self.seq=-1
        self.seen=-100;self.native_seen=-100;self.value={};self.commands=OrderedDict();self.acked=OrderedDict()
        self.sound_enabled=True
        self.control_error=''
    def claim_listener(self,client_id):
        if not isinstance(client_id,str) or not 1<=len(client_id)<=100:raise ValueError('Invalid listener')
        with self.lock:
            if client_id!=self.owner:
                self.owner=client_id;self.lease=secrets.token_urlsafe(24);self.seq=-1;self.commands.clear();self.value={}
            return self.lease
    def _check(self,lease):
        if not isinstance(lease,str) or not self.lease or not secrets.compare_digest(lease,self.lease):raise ValueError('Listener replaced; reload the voice page')
    def publish(self,lease,seq,snapshot):
        with self.lock:
            self._check(lease)
            if type(seq)!=int or seq<=self.seq:raise ValueError('Stale snapshot')
            if not isinstance(snapshot,dict) or len(json.dumps(snapshot).encode())>8000:raise ValueError('Invalid snapshot')
            self.value={k:str(snapshot.get(k,''))[:700] for k in ('phase','status','heard','request','error','epoch')}
            self.value.update(listening=snapshot.get('listening') is True,wants_mic=snapshot.get('wants_mic') is True)
            self.value['dialogue_pending']=snapshot.get('dialogue_pending') is True
            self.seq=seq;self.seen=self.clock()
    def snapshot(self,native=False):
        with self.lock:
            if native:self.native_seen=self.clock()
            return {**self.value,'listener_connected':self.clock()-self.seen<5,'native_connected':self.clock()-self.native_seen<3,'sound_enabled':self.sound_enabled,'control_error':self.control_error}
    def enqueue_control(self,identifier,action,payload):
        if action not in self.ACTIONS or not isinstance(identifier,str) or not 1<=len(identifier)<=100:raise ValueError('Invalid control')
        if not isinstance(payload,dict) or len(json.dumps(payload).encode())>1000:raise ValueError('Invalid control payload')
        with self.lock:
            self.control_error=''
            if identifier not in self.acked and identifier not in self.commands:
                if len(self.commands)>=20:raise ValueError('Control queue busy')
                self.commands[identifier]={'id':identifier,'action':action,'payload':payload,'expires':self.clock()+10}
    def poll_controls(self,lease):
        with self.lock:
            self._check(lease)
            for identifier in list(self.commands):
                if self.commands[identifier]['expires']<=self.clock():self.commands.pop(identifier)
            return [{k:v for k,v in c.items() if k!='expires'} for c in self.commands.values()]
    def ack_control(self,lease,identifier):
        with self.lock:
            self._check(lease);self.commands.pop(identifier,None);self.acked[identifier]=True
            while len(self.acked)>100:self.acked.popitem(last=False)
