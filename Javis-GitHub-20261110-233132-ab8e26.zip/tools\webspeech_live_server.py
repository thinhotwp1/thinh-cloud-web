"""Authenticated loopback bridge for the user-approved Chrome voice executor."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse
import base64
import json
import os
import secrets
import sys
import threading
from urllib.parse import urlsplit, unquote, parse_qs

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from web_bridge import VoiceBridge, BridgeError
from pet_hub import PetHub
from audio_service import AudioService
import sqlite3


def make_server(root=ROOT,port=8766,bridge=None):
    if port not in (0,8766):
        raise ValueError('Production voice execution is reserved for port 8766; diagnostic origins cannot execute.')
    root=Path(root)
    config=json.loads((root/'voice-config.json').read_text(encoding='utf-8-sig'))
    config_lock=threading.RLock()
    bridge=bridge or VoiceBridge(root,aliases=config.get('wake_aliases'))
    token=secrets.token_urlsafe(32)
    pet=PetHub();audio=AudioService(root)

    class Handler(BaseHTTPRequestHandler):
        def reply(self,status,body,kind='application/json'):
            if not isinstance(body,bytes):
                body=json.dumps(body,ensure_ascii=False).encode('utf-8')
            self.send_response(status)
            for key,value in {'Content-Type':kind if kind.startswith('audio/') else kind+'; charset=utf-8','Content-Length':str(len(body)),
                'Cache-Control':'no-store','X-Content-Type-Options':'nosniff',
                'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'",
                'Permissions-Policy':'microphone=(self)'}.items():
                self.send_header(key,value)
            self.end_headers()
            self.wfile.write(body)

        def check(self,authenticated=False,post=False):
            origin=f'http://127.0.0.1:{self.server.server_port}'
            if self.headers.get('Host')!=f'127.0.0.1:{self.server.server_port}':
                raise BridgeError('Invalid host.',403)
            supplied=self.headers.get('Origin')
            if (post and supplied!=origin) or (supplied and supplied!=origin):
                raise BridgeError('Invalid origin.',403)
            if self.headers.get('Sec-Fetch-Site')=='cross-site':
                raise BridgeError('Cross-site requests are not allowed.',403)
            if authenticated:
                received=self.headers.get('X-Jarvis-Token','')
                if not received.isascii() or not secrets.compare_digest(received,token):
                    raise BridgeError('Invalid session token. Reload the voice page.',403)

        def do_GET(self):
            try:
                route=urlsplit(self.path).path
                self.check(authenticated=route.startswith('/api/'))
                if route=='/health':
                    self.reply(200,{'app':'jarvis-webspeech-live','server_id':self.server.identity,'pid':os.getpid()})
                elif route=='/config':
                    clip=root/'webspeech-probe/yes.wav'
                    ready_audio=base64.b64encode(clip.read_bytes()).decode('ascii') if clip.is_file() and clip.stat().st_size<=256000 else None
                    self.reply(200,{'execution_enabled':True,'csrf_token':token,'wake_aliases':config.get('wake_aliases',[]),
                                    'native_pet':(root/'desktop/PetHost.cs').is_file(),
                                    'ready_audio':ready_audio,
                                    'mode':'live','session_id':self.server.session_id,
                                    'silence_ms':int(config.get('webspeech_silence_seconds',10)*1000),
                                    'reasoning_effort':bridge.reasoning_effort})
                elif route=='/api/pet/state':
                    value=pet.snapshot(native=True)
                    with bridge.lock:
                        bridge._expire_pending_if_needed()
                        latest=(bridge.jobs.get(bridge.pending_id) if bridge.pending_id else None) or (bridge.jobs.get(bridge.active) if bridge.active else None) or (next(reversed(bridge.jobs.values()),None) if bridge.jobs else None)
                        value['job']=({k:bridge._public(latest).get(k) for k in ('id','state','outcome','text','error')} if latest else None)
                        if value['job']:
                            value['job']['text']=str(value['job'].get('text',''))[:500]
                            value['job']['error']=str(value['job'].get('error',''))[:500]
                            value['job']['current_step']=latest.get('steps',[{}])[-1].get('label','') if latest.get('steps') else ''
                    self.reply(200,value)
                elif route=='/api/recipes':
                    self.reply(200,{'recipes':bridge.recipes.list_recipes()})
                elif route=='/api/state':
                    with bridge.lock:
                        active=bridge.active
                    self.reply(200,{'active':bridge.status(active) if active else None})
                elif route=='/api/workspaces':
                    try:
                        self.reply(200,{'workspaces':bridge.desktop.catalog()})
                    except (ValueError,OSError) as error:
                        raise BridgeError('Workspace configuration: '+str(error),400)
                elif route=='/api/fast-actions':
                    self.reply(200,bridge.desktop.fast.list_actions())
                elif route=='/api/work/goals':
                    self.reply(200,{'goals':bridge.work.list_goals()})
                elif route=='/api/work/policy':
                    source=parse_qs(urlsplit(self.path).query).get('source',[''])[0]
                    self.reply(200,{'source':source,'allow_ai':bridge.work.ai_allowed(source)})
                elif route=='/api/work/decisions':
                    query=parse_qs(urlsplit(self.path).query)
                    source=query.get('source',[''])[0];item_id=query.get('item_id',[''])[0]
                    if not source or not item_id:raise BridgeError('Source and item ID required',400)
                    self.reply(200,{'decisions':bridge.work.list_decisions(source,item_id)})
                elif route.startswith('/api/jobs/'):
                    self.reply(200,bridge.status(unquote(route[len('/api/jobs/'):])) )
                elif route.startswith('/api/questions/'):
                    try:self.reply(200,bridge.dialogue.get(unquote(route[len('/api/questions/'):])) )
                    except ValueError as error:raise BridgeError(str(error),404)
                elif route in ('/','/app.js','/speech.js','/style.css','/yes.wav','/done.wav'):
                    name,kind={'/':('index.html','text/html'),'/app.js':('app.js','text/javascript'),
                               '/speech.js':('speech.js','text/javascript'),'/style.css':('style.css','text/css'),'/yes.wav':('yes.wav','audio/wav'),'/done.wav':('done.wav','audio/wav')}[route]
                    self.reply(200,(root/'webspeech-probe'/name).read_bytes(),kind)
                else:
                    raise BridgeError('Not found.',404)
            except BridgeError as error:
                self.reply(error.status,{'error':str(error)})
            except (ValueError,sqlite3.Error) as error:self.reply(400,{'error':str(error)})

        def do_POST(self):
            body_read=False
            try:
                self.check(authenticated=True,post=True)
                if self.headers.get('Content-Type','').split(';')[0].strip()!='application/json':
                    raise BridgeError('JSON content type required.',415)
                try: length=int(self.headers.get('Content-Length','-1'))
                except ValueError: raise BridgeError('Invalid content length.',400)
                if not 0<length<=16384:
                    # Drain a small rejected body before replying so Windows does
                    # not reset the connection with unread incoming bytes.
                    if 0<length<=65536:
                        self.connection.settimeout(5)
                        body_read=True
                        self.rfile.read(length)
                    raise BridgeError('Request body must be at most 16384 bytes.',413)
                self.connection.settimeout(5)
                body_read=True
                try: data=json.loads(self.rfile.read(length).decode('utf-8'))
                except (ValueError,UnicodeError,TimeoutError): raise BridgeError('Invalid JSON request.',400)
                if not isinstance(data,dict): raise BridgeError('JSON object required.',400)
                route=urlsplit(self.path).path
                if route=='/api/arm':
                    self.reply(200,bridge.arm(data.get('wake')))
                elif route=='/api/disarm':
                    bridge.disarm(data.get('grant'))
                    self.reply(200,{'ok':True})
                elif route=='/api/requests':
                    self.reply(202,bridge.submit(data.get('request_id'),data.get('grant'),data.get('text')))
                elif route=='/api/local-actions':
                    self.reply(202,bridge.submit_fast_action(data.get('request_id'),data.get('grant'),data.get('action_id')))
                elif route=='/api/pet/claim':
                    with pet.lock:
                        if pet.owner and pet.owner!=data.get('client_id'):
                            bridge.dismiss_question();bridge.dismiss_busy()
                        self.reply(200,{'lease':pet.claim_listener(data.get('client_id'))})
                elif route in ('/api/busy/arm','/api/busy/replace','/api/busy/cancel'):
                    with pet.lock:
                        try:pet._check(data.get('lease'))
                        except ValueError as error:raise BridgeError(str(error))
                        target=data.get('active_job_id')
                        if route=='/api/busy/arm':self.reply(200,bridge.arm_busy(data.get('wake'),pet.lease,target))
                        elif route=='/api/busy/replace':self.reply(202,bridge.replace(data.get('request_id'),data.get('grant'),pet.lease,target,data.get('text')))
                        else:
                            with bridge.lock:
                                if not target or target not in (bridge.active,bridge.pending_id):raise BridgeError('Current task changed; cancel was not applied')
                            self.reply(200,bridge.cancel(target))
                elif route.startswith('/api/questions/'):
                    parts=route.split('/')
                    if len(parts)!=5:raise BridgeError('Invalid question route',404)
                    identifier,action=unquote(parts[3]),parts[4]
                    with pet.lock:
                        try:pet._check(data.get('lease'))
                        except ValueError as error:raise BridgeError(str(error))
                        if action=='arm':self.reply(200,bridge.arm_answer(identifier,pet.lease))
                        elif action=='answer':self.reply(202,bridge.submit_answer(identifier,data.get('request_id'),data.get('grant'),pet.lease,data.get('text')))
                        elif action=='dismiss':bridge.dismiss_question(identifier);self.reply(200,{'ok':True})
                        else:raise BridgeError('Invalid question action',404)
                elif route=='/api/pet/publish':
                    pet.publish(data.get('lease'),data.get('seq'),data.get('snapshot'))
                    for identifier in data.get('ack',[])[:20]:pet.ack_control(data.get('lease'),identifier)
                    self.reply(200,{'controls':pet.poll_controls(data.get('lease')),'native_connected':pet.snapshot()['native_connected'],'sound_enabled':pet.sound_enabled})
                elif route=='/api/pet/control':
                    action=data.get('action');payload=data.get('payload',{})
                    if action in ('mic_off','stop_speaking','sound_off','cancel_current'):
                        bridge.dismiss_question();bridge.dismiss_busy()
                    if action=='cancel_current' and payload.get('job_id'):
                        with bridge.lock:
                            if payload['job_id'] not in (bridge.active,bridge.pending_id):raise BridgeError('Current task changed; cancel was not applied.')
                        bridge.cancel(payload['job_id'])
                    else:pet.enqueue_control(data.get('id'),action,payload)
                    if action in ('sound_off','sound_on'):
                        pet.sound_enabled=action=='sound_on'
                        if not pet.sound_enabled:audio.stop()
                    if action=='stop_speaking':audio.stop()
                    if action=='show_details':
                        import subprocess,threading
                        def show_details():
                            try:
                                result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(root/'tools/Show-VoiceDetails.ps1')],capture_output=True,timeout=25,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                                if result.returncode:raise ValueError(result.stderr.decode('utf-8',errors='replace')[-300:])
                            except Exception as error:
                                with pet.lock:pet.control_error='Không mở được Chi tiết: '+str(error)[:300]
                        threading.Thread(target=show_details,daemon=True).start()
                    if action=='show_pet':
                        import subprocess
                        subprocess.Popen(['powershell.exe','-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',str(root/'Start-Pet.ps1'),'-PetHost'],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                    self.reply(200,{'ok':True})
                elif route=='/api/pet/audio/stop':
                    audio.stop(data.get('generation'));self.reply(200,{'ok':True})
                elif route=='/api/pet/audio':
                    cue=data.get('clip');cue_id=data.get('cue_id');job_id=data.get('job_id')
                    if cue=='done' and data.get('preview') is not True:
                        job=bridge.status(job_id)
                        if job.get('outcome')!='success' or job['state']!='completed' or job.get('response_kind','action')!='action':raise BridgeError('No verified action success to announce.')
                        if not bridge.memory.claim_notification(job_id,'done'):
                            self.reply(200,{'played':False});return
                        cue_id='done:'+job_id
                    if not pet.sound_enabled:self.reply(200,{'played':False});return
                    self.reply(200,{'played':audio.play(cue_id,cue,data.get('generation'),gain=data.get('gain',1))})
                elif route=='/api/recipes/save':
                    definition=data.get('definition')
                    value=bridge.recipes.save_recipe(definition,'user-ui:'+str(data.get('id',''))) if definition else bridge.recipes.save_previous(data.get('name'),data.get('job_id'))
                    self.reply(200,value)
                elif route=='/api/fast-actions/save':
                    self.reply(200,bridge.desktop.fast.save(data.get('config')))
                elif route=='/api/voice-settings':
                    seconds=data.get('silence_seconds')
                    if type(seconds) is not int or not 5<=seconds<=20:
                        raise BridgeError('Silence must be an integer from 5 to 20 seconds.',400)
                    with config_lock:
                        updated={**config,'webspeech_silence_seconds':seconds}
                        path=root/'voice-config.json';temporary=path.with_suffix('.json.tmp')
                        temporary.write_text(json.dumps(updated,ensure_ascii=False,indent=2),encoding='utf-8')
                        os.replace(temporary,path)
                        config.update(updated)
                    self.reply(200,{'silence_seconds':seconds})
                elif route=='/api/work/import':
                    self.reply(200,bridge.work.import_items(data.get('source'),data.get('items')))
                elif route=='/api/work/policy':
                    self.reply(200,bridge.work.set_ai_permission(data.get('source'),data.get('allow_ai')))
                elif route=='/api/work/goal':
                    self.reply(200,bridge.work.save_goal(data.get('name'),data.get('criteria'),'user',data.get('item_id')))
                elif route=='/api/work/goal/delete':
                    bridge.work.delete_goal(data.get('id'));self.reply(200,{'ok':True})
                elif route=='/api/work/decision':
                    self.reply(200,bridge.work.save_decision(data.get('source'),data.get('item_id'),data.get('note'),'user'))
                elif route=='/api/work/decision/delete':
                    bridge.work.delete_decision(data.get('id'));self.reply(200,{'ok':True})
                elif route=='/api/recipes/enable':
                    bridge.recipes.set_recipe_enabled(data.get('id'),data.get('enabled'));self.reply(200,{'ok':True})
                elif route=='/api/recipes/restore':
                    self.reply(200,bridge.recipes.restore_recipe_version(data.get('id'),data.get('version'),'user-ui-restore'))
                elif route.startswith('/api/jobs/') and route.endswith('/cancel'):
                    request_id=unquote(route[len('/api/jobs/'):-len('/cancel')])
                    self.reply(200,bridge.cancel(request_id))
                else: raise BridgeError('Not found.',404)
            except BridgeError as error:
                if not body_read:
                    # Early authorization/type failures also leave a POST body.
                    # Drain only a small bounded body, preventing Windows RSTs.
                    try:
                        remaining=int(self.headers.get('Content-Length','0'))
                        if 0<remaining<=65536:
                            self.connection.settimeout(.5);self.rfile.read(remaining)
                    except (ValueError,OSError):pass
                self.reply(error.status,{'error':str(error)})
            except (ValueError,sqlite3.Error,TypeError) as error:self.reply(400,{'error':str(error)})

        def log_message(self,*args): pass

    server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    server.daemon_threads=True
    server.bridge=bridge
    server.pet=pet;server.audio=audio
    server.identity=secrets.token_hex(16)
    session_file=root/'state/session.json'
    server.session_id=json.loads(session_file.read_text(encoding='utf-8-sig'))['thread_id'] if session_file.exists() else ''
    return server


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--port',type=int,default=8766)
    args=parser.parse_args()
    if args.port!=8766:
        parser.error('Production voice execution must use port 8766.')
    if not (ROOT/'state/session.json').is_file():
        raise RuntimeError('Saved Codex session missing. Initialize with Start-Codex.ps1 -InitializeOnly first.')
    server=make_server(port=args.port)
    state=ROOT/'state/webspeech-live.json'
    temporary=state.with_suffix('.tmp')
    temporary.write_text(json.dumps({'url':f'http://127.0.0.1:{args.port}/','port':args.port,
                                     'pid':os.getpid(),'server_id':server.identity}),encoding='utf-8')
    os.replace(temporary,state)
    print(f'LIVE CODEX VOICE: http://127.0.0.1:{args.port}/ | session={server.session_id}',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        server.bridge.close()
        server.server_close()

if __name__=='__main__': main()
