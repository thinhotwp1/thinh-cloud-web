const assert=require('node:assert/strict');
const {setup,flush}=require('./check-webspeech-ui.cjs');

async function capture(seconds){
  const app=setup({silenceMs:seconds*1000});await flush();
  assert.equal(Number(app.node('silence-seconds').value),seconds);
  await app.node('start').onclick();app.instances.at(-1).final('Hey Javis');await flush();
  const speech=app.instances.at(-1);speech.final('open dashboard');speech.onspeechend();
  await app.advance(seconds*1000-1);assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);
  await app.advance(1);assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,1);
  app.stop();
}
(async()=>{
  await capture(5);await capture(20);
  const app=setup({silenceMs:10000});await flush();
  app.node('silence-seconds').value='15';await app.node('silence-save').onclick();
  assert.equal(app.calls.find(c=>c.path==='/api/voice-settings').body.silence_seconds,15);
  assert.equal(app.node('silence-status').textContent.includes('15'),true);
  console.log('PASS: configurable 5–20 second silence and live save.');
})().catch(error=>{console.error(error);process.exitCode=1;});
