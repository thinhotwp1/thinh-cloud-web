"""Isolated real-browser UI + HTTP + fake CLI cancellation; never real Codex."""
from contextlib import nullcontext
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'tools')]
from voice_core import CodexRunner
from web_bridge import VoiceBridge
from webspeech_live_server import make_server

with tempfile.TemporaryDirectory() as temporary:
    fixture=Path(temporary)
    (fixture/'state').mkdir()
    (fixture/'webspeech-probe').mkdir()
    shutil.copy2(ROOT/'voice-config.json',fixture/'voice-config.json')
    for name in ('app.js','speech.js','index.html','style.css','yes.wav'):
        shutil.copy2(ROOT/'webspeech-probe'/name,fixture/'webspeech-probe'/name)
    (fixture/'state/session.json').write_text(json.dumps({'thread_id':'11111111-2222-4333-8444-555555555555'}))
    cli=fixture/'fake_cli.py'
    cli.write_text('import pathlib,sys,time\nsys.stdin.read()\npathlib.Path("started").touch()\ntime.sleep(60)\n',encoding='utf-8')
    bridge=VoiceBridge(fixture,runner_factory=lambda on_event:CodexRunner(fixture,cli=[sys.executable,str(cli)],on_event=on_event),mutex_factory=nullcontext)
    server=make_server(fixture,0,bridge)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',
                               str(ROOT/'tests/check-compact-controls.ps1'),'-FixtureUrl',f'http://127.0.0.1:{server.server_port}/',
                               '-GuardRoot',str(fixture/'guard')],
                              capture_output=True,encoding='utf-8-sig',errors='replace',timeout=45)
        print(result.stdout.strip())
        assert result.returncode==0,result.stderr
        assert any(job['state']=='cancelled' for job in bridge.jobs.values())
    finally:
        bridge.close();server.shutdown();server.server_close();thread.join()
