"""Explicit, versioned ways of working. Exact aliases only; no shell replay."""
import json
import re
import sqlite3
import uuid
from desktop_tasks import normalized, calculate
from execution_result import ExecutionResult, clean


class RecipeMemory:
    def __init__(self,memory):self.memory=memory

    @staticmethod
    def validate(definition):
        value=json.loads(json.dumps(definition,ensure_ascii=False))
        if len(json.dumps(value).encode())>12000:raise ValueError('Recipe too large')
        if not re.fullmatch(r'[a-z][a-z0-9-]{0,63}',value.get('id','')):raise ValueError('Invalid recipe ID')
        if not isinstance(value.get('name'),str) or not 1<=len(value['name'].strip())<=100:raise ValueError('Recipe name required')
        aliases=value.get('aliases',[])
        if not isinstance(aliases,list) or not 1<=len(aliases)<=20 or any(not isinstance(a,str) or not 1<=len(a.strip())<=120 for a in aliases):raise ValueError('Aliases required')
        if len({normalized(a) for a in aliases})!=len(aliases):raise ValueError('Duplicate alias')
        if value.get('executor')=='codex':
            if not isinstance(value.get('instructions'),str) or not 1<=len(value['instructions'])<=4000:raise ValueError('Instructions required')
        elif value.get('executor')=='local':
            actions=value.get('actions')
            if not isinstance(actions,list) or not 1<=len(actions)<=10:raise ValueError('1-10 actions required')
            for a in actions:
                if not isinstance(a,dict):raise ValueError('Invalid action')
                kind=a.get('type');fields={'open_workset':'workspace_id','check_port':'port','calculate':'expression',
                    'format_json':'json','read_logs':'workspace_id','time':'place'}
                if kind not in fields or set(a)!={'type',fields[kind]}:raise ValueError('Unsupported action/fields')
                p=a[fields[kind]]
                if kind in ('open_workset','read_logs') and (not isinstance(p,str) or not re.fullmatch('[a-z][a-z0-9-]{0,31}',p)):raise ValueError('Invalid workspace')
                if kind=='check_port' and (type(p)!=int or not 1<=p<=65535):raise ValueError('Invalid port')
                if kind=='calculate':calculate(p)
                if kind=='format_json':json.loads(p)
                if kind=='time' and p not in ('vietnam','japan','utc'):raise ValueError('Invalid place')
        else:raise ValueError('Unsupported executor')
        value['checks']=clean(value.get('checks'),1000)
        return value

    def save_recipe(self,definition,user_request_id):
        if not isinstance(user_request_id,str) or not 1<=len(user_request_id)<=120:raise ValueError('Explicit user save source required')
        value=self.validate(definition)
        with self.memory.connection() as db:
            old=db.execute('SELECT version FROM recipes WHERE id=?',(value['id'],)).fetchone()
            value['version']=(old[0]+1) if old else 1
            value['enabled']=True
            for alias in value['aliases']:
                collision=db.execute('SELECT recipe_id FROM recipe_aliases WHERE alias=?',(normalized(alias),)).fetchone()
                if collision and collision[0]!=value['id']:raise ValueError('Alias already belongs to another recipe')
            body=json.dumps(value,ensure_ascii=False)
            db.execute('INSERT INTO recipes VALUES(?,?,1,?) ON CONFLICT(id) DO UPDATE SET version=excluded.version,enabled=1,definition=excluded.definition', (value['id'],value['version'],body))
            db.execute('INSERT INTO recipe_versions VALUES(?,?,?,?)',(value['id'],value['version'],body,user_request_id))
            db.execute('DELETE FROM recipe_aliases WHERE recipe_id=?',(value['id'],))
            for alias in value['aliases']:db.execute('INSERT INTO recipe_aliases VALUES(?,?)',(normalized(alias),value['id']))
        return value

    def resolve_recipe(self,text):
        with self.memory.connection() as db:
            row=db.execute('SELECT r.definition FROM recipes r JOIN recipe_aliases a ON r.id=a.recipe_id WHERE a.alias=? AND r.enabled=1',(normalized(text),)).fetchone()
            return json.loads(row[0]) if row else None

    def list_recipes(self):
        with self.memory.connection() as db:
            return [{**json.loads(body),'enabled':bool(enabled)} for body,enabled in db.execute('SELECT definition,enabled FROM recipes ORDER BY id')]

    def set_recipe_enabled(self,identifier,enabled):
        if type(enabled)!=bool:raise ValueError('enabled must be boolean')
        with self.memory.connection() as db:
            if db.execute('UPDATE recipes SET enabled=? WHERE id=?',(int(enabled),identifier)).rowcount!=1:raise ValueError('Recipe not found')

    def restore_recipe_version(self,identifier,version,source):
        with self.memory.connection() as db:
            row=db.execute('SELECT definition FROM recipe_versions WHERE recipe_id=? AND version=?',(identifier,version)).fetchone()
        if not row:raise ValueError('Version not found')
        return self.save_recipe(json.loads(row[0]),source)

    def save_previous(self,name,job_id=None):
        if not isinstance(name,str) or not 1<=len(name.strip())<=100:raise ValueError('Tên cách làm cần từ 1 đến 100 ký tự.')
        if job_id:
            previous=self.memory.get_job(job_id)
        else:
            rows=json.loads(self.memory.summary_context('last task'))
            previous=rows[0] if rows else None
        if not previous or previous.get('outcome')!='success':raise ValueError('Chưa có kết quả thành công đã xác nhận để lưu; hãy chọn cách làm cụ thể.')
        previous=self.memory.get_job(previous['id'])
        # Preserve typed local actions when known; other explicit saves use Codex
        # instructions rather than attempting to replay abbreviated shell events.
        original=previous.get('text','')
        from desktop_tasks import normalized
        match=re.fullmatch(r'(?:open workspace|mo bo(?: cong viec)?|bat dau (?:ngay )?lam viec)(?: (.+))?',normalized(original))
        recipe=dict(id='saved-'+uuid.uuid4().hex[:12],name=name.strip(),aliases=[name.strip()],executor='codex',
            instructions=clean(original,1800)+'\nObserved steps (reference only; verify current state):\n'+clean(json.dumps(previous.get('steps',[])[-5:],ensure_ascii=False),2000),
            checks='Verify the actual requested result; report missing configuration or errors.')
        if previous.get('recipe_id'):
            with self.memory.connection() as db:
                old=db.execute('SELECT definition FROM recipe_versions WHERE recipe_id=? AND version=?',(previous['recipe_id'],previous['recipe_version'])).fetchone()
            if old:
                source=json.loads(old[0]);recipe.update(executor=source['executor'],actions=source.get('actions',[]),instructions=source.get('instructions',''),checks=source.get('checks',''))
        arithmetic=re.fullmatch(r'(?:calculate|tính)\s+(.+)',original,re.I|re.S)
        if arithmetic:recipe.update(executor='local',actions=[dict(type='calculate',expression=arithmetic[1])])
        if match:
            from desktop_tasks import DesktopRouter
            workspace=DesktopRouter(self.memory.root)._workspace(match[1])
            if workspace:recipe.update(executor='local',actions=[dict(type='open_workset',workspace_id=workspace['id'])])
        return self.save_recipe(recipe,'user-save:'+str(previous['id']))

    def execute_local(self,recipe,router,cancel):
        replies=[];steps=[];outcome='success'
        for action in recipe['actions']:
            if cancel.is_set():
                from process_control import TaskCancelled
                raise TaskCancelled('Recipe cancelled')
            result=router.execute_action(action,cancel)
            replies.append(str(result));steps.extend(result.steps)
            if result.outcome!='success':outcome=result.outcome;break
        return ExecutionResult('\n'.join(replies),outcome,steps)
