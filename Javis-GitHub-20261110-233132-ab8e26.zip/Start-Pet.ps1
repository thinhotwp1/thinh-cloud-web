param([switch]$SelfTest,[switch]$PetHost,[switch]$Describe,[string]$FixtureUrl)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
if($FixtureUrl -and (-not $SelfTest -or $FixtureUrl -notmatch '^http://127\.0\.0\.1:\d+/?$')){throw 'FixtureUrl is loopback self-test only.'}
if($Describe){@{mode='native-transparent-pet';model_loaded=$false;session=(Get-Content (Join-Path $root 'state/session.json') -Raw|ConvertFrom-Json).thread_id;global_config_edited=$false}|ConvertTo-Json;exit}
if(-not $SelfTest -and -not $PetHost){
    & (Join-Path $root 'Start-WebSpeech.ps1') -NoBrowser
    . (Join-Path $root 'tools/Chrome-Cdp.ps1')
    try{$endpoint=Get-JarvisChromeEndpoint $root}catch{
        & (Join-Path $root 'tools/Open-Chrome.ps1') -Inspect|Out-Null
        $endpoint=Get-JarvisChromeEndpoint $root
    }
    $client=Connect-JarvisCdp $endpoint.webSocketDebuggerUrl
    try{
        $rolesPath=Join-Path $root 'state/webspeech-live-browser.json'
        $roles=if(Test-Path $rolesPath){Get-Content $rolesPath -Raw|ConvertFrom-Json}else{$null}
        $voice=(Invoke-JarvisCdp $client 'Target.getTargets' @{}).targetInfos|Where-Object {$_.targetId -eq $roles.voice_target}|Select-Object -First 1
        if(-not $voice){& (Join-Path $root 'tools/Open-Voice-Page.ps1') -VoiceUrl 'http://127.0.0.1:8766/'|Out-Null}
    }finally{$client.socket.Dispose()}
    Start-Process -FilePath powershell.exe -ArgumentList ('-NoProfile -STA -ExecutionPolicy Bypass -File "{0}" -PetHost' -f $PSCommandPath) -WindowStyle Hidden
    Write-Host 'Javis desktop pet started. Use its Mic button; Chrome voice permission is required once.'
    exit
}
$mutex=New-Object Threading.Mutex($false,('Local\JavisDesktopPet'+$(if($SelfTest){'SelfTest'}else{''})))
$owned=$false
try{
    try{$owned=$mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$owned=$true}
    if(-not $owned){Write-Host 'Javis pet is already open.';exit}
    Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase,System.Xaml,System.Web.Extensions,System.Windows.Forms,System.Drawing
    $refs=@([Windows.Window].Assembly.Location,[Windows.Media.Imaging.BitmapDecoder].Assembly.Location,[Windows.Threading.Dispatcher].Assembly.Location,
        [System.Xaml.XamlReader].Assembly.Location,[Web.Script.Serialization.JavaScriptSerializer].Assembly.Location,[Windows.Forms.Screen].Assembly.Location,
        [Drawing.Point].Assembly.Location,[Uri].Assembly.Location,[Linq.Enumerable].Assembly.Location,[Xml.XmlReader].Assembly.Location)
    Add-Type -Path (Join-Path $root 'desktop/PetHost.cs') -ReferencedAssemblies $refs
    $url=if($FixtureUrl){$FixtureUrl}else{'http://127.0.0.1:8766/'}
    [JavisDesktop.PetHost]::Run($root,$url,$SelfTest.IsPresent,[bool]$FixtureUrl)
}finally{if($owned){$mutex.ReleaseMutex()};$mutex.Dispose()}
