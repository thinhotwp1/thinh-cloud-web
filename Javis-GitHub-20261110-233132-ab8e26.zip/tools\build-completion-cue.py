"""Generate the original option-A cue; stdlib only, no system audio settings."""
import array
import math
from pathlib import Path
import sys
import wave


def build(path):
    rate=22050;samples=array.array('h')
    for index in range(round(1.5*rate)):
        t=index/rate;value=0.
        for start,frequency in ((0.,660.),(.43,880.),(.86,1100.)):
            age=t-start
            if 0<=age<.64:
                envelope=min(1.,age/.018)*math.exp(-age*4.5)*min(1.,(.64-age)/.08)
                value+=.62*envelope*(math.sin(2*math.pi*frequency*age)+.10*math.sin(4*math.pi*frequency*age))
        samples.append(round(max(-.95,min(.95,value))*32767))
    with wave.open(str(path),'wb') as wav:
        wav.setparams((1,2,rate,0,'NONE','not compressed'));wav.writeframes(samples.tobytes())


if __name__=='__main__':build(Path(sys.argv[1]))
