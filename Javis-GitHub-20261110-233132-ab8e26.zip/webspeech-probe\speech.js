'use strict';
// Installed local voices only: no provider account, network TTS or model download.
window.JavisSpeech = (() => {
  let active = null, epoch = 0;
  const synth = window.speechSynthesis;
  const voices = () => (synth?.getVoices() || []).filter(v => v.localService && /^en(?:-|$)/i.test(v.lang));
  const vietnameseAvailable = () => (synth?.getVoices() || []).some(v => v.localService && /^vi(?:-|$)/i.test(v.lang));
  function pages(text,limit=96){
    const result=[];let start=0;
    while(start<text.length){
      let end=Math.min(start+limit,text.length);
      if(end<text.length){const space=text.lastIndexOf(' ',end-1);if(space>start)end=space+1;}
      result.push({start,end,text:text.slice(start,end)});start=end;
    }
    return result;
  }
  function stop() { epoch++; synth?.cancel(); active?.(false); }
  async function speak(text, options = {}) {
    stop();const mine=epoch;
    const available=voices();
    const voice=available.find(v => (v.voiceURI||v.name)===options.voice)
      || available.find(v => /Zira/i.test(v.name)) || available[0];
    if(!voice || typeof text!=='string' || !text.trim())return false;
    return new Promise(resolve => {
      let finished=false,timer,pageIndex=-1,lastBoundaryIndex=0,lastBoundaryAt=-Infinity;const pageTimers=[],captions=pages(text.slice(0,700));
      const clearPages=()=>pageTimers.forEach(id=>window.clearTimeout(id));
      const show=index=>{if(finished||mine!==epoch||index<=pageIndex||!captions[index])return;pageIndex=index;options.onPage?.({...captions[index],index:index+1,total:captions.length});};
      const done=success=>{if(finished)return;finished=true;window.clearTimeout(timer);clearPages();if(active===done)active=null;resolve(success && mine===epoch);};
      const utterance=new window.SpeechSynthesisUtterance(text.slice(0,700));
      utterance.voice=voice;utterance.lang=voice.lang;utterance.rate=.95;utterance.pitch=1.08;
      utterance.volume=.9;utterance.onend=()=>done(true);utterance.onerror=()=>done(false);
      utterance.onboundary=event=>{if(!Number.isFinite(event.charIndex)||finished||mine!==epoch)return;if(event.charIndex>lastBoundaryIndex){lastBoundaryIndex=event.charIndex;lastBoundaryAt=Date.now();}let index=captions.findIndex(p=>event.charIndex>=p.start&&event.charIndex<p.end);if(index>=0)show(index);};
      active=done;timer=window.setTimeout(()=>{synth.cancel();done(false);},45000);
      show(0);let elapsed=0;
      const fallback=index=>{if(finished||mine!==epoch||index<=pageIndex)return;if(Date.now()-lastBoundaryAt<2000){pageTimers.push(window.setTimeout(()=>fallback(index),2000));return;}show(index);};
      for(let i=1;i<captions.length;i++){elapsed+=Math.max(1500,captions[i-1].text.trim().split(/\s+/).length/2.35*1000);pageTimers.push(window.setTimeout(()=>fallback(i),elapsed));}
      try{synth.speak(utterance);}catch(_){done(false);}
    });
  }
  return {voices,vietnameseAvailable,pages,speak,stop};
})();
