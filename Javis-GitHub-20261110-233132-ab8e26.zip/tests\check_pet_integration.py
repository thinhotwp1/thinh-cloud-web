"""Real native WPF controls + HTTP + owned fake CLI; no mic or model."""
from contextlib import nullcontext
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
from urllib.request import Request,urlopen

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'tools')]
from voice_core import CodexRunner
from web_bridge import VoiceBridge
from webspeech_live_server import make_server

with tempfile.TemporaryDirectory() as temporary:
    fixture=Path(temporary);(fixture/'state').mkdir()
    (fixture/'voice-config.json').write_text('{"wake_aliases":["Javis"]}')
    (fixture/'state/session.json').write_text(json.dumps({'thread_id':'11111111-2222-4333-8444-555555555555'}))
    cli=fixture/'fake_cli.py';cli.write_text('import pathlib,sys,time\nsys.stdin.read()\npathlib.Path("started").touch()\ntime.sleep(60)\n')
    bridge=VoiceBridge(fixture,runner_factory=lambda on_event:CodexRunner(fixture,cli=[sys.executable,str(cli)],on_event=on_event),mutex_factory=nullcontext)
    server=make_server(fixture,0,bridge);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    url=f'http://127.0.0.1:{server.server_port}'
    def api(path,data=None,token=''):
        req=Request(url+path,data=json.dumps(data).encode() if data is not None else None,headers={'X-Jarvis-Token':token,'Origin':url,'Content-Type':'application/json'})
        with urlopen(req,timeout=5) as response:return json.load(response)
    try:
        token=api('/config')['csrf_token'];lease=api('/api/pet/claim',{'client_id':'fixture'},token)['lease']
        api('/api/pet/publish',{'lease':lease,'seq':1,'snapshot':{'phase':'executing','status':'Fixture task running','epoch':'fixture:1'}},token)
        grant=api('/api/arm',{'wake':'Hi Javis'},token)['grant']
        api('/api/requests',{'request_id':'native-cancel','grant':grant,'text':'BLOCK'},token)
        until=time.monotonic()+4
        while not (fixture/'started').exists() and time.monotonic()<until:time.sleep(.02)
        assert (fixture/'started').exists(),'Owned fake CLI did not start'
        result=subprocess.run(['powershell.exe','-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',str(ROOT/'Start-Pet.ps1'),'-SelfTest','-FixtureUrl',url],capture_output=True,encoding='utf-8',errors='replace',timeout=20)
        print(result.stdout.strip());assert result.returncode==0,result.stderr
        until=time.monotonic()+3
        while bridge.status('native-cancel')['state']!='cancelled' and time.monotonic()<until:time.sleep(.02)
        assert bridge.status('native-cancel')['state']=='cancelled'
        assert not bridge.worker.is_alive()
        print('PASS: native controls reached authenticated HTTP and cancelled actual owned fake-CLI worker; mic/model not used.')
    finally:bridge.close();server.shutdown();server.server_close();thread.join()
