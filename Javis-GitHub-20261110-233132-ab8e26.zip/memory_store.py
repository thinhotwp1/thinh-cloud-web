"""Local, bounded, transactional memory. Never starts work or calls an AI."""
from contextlib import contextmanager
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sqlite3
import time
from execution_result import clean


class MemoryStore:
    def __init__(self, root):
        self.root=Path(root);self.path=self.root/'state/javis.sqlite3'
        self.path.parent.mkdir(parents=True,exist_ok=True)
        with self.connection() as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.executescript('''
                CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,created REAL NOT NULL,record TEXT NOT NULL,grant_digest TEXT,request_digest TEXT);
                CREATE INDEX IF NOT EXISTS jobs_created ON jobs(created);
                CREATE TABLE IF NOT EXISTS steps(job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,seq INTEGER NOT NULL,record TEXT NOT NULL,PRIMARY KEY(job_id,seq));
                CREATE TABLE IF NOT EXISTS notifications(job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,cue TEXT NOT NULL,PRIMARY KEY(job_id,cue));
                CREATE TABLE IF NOT EXISTS questions(id TEXT PRIMARY KEY,parent_job TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,record TEXT NOT NULL,status TEXT NOT NULL,child_job TEXT);
                CREATE TABLE IF NOT EXISTS recipes(id TEXT PRIMARY KEY,version INTEGER NOT NULL,enabled INTEGER NOT NULL,definition TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS recipe_versions(recipe_id TEXT NOT NULL,version INTEGER NOT NULL,definition TEXT NOT NULL,source TEXT NOT NULL,PRIMARY KEY(recipe_id,version));
                CREATE TABLE IF NOT EXISTS recipe_aliases(alias TEXT PRIMARY KEY,recipe_id TEXT NOT NULL REFERENCES recipes(id) ON DELETE CASCADE);
                CREATE TABLE IF NOT EXISTS recipe_runs(job_id TEXT PRIMARY KEY REFERENCES jobs(id) ON DELETE CASCADE,recipe_id TEXT NOT NULL,version INTEGER NOT NULL,outcome TEXT NOT NULL);
            ''')
            db.execute("INSERT OR IGNORE INTO meta VALUES('schema_version','1')")
            if db.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0]!='1':
                raise ValueError('Unsupported Javis database version')
            for identifier,record in db.execute('SELECT id,record FROM jobs').fetchall():
                value=json.loads(record)
                if value.get('state') in ('queued','running','cancelling','submitting'):
                    value.update(state='interrupted',outcome='unknown',error='Previous broker stopped; work was not replayed.')
                    db.execute('UPDATE jobs SET record=? WHERE id=?',(json.dumps(value,ensure_ascii=False),identifier))
            if not db.execute("SELECT 1 FROM meta WHERE key='legacy_import'").fetchone():
                self._import_legacy(db)
                db.execute("INSERT INTO meta VALUES('legacy_import','1')")
        self.prune()

    @contextmanager
    def connection(self):
        db=sqlite3.connect(self.path,timeout=.5)
        try:
            db.execute('PRAGMA foreign_keys=ON')
            with db: yield db
        finally: db.close()

    @staticmethod
    def digest(text): return hashlib.sha256(str(text).encode()).hexdigest()

    @staticmethod
    def public(record):
        result={k:record[k] for k in ('id','state','outcome','executor','created_at','started_at','completed_at','elapsed_seconds','recipe_id','recipe_version','response_kind','parent_question_id','local_action_id') if k in record}
        for key,limit in (('text',8000),('reply',4000),('error',1000)):
            result[key]=clean(record.get(key),limit)
        result['events']=[]
        if record.get('sourced_work'):result['sourced_work']=True
        result['spoken_reply']=clean(record.get('spoken_reply'),700)[:700]
        result['question_options']=[clean(v,100) for v in record.get('question_options',[])[:4]]
        if record.get('question'):result['question']=record['question']
        return result

    def begin_job(self,record,grant,question_id=None):
        with self.connection() as db:
            try:
                db.execute('INSERT INTO jobs VALUES(?,?,?,?,?)',(record['id'],time.time(),json.dumps(self.public(record),ensure_ascii=False),self.digest(grant),self.digest(record['text'])))
                if question_id and db.execute("UPDATE questions SET status='answered',child_job=? WHERE id=? AND status='pending'",(record['id'],question_id)).rowcount!=1:
                    raise ValueError('Question already answered or dismissed')
            except sqlite3.IntegrityError as error: raise ValueError('Request ID already exists') from error

    def finish_job(self,record,steps):
        with self.connection() as db:
            db.execute('UPDATE jobs SET record=? WHERE id=?',(json.dumps(self.public(record),ensure_ascii=False),record['id']))
            if record.get('question'):
                q=record['question']
                db.execute("UPDATE questions SET status='dismissed' WHERE status='pending' AND id<>?",(q['id'],))
                db.execute('INSERT OR IGNORE INTO questions VALUES(?,?,?,?,NULL)',(q['id'],record['id'],json.dumps(q,ensure_ascii=False),'pending'))
            db.execute('DELETE FROM steps WHERE job_id=?',(record['id'],))
            for index,step in enumerate(list(steps)[:20]):
                db.execute('INSERT INTO steps VALUES(?,?,?)',(record['id'],index,json.dumps({'label':clean(step.get('label'),160),
                    'state':clean(step.get('state'),24),'evidence':clean(step.get('evidence'),400)},ensure_ascii=False)))
            if record.get('recipe_id'):
                db.execute('INSERT OR REPLACE INTO recipe_runs VALUES(?,?,?,?)',(record['id'],record['recipe_id'],record['recipe_version'],record.get('outcome','unknown')))
        self.prune()

    def get_job(self,identifier):
        with self.connection() as db:
            row=db.execute('SELECT record FROM jobs WHERE id=?',(identifier,)).fetchone()
            if not row:return None
            record=json.loads(row[0]);record['steps']=[json.loads(s[0]) for s in db.execute('SELECT record FROM steps WHERE job_id=? ORDER BY seq',(identifier,))]
            return record

    def append_step(self,identifier,step):
        bounded={'label':clean(step.get('label'),160),'state':clean(step.get('state'),24),'evidence':clean(step.get('evidence'),400)}
        with self.connection() as db:
            count=db.execute('SELECT count(*) FROM steps WHERE job_id=?',(identifier,)).fetchone()[0]
            seq=min(count,19)
            db.execute('INSERT OR REPLACE INTO steps VALUES(?,?,?)',(identifier,seq,json.dumps(bounded,ensure_ascii=False)))

    def matches_retry(self,identifier,grant,text):
        with self.connection() as db:
            row=db.execute('SELECT grant_digest,request_digest FROM jobs WHERE id=?',(identifier,)).fetchone()
            return bool(row and row==(self.digest(grant),self.digest(text)))

    def claim_notification(self,identifier,cue):
        with self.connection() as db:
            return db.execute('INSERT OR IGNORE INTO notifications VALUES(?,?)',(identifier,cue)).rowcount==1

    def summary_context(self,query,exclude_id=None,include_sourced=False):
        query=query.lower();since=0
        if any(x in query for x in ('today','hôm nay','hom nay')):
            since=datetime.now().astimezone().replace(hour=0,minute=0,second=0,microsecond=0).timestamp()
        limit=1 if any(x in query for x in ('vừa rồi','last task','vua roi')) else 20
        records=[]
        with self.connection() as db:
            ids=[r[0] for r in db.execute("SELECT id FROM jobs WHERE id<>? AND created>=? AND (?=1 OR COALESCE(json_extract(record,'$.sourced_work'),0)=0) AND json_extract(record,'$.state') NOT IN ('queued','running','cancelling','submitting') ORDER BY created DESC LIMIT ?", (exclude_id or '',since,int(include_sourced),limit))]
        for identifier in ids:
            value=self.get_job(identifier)
            if value['state'] in ('queued','running','cancelling','submitting'):continue
            item={k:value.get(k) for k in ('id','text','outcome','reply','steps','error')}
            item['text']=clean(item['text'],500);item['reply']=clean(item['reply'],700)
            item['steps']=[{'label':clean(s.get('label'),100),'state':s.get('state'),'evidence':clean(s.get('evidence'),200)} for s in (item.get('steps') or [])[-5:]]
            if len(json.dumps(records+[item],ensure_ascii=False).encode())>12000:break
            records.append(item)
        return json.dumps(records,ensure_ascii=False)

    def conversation_context(self,exclude_id=None):
        """Short continuity for the next requested turn, including local work.

        The Codex session already carries its conversation; this supplements it
        with broker-only actions and past browser observations, never page text.
        """
        value={'recent_turns':[]}
        browser_path=self.root/'state/browser.json'
        try:
            if browser_path.stat().st_size<=16384:
                browser=json.loads(browser_path.read_text(encoding='utf-8-sig'))
                url=clean(browser.get('current_url'),400)
                if url.startswith(('http://','https://')):
                    value['browser_observation']={'url':url,'title':clean(browser.get('title'),120),
                        'target_id':clean(browser.get('target_id'),80),'observed_at':clean(browser.get('observed_at'),64),
                        'freshness':'past observation; inspect the current page before making claims'}
        except (OSError,ValueError,TypeError,AttributeError):pass
        with self.connection() as db:
            rows=db.execute("SELECT id FROM jobs WHERE id<>? AND COALESCE(json_extract(record,'$.sourced_work'),0)=0 AND json_extract(record,'$.state') NOT IN ('queued','running','cancelling','submitting') ORDER BY created DESC,rowid DESC LIMIT 3",(exclude_id or '',)).fetchall()
        for row in rows:
            job=self.get_job(row[0])
            if not job:continue
            turn={k:job.get(k) for k in ('id','executor','state','outcome')}
            turn.update(user=clean(job.get('text'),300),assistant=clean(job.get('reply'),400),error=clean(job.get('error'),160),
                steps=[{'label':clean(s.get('label'),80),'state':s.get('state'),'evidence':clean(s.get('evidence'),100)} for s in job.get('steps',[])[-2:]])
            candidate={**value,'recent_turns':value['recent_turns']+[turn]}
            if len(json.dumps(candidate,ensure_ascii=False).encode('utf-8'))>6000:break
            value=candidate
        if not value['recent_turns'] and 'browser_observation' not in value:return ''
        # Latest first makes the nearest antecedent clear; no history is replayed.
        return json.dumps(value,ensure_ascii=False)

    def prune(self):
        with self.connection() as db:
            # Never delete a live job as a side effect of retention.
            db.execute("DELETE FROM jobs WHERE (created<? OR id NOT IN (SELECT id FROM jobs ORDER BY created DESC LIMIT 1000)) AND json_extract(record,'$.state') NOT IN ('queued','running','cancelling','submitting')",(time.time()-90*86400,))

    def _import_legacy(self,db):
        path=self.root/'state/webspeech-requests.jsonl'
        if not path.exists():return
        with path.open('rb') as stream:
            stream.seek(max(0,path.stat().st_size-2_000_000));lines=stream.read().splitlines()[-200:]
        for line in lines:
            try:
                value=json.loads(line);identifier=value['id']
                if not isinstance(identifier,str) or len(identifier)>100:continue
                value['outcome']='unknown'
                if value.get('state') not in ('completed','failed','cancelled'):value['state']='interrupted'
                try:created=datetime.fromisoformat(value.get('created_at','')).timestamp()
                except (ValueError,TypeError):created=time.time()
                db.execute('INSERT OR IGNORE INTO jobs(id,created,record) VALUES(?,?,?)',(identifier,created,json.dumps(self.public(value),ensure_ascii=False)))
            except (ValueError,KeyError,TypeError):continue
