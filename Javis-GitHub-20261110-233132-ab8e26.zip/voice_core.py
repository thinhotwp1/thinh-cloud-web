"""Pure routing/segmentation and UTF-8 Codex transport; no microphone on import."""
from collections import Counter, deque
from contextlib import contextmanager, nullcontext
import json
from pathlib import Path
import os
import re
import subprocess
import threading
import time
import unicodedata
import uuid
from process_control import Cancellation, start_owned_process, TaskCancelled


class WakeGate:
    @staticmethod
    def _near_name(candidate,aliases):
        def fold(value):
            value=unicodedata.normalize('NFD',value.lower().replace('đ','d'))
            return ''.join(char for char in value if not unicodedata.combining(char) and not char.isspace())
        def one_edit(left,right):
            if abs(len(left)-len(right))>1:return False
            i=j=changes=0
            while i<len(left) and j<len(right):
                if left[i]==right[j]:i+=1;j+=1;continue
                changes+=1
                if changes>1:return False
                if len(left)>=len(right):i+=1
                if len(left)<=len(right):j+=1
            return changes+int(i<len(left) or j<len(right))<=1
        def vector(value):return Counter(zip(('^'+value+'$')[:-1],('^'+value+'$')[1:]))
        candidate=fold(candidate)
        if not 5<=len(candidate)<=12 or not candidate.isascii() or not candidate.isalpha():return False
        first=vector(candidate)
        for alias in aliases:
            alias=fold(alias)
            if not 5<=len(alias)<=12 or not alias.isascii() or not alias.isalpha() or not one_edit(candidate,alias):continue
            second=vector(alias)
            dot=sum(count*second.get(gram,0) for gram,count in first.items())
            norm=(sum(count*count for count in first.values())*sum(count*count for count in second.values()))**.5
            if dot/norm>=.70:return True
        return False

    def __init__(self, arm_seconds=20, aliases=None):
        self.arm_seconds = arm_seconds
        self.armed_until = 0
        self.armed_since = 0
        if aliases is not None and (not isinstance(aliases, (list, tuple))
                or any(not isinstance(name, str) or not name.strip() for name in aliases)):
            raise ValueError('wake_aliases must be a list of nonempty names.')
        names = {'jarvis', 'javis', 'javist'}
        names.update(unicodedata.normalize('NFC', name).strip().lower() for name in (aliases or []))
        self.aliases = sorted(names)
        pattern = '|'.join(re.escape(name) for name in sorted(names, key=lambda name: (-len(name), name)))
        tail=r'\b[\s,.:;!?–—-]*(?:ơi\b[\s,.:;!?–—-]*)?'
        self.prefix = re.compile(r'^\s*(?:(?:hey|hay|hi|hai|hello|ê|chào)[\s,]+)?(?:'
                                 + pattern + r')' + tail, re.I)
        self.near_prefix=re.compile(r'^\s*(?:hey|hay|hi|hai|hello|ê|chào)[\s,]+([^\W\d_]{5,12})'+tail,re.I)
        self.near_phrase_prefix=re.compile(r'^\s*(?:hey|hay|hi|hai|hello|ê|chào)[\s,]+([^\W\d_]{2,8}\s+[^\W\d_]{2,8})'+tail,re.I)

    def accept(self, text, now=None, recorded_at=None):
        now = time.monotonic() if now is None else now
        recorded_at = now if recorded_at is None else recorded_at
        text = unicodedata.normalize('NFC', text).strip()
        match = self.prefix.match(text)
        if not match:
            near=self.near_prefix.match(text)
            if not near:near=self.near_phrase_prefix.match(text)
            if near and self._near_name(near[1],self.aliases):match=near
        if match:
            request = text[match.end():].strip()
            # Multiple name attempts in one recording are still just one wake.
            while True:
                repeated = self.prefix.match(request)
                if not repeated:
                    break
                request = request[repeated.end():].strip()
            if not request:
                self.armed_until = now + self.arm_seconds
                self.armed_since = now
                return 'armed', None
            self.armed_until = 0
            return 'request', request
        if text and self.armed_since <= recorded_at < self.armed_until:
            self.armed_until = 0
            return 'request', text
        return 'ignored', None

    def reset(self):
        self.armed_until = 0
        self.armed_since = 0


class VoiceControl:
    """Atomic mute/wake/dispatch boundary, with capture-time staleness checks."""
    def __init__(self, arm_seconds=20, max_transcript_age=15, aliases=None):
        self.lock = threading.RLock()
        self.max_transcript_age = max_transcript_age
        self.gate = WakeGate(arm_seconds, aliases=aliases)
        self.epoch = 0
        self.muted = False
        self.stopped = False

    def set_muted(self, value):
        with self.lock:
            self.muted = value
            self.epoch += 1
            self.gate.reset()

    def stop(self):
        with self.lock:
            self.stopped = True
            self.epoch += 1
            self.gate.reset()

    def is_armed_for(self, recorded_at):
        with self.lock:
            return (not self.muted and not self.stopped
                    and self.gate.armed_since <= recorded_at < self.gate.armed_until)

    def acknowledge(self, epoch, now=None):
        with self.lock:
            if self.stopped or self.muted or epoch != self.epoch:
                return False
            now = time.monotonic() if now is None else now
            self.gate.armed_since = now
            self.gate.armed_until = now + self.gate.arm_seconds
            return True

    def predates_ready(self, recorded_at):
        with self.lock:
            return self.gate.armed_since > 0 and recorded_at < self.gate.armed_since

    def accept_voice(self, text, epoch, began_at, finished_at, decoded_at, enqueue):
        with self.lock:
            if self.stopped or self.muted or epoch != self.epoch:
                return 'invalidated', None
            if decoded_at-finished_at > self.max_transcript_age:
                return 'stale', None
            outcome, request = self.gate.accept(text, now=decoded_at, recorded_at=began_at)
            if outcome == 'request':
                enqueue(request, epoch, finished_at)
            return outcome, request

    @contextmanager
    def authorize(self, epoch, captured_at, max_age):
        # Held only across subprocess creation, never for the running model turn.
        with self.lock:
            if self.stopped:
                raise RuntimeError('Voice worker is stopping; request not started.')
            if epoch is not None and (self.muted or epoch != self.epoch):
                raise RuntimeError('Voice request invalidated by mute; request not started.')
            if time.monotonic()-captured_at > max_age:
                raise RuntimeError('Request expired before execution; please repeat.')
            yield


class SpeechSegmenter:
    def __init__(self, sample_rate, rms_threshold=.006, min_speech_seconds=.25,
                 silence_seconds=.8, max_seconds=30):
        self.rate = sample_rate
        self.threshold = rms_threshold
        self.minimum = min_speech_seconds
        self.silence_limit = silence_seconds
        self.maximum = max_seconds
        self.pre = deque(maxlen=6)
        self.reset()

    def reset(self):
        self.frames = []
        self.speech_seconds = self.silence = self.duration = 0
        self.onset = 0
        self.pre.clear()

    def feed(self, block, rms):
        seconds = len(block) / self.rate
        voiced = rms >= self.threshold
        if not self.frames:
            self.pre.append((block, voiced))
            self.onset = self.onset + 1 if voiced else 0
            if self.onset < 2:
                return None
            self.frames = [b for b, _ in self.pre]
            self.duration = sum(len(b) / self.rate for b, _ in self.pre)
            self.speech_seconds = sum(len(b) / self.rate for b, yes in self.pre if yes)
            self.silence = 0
            return None
        self.frames.append(block)
        self.duration += seconds
        if voiced:
            self.speech_seconds += seconds
            self.silence = 0
        else:
            self.silence += seconds
        if self.silence + 1e-9 >= self.silence_limit or self.duration >= self.maximum:
            result = self.frames if self.speech_seconds >= self.minimum else None
            self.reset()
            return result
        return None


def find_codex():
    extensions = Path.home() / '.vscode' / 'extensions'
    candidates = sorted(extensions.glob('openai.chatgpt-*-win32-x64'),
                        key=lambda p: p.stat().st_mtime, reverse=True)
    for directory in candidates:
        executable = directory / 'bin/windows-x86_64/codex.exe'
        if executable.is_file():
            return [str(executable)]
    raise RuntimeError('Installed Codex CLI not found. Sign in/install the extension manually.')


class CodexRunner:
    def __init__(self, root, cli=None, on_event=None, reasoning_effort=None, result_contract=False):
        if reasoning_effort not in (None,'low','medium','high','xhigh','max'):
            raise ValueError('Unsupported reasoning effort.')
        self.reasoning_effort = reasoning_effort
        self.result_contract=result_contract
        self.sandbox='danger-full-access'
        self.root = Path(root)
        self.cli = list(cli) if cli is not None else find_codex()
        self.on_event = on_event or (lambda event: None)
        self.lock = threading.Lock()
        self.process_lock = threading.Lock()
        self.cancelled = Cancellation()
        self.process = None
        self.process_group = None
        self.finished = False

    def session_id(self):
        state = json.loads((self.root / 'state/session.json').read_text(encoding='utf-8-sig'))
        value = state['thread_id']
        uuid.UUID(value)
        return value

    def run(self, text, start_guard=None):
        if not text.strip():
            raise ValueError('Empty request')
        with self.lock:
            self.finished = False
            if self.cancelled.is_set():
                raise TaskCancelled('Runner cancelled; no new request will start.')
            session_id = self.session_id()
            if self.sandbox not in ('danger-full-access','read-only'):raise ValueError('Unsupported per-turn sandbox')
            args = self.cli + ['-C', str(self.root), '-s', self.sandbox, '-a', 'never',
                               'exec', 'resume', session_id, '--skip-git-repo-check', '--json', '-']
            if self.reasoning_effort:
                args[len(self.cli):len(self.cli)] = ['-c',f'model_reasoning_effort="{self.reasoning_effort}"']
            state_dir = self.root / 'state'
            state_dir.mkdir(exist_ok=True)
            tail = deque(maxlen=10)
            replies = []
            failed = None
            flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
            environment = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
            with self.process_lock:
                if self.cancelled.is_set():
                    raise TaskCancelled('Runner cancelled; no new request will start.')
                with (start_guard if start_guard is not None else nullcontext()):
                    if self.cancelled.is_set():
                        raise TaskCancelled('Runner cancelled before process creation.')
                    process, self.process_group = start_owned_process(args, cwd=self.root, stdin=subprocess.PIPE,
                                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                               text=True, encoding='utf-8', errors='replace',
                                               creationflags=flags, env=environment, cancellation=self.cancelled)
                    self.process = process

            def read_errors():
                for line in process.stderr:tail.append(line.strip())

            reader = threading.Thread(target=read_errors, daemon=True)
            reader.start()
            try:
                if self.result_contract:
                    from execution_result import RESULT_INSTRUCTION
                    text+=RESULT_INSTRUCTION
                process.stdin.write(text)
                process.stdin.close()
                for line in process.stdout:
                    try:event = json.loads(line)
                    except json.JSONDecodeError:continue
                    if event.get('type') == 'thread.started' and event.get('thread_id') != session_id:
                        failed = 'Codex returned a different session ID; state was not replaced.'
                    if event.get('type') in ('turn.failed', 'error'):
                        failed = json.dumps(event.get('error', event), ensure_ascii=False)
                    item = event.get('item', {})
                    if event.get('type') == 'item.completed' and item.get('type') == 'agent_message':
                        replies.append(item.get('text', ''))
                    self.on_event(event)
                code = process.wait()
                reader.join(timeout=3)
                if self.cancelled.is_set():
                    raise TaskCancelled('Codex task cancelled; owned process stopped.')
                if code != 0 or failed:
                    raise RuntimeError(f'Codex failed (exit {code}): {failed or " | ".join(tail)}')
                # Progress and final agent messages share the same item type in
                # the installed CLI. Only the last message is the result contract;
                # progress remains available through on_event and the event log.
                reply = (replies[-1] if replies else '') if self.result_contract else '\n\n'.join(replies)
                (state_dir / 'current-reply.txt').write_text(reply, encoding='utf-8')
                return reply
            except Exception as error:
                if self.cancelled.is_set():
                    raise TaskCancelled('Codex task cancelled.') from error
                raise
            finally:
                if process.poll() is None:
                    self.process_group.terminate()
                    process.wait(timeout=5)
                process.stdout.close()
                process.stderr.close()
                if not process.stdin.closed:
                    try: process.stdin.close()
                    except BrokenPipeError: pass
                with self.process_lock:
                    with self.cancelled.ownership_lock:
                        cancelled = self.cancelled.release(self.process_group)
                        self.finished = True
                    self.process_group = None
                    self.process = None
                if cancelled:
                    raise TaskCancelled('Codex task cancelled; owned group terminated.')

    def cancel(self):
        with self.cancelled.ownership_lock:
            accepted = not self.finished
            self.cancelled.set()
            return accepted
