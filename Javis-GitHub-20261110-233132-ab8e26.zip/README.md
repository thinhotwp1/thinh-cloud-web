# Javis — trợ lý giọng nói trên Windows

Javis nghe qua Chrome, phản hồi bằng pet nổi trên desktop và giao việc phức tạp
cho một phiên Codex riêng. Lệnh mở web, playlist, chụp ảnh, khóa/tắt màn hình
và các tác vụ nhanh đã cấu hình được xử lý tại máy, không gọi AI khi chờ tên.

## Cài trên máy Windows khác

Cần Windows PowerShell 5.1, Python 3.10 trở lên, Google Chrome, microphone và
VS Code với [Codex IDE extension](https://learn.chatgpt.com/docs/codex/ide)
đã cài và đăng nhập. Javis hiện tìm `codex.exe` đi kèm extension trong
`%USERPROFILE%\.vscode\extensions`; bản CLI khác chưa được kiểm chứng với
luồng phiên cố định này. Chrome Web Speech và Codex cần kết nối mạng.

Mở PowerShell trong thư mục vừa tải từ GitHub và chạy:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Setup-Javis.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Start-Codex.ps1 -InitializeOnly
.\Start-Pet.cmd
```

Lệnh đầu tạo `state/`, môi trường Python `.venv/` và sao chép hai file cấu
hình mẫu nếu chưa có. Chúng chỉ dùng thư viện chuẩn Python; không tải model
giọng nói. Lệnh thứ hai tạo **một phiên Codex mới cho chính máy này** và có
thể dùng một lượt Codex; không sao chép phiên hay tài khoản từ máy cũ. Quyền
Full Access chỉ áp dụng cho tiến trình Codex do Javis khởi chạy; hãy dùng theo
chính sách máy của bạn. `-ExecutionPolicy Bypass` chỉ có hiệu lực cho lệnh đang
chạy, không sửa chính sách Windows toàn cục.

Khi pet hiện ra, bấm **Bật mic**. Trong Chrome riêng của Javis, cho phép mic
nếu trình duyệt hỏi. Chọn **Tiếng Việt** để gọi “Bảo Bối”, hoặc **English**
để ưu tiên “Jarvis/Davis”; đợi tiếng **Yes** rồi mới nói nhiệm vụ. Chọn mức
chờ im lặng 5–20 giây trong **··· → Chi tiết → Voice & sounds**. Nút **Gửi ngay**
nằm ngoài pet; nút **Hủy** dừng lượt hiện tại.

## Cấu hình lần đầu

- `voice-config.json` được tạo từ `voice-config.example.json`. Trang Chi tiết
  lưu thời gian chờ và các tùy chọn giọng nói; không cần sửa file để dùng.
- `workspaces.json` được tạo từ `workspaces.example.json`. Điền đường dẫn
  dự án và URL thật trên **máy hiện tại**, rồi bật `enabled` cho workset cần dùng.
  Không chép đường dẫn hay cookie từ máy cũ.
- Trong **Chi tiết → Tác vụ nhanh**, lưu playlist YouTube dạng `/playlist?list=`
  hoặc `/watch?v=...&list=...`, dashboard và các web thường dùng. Mỗi web có
  tên gọi chính xác. Screenshot, Lock Windows và Tắt hai màn hình cũng có nút
  nhanh trong Chi tiết/menu pet. Các thao tác hệ thống này không tự chạy khi
  cài đặt.
- **Ngữ cảnh công việc** chỉ nhận snapshot JSON thủ công có ID, trạng thái,
  thời gian và URL nguồn. Nó chưa tự đồng bộ dashboard. Quyền gửi dữ liệu từng
  nguồn sang Codex tắt mặc định.

Địa chỉ `http://127.0.0.1:8766/` là trang điều khiển Javis trên máy, không
phải URL dashboard. Nút **··· → Chi tiết** mở trang đó.

## Kiểm tra và khắc phục

```powershell
.\.venv\Scripts\python.exe -S -m unittest discover -s tests -p "test_*.py" -q
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Start-Pet.ps1 -SelfTest
```

Nếu báo thiếu `state/session.json`, chạy lại bước `Start-Codex.ps1 -InitializeOnly`.
Nếu Chrome báo mic hoặc mạng, kiểm tra mic mặc định/quyền mic trong profile
Chrome của Javis. Lỗi mạng lúc chờ tên được thử lại tối đa ba lần; lỗi khi
đang đọc nhiệm vụ không tự phát lại lệnh. Tắt pet bằng menu **··· → Thoát pet**.

## Dữ liệu và phân phối

Gói GitHub mặc định **không chứa** `state/`, `.venv/`, profile Chrome/VS Code,
SQLite, lịch sử, ảnh chụp, phiên Codex, cấu hình cá nhân hay sprite Sprig sao
chép từ một pet khác. Khi không có sprite riêng, pet dùng hình xanh đơn giản
được vẽ bằng mã nguồn trong ứng dụng. Nếu có quyền dùng một sprite atlas phù
hợp, có thể đặt nó tại `assets/pet/spritesheet.webp` (1536×2288 pixel).

Chrome Web Speech có thể gửi âm thanh tới dịch vụ nhận dạng của trình duyệt;
nhiệm vụ phức tạp gửi văn bản tới Codex. Xem chính sách công ty trước khi dùng
với dữ liệu nội bộ. Không có Teams, model STT local nặng, autostart hay thay
đổi cấu hình hệ thống trong gói này.

Chạy `Package-Javis.ps1` từ thư mục nguồn để tạo lại thư mục/ZIP sạch trong
`dist/`. **Chỉ đưa nội dung thư mục gói sạch lên GitHub**; đừng tải toàn bộ
thư mục Javis đang chạy lên. File `.gitignore` là lớp bảo vệ bổ sung, còn bản
gói được tạo từ danh sách file cho phép.
