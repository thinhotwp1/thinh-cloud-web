from contextlib import nullcontext
import json
from pathlib import Path
import tempfile
import unittest
from web_bridge import VoiceBridge,BridgeError


class DialogueTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.calls=[];self.now=[100.]
        outer=self
        class Runner:
            def __init__(self,on_event):pass
            def run(self,text):
                outer.calls.append(text)
                return json.dumps(dict(version=2,outcome='needs_input' if len(outer.calls)==1 else 'success',
                    reply='Which project?',spoken_reply='Which project should I open?',response_kind='question' if len(outer.calls)==1 else 'answer',
                    question_options=['backend','frontend'],steps=[dict(label='Opened dashboard',state='success',evidence='Dashboard visible')]))
            def cancel(self):return True
        self.factory=lambda:VoiceBridge(self.root,runner_factory=Runner,mutex_factory=nullcontext,clock=lambda:self.now[0])
        self.bridge=self.factory()
    def tearDown(self):self.bridge.close();self.temp.cleanup()
    def question(self):
        self.bridge.submit('parent',self.bridge.arm('Hey Javis')['grant'],'Open my project');self.bridge.worker.join(2)
        return self.bridge.status('parent')['question']
    def test_answer_continues_parent_once_and_skips_local_router(self):
        q=self.question();grant=self.bridge.arm_answer(q['id'],'lease-a')['grant']
        job=self.bridge.submit_answer(q['id'],'child',grant,'lease-a','backend');self.bridge.worker.join(2)
        self.assertEqual(job['parent_question_id'],q['id']);self.assertEqual(len(self.calls),2)
        self.assertIn('Open my project',self.calls[1]);self.assertIn('Dashboard visible',self.calls[1]);self.assertIn('backend',self.calls[1])
        self.assertEqual(self.bridge.submit_answer(q['id'],'child',grant,'lease-a','backend')['id'],'child')
        self.assertEqual(len(self.calls),2)
        with self.assertRaises(BridgeError):self.bridge.submit_answer(q['id'],'another',grant,'lease-a','backend')
    def test_expired_wrong_lease_dismissed_and_restart_grants_fail(self):
        q=self.question();grant=self.bridge.arm_answer(q['id'],'lease-a')['grant']
        with self.assertRaises(BridgeError):self.bridge.submit_answer(q['id'],'wrong',grant,'lease-b','frontend')
        self.now[0]+=20
        with self.assertRaises(BridgeError):self.bridge.submit_answer(q['id'],'late',grant,'lease-a','frontend')
        self.bridge.close();self.bridge=self.factory()
        with self.assertRaises(BridgeError):self.bridge.arm_answer(q['id'],'lease-a')
        self.assertEqual(len(self.calls),1)
    def test_new_wake_invalidates_answer_and_question_dismissal_is_idempotent(self):
        q=self.question();grant=self.bridge.arm_answer(q['id'],'lease-a')['grant']
        self.bridge.arm('Hey Javis')
        with self.assertRaises(BridgeError):self.bridge.submit_answer(q['id'],'late',grant,'lease-a','frontend')
        self.bridge.dismiss_question(q['id']);self.bridge.dismiss_question(q['id'])
        self.assertEqual(len(self.calls),1)
    def test_persistence_failure_does_not_consume_answer(self):
        q=self.question();grant=self.bridge.arm_answer(q['id'],'lease-a')['grant']
        original=self.bridge.memory.begin_job
        def fail(*a,**k):raise ValueError('storage unavailable')
        self.bridge.memory.begin_job=fail
        with self.assertRaises(BridgeError):self.bridge.submit_answer(q['id'],'child',grant,'lease-a','backend')
        self.bridge.memory.begin_job=original
        self.bridge.submit_answer(q['id'],'child',grant,'lease-a','backend');self.bridge.worker.join(2)
        self.assertEqual(len(self.calls),2)
