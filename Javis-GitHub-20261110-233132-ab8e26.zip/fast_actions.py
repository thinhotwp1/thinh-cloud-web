"""Explicit, bounded desktop shortcuts. Saved data never contains commands."""
import ctypes
from datetime import datetime
import json
import os
from pathlib import Path
import re
import uuid
from urllib.parse import urlsplit,parse_qs

from desktop_tasks import normalized
from execution_result import ExecutionResult
from process_control import run_cancellable,Cancellation,TaskCancelled


DEFAULTS=[
    {'id':'favorites','type':'playlist','name':'Nhạc yêu thích','aliases':['mở nhạc yêu thích','play favorites'],'url':None},
    {'id':'today','type':'dashboard','name':'Công việc hôm nay','aliases':['mở công việc hôm nay','open today dashboard'],'url':None},
    {'id':'screens-off','type':'screens_off','name':'Tắt cả hai màn hình','aliases':['tắt màn hình','turn off screens']},
    {'id':'lock','type':'lock','name':'Khóa Windows','aliases':['khóa màn hình','lock screen']},
    {'id':'screenshot','type':'screenshot','name':'Chụp màn hình','aliases':['chụp ảnh màn hình','take screenshot']},
]
BUILTINS={row['id']:row['type'] for row in DEFAULTS}
RESERVED={'cancel','cancle','huy','huy lenh','stop','jarvis','javis','hey jarvis','hey javis'}


class WindowsActions:
    def __init__(self,root):self.root=Path(root);self.cancel_event=Cancellation()
    def screens_off(self):
        if os.name!='nt':raise RuntimeError('Windows required')
        # WM_SYSCOMMAND / SC_MONITORPOWER / power off, broadcast to this desktop.
        ctypes.windll.user32.SendMessageW(0xFFFF,0x0112,0xF170,2)
        return True
    def lock(self):
        if os.name!='nt':raise RuntimeError('Windows required')
        return bool(ctypes.windll.user32.LockWorkStation())
    def screenshot(self):
        folder=self.root/'state/screenshots';folder.mkdir(parents=True,exist_ok=True)
        if len(list(folder.glob('Javis-*.png')))>=100:raise ValueError('Screenshot folder is full; review/delete old screenshots before saving another.')
        name='Javis-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]+'.png'
        path=folder/name
        result=run_cancellable(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',
            str(self.root/'tools/Take-Screenshot.ps1'),'-OutputPath',str(path)],self.cancel_event,20,encoding='utf-8-sig')
        if result.returncode:raise RuntimeError((result.stderr or result.stdout)[-500:])
        value=json.loads(result.stdout)
        if not value.get('saved') or Path(value.get('path','')).resolve()!=path.resolve():raise RuntimeError('Screenshot was not verified')
        return str(path)


class FastActionCatalog:
    def __init__(self,root,open_url=None,os_ops=None):
        self.root=Path(root);self.path=self.root/'state/fast-actions.json'
        self.open_url=open_url;self.os_ops=os_ops or WindowsActions(root)
    def list_actions(self):
        if not self.path.exists():return {'version':1,'actions':json.loads(json.dumps(DEFAULTS,ensure_ascii=False))}
        if self.path.stat().st_size>32768:raise ValueError('Fast-action catalog exceeds 32 KB')
        return self.validate(json.loads(self.path.read_text(encoding='utf-8-sig')))
    @staticmethod
    def validate(config):
        if not isinstance(config,dict) or set(config)!={'version','actions'} or config['version']!=1 or not isinstance(config['actions'],list) or len(config['actions'])>20:
            raise ValueError('Invalid fast-action catalog')
        result={'version':1,'actions':[]};ids=set();aliases=set()
        for action in config['actions']:
            if not isinstance(action,dict):raise ValueError('Invalid action')
            kind=action.get('type');identifier=action.get('id','')
            if not isinstance(identifier,str) or not re.fullmatch('[a-z][a-z0-9-]{0,31}',identifier) or identifier in ids:
                raise ValueError('Invalid or duplicate action ID')
            if kind not in ('playlist','dashboard','web','screens_off','lock','screenshot') or (identifier in BUILTINS and kind!=BUILTINS[identifier]):raise ValueError('Unsupported action type')
            if kind not in ('playlist','dashboard','web') and identifier not in BUILTINS:raise ValueError('Only web/playlist/dashboard actions may be added')
            fields={'id','type','name','aliases'}|({'url'} if kind in ('playlist','dashboard','web') else set())
            if set(action)!=fields or not isinstance(action.get('name'),str) or not 1<=len(action['name'].strip())<=100:raise ValueError('Invalid action fields/name')
            names=action.get('aliases')
            if not isinstance(names,list) or not 1<=len(names)<=12:raise ValueError('Aliases required')
            for alias in names:
                if not isinstance(alias,str) or not 1<=len(alias.strip())<=100:raise ValueError('Invalid alias')
                key=normalized(alias)
                if key in aliases or key in RESERVED or key.startswith(('hey jarvis ','hey javis ','hi jarvis ','hi javis ')):
                    raise ValueError('Duplicate or reserved alias')
                aliases.add(key)
            if kind in ('playlist','dashboard','web'):
                url=action['url']
                if url is not None:
                    if not isinstance(url,str) or len(url)>2048 or any(char.isspace() for char in url):raise ValueError('Invalid URL')
                    parsed=urlsplit(url)
                    if parsed.username or parsed.password or parsed.fragment or not parsed.hostname:raise ValueError('URL credentials/fragment are not allowed')
                    host=parsed.hostname.lower()
                    try:port=parsed.port
                    except ValueError as error:raise ValueError('Invalid URL port') from error
                    if kind=='playlist':
                        playlist_ids=parse_qs(parsed.query).get('list',[])
                        if parsed.scheme!='https' or host not in ('www.youtube.com','youtube.com','music.youtube.com') or parsed.path not in ('/playlist','/watch') or len(playlist_ids)!=1 or not re.fullmatch(r'[A-Za-z0-9_-]{1,150}',playlist_ids[0]):
                            raise ValueError('Playlist cần link YouTube /playlist?list=... hoặc /watch?v=...&list=...')
                    elif parsed.scheme!='https' and not (parsed.scheme=='http' and host in ('localhost','127.0.0.1','::1')):
                        raise ValueError('Web/dashboard requires HTTPS or local HTTP')
                    if host in ('localhost','127.0.0.1','::1') and port in (8765,8766):raise ValueError('Voice endpoint is not a work URL')
            ids.add(identifier);result['actions'].append(action)
        if any(identifier not in ids for identifier in BUILTINS):raise ValueError('Required actions missing')
        return result
    def save(self,config):
        value=self.validate(config);self.path.parent.mkdir(parents=True,exist_ok=True)
        temporary=self.path.with_suffix('.json.tmp');temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(temporary,self.path)
        return value
    def run(self,text,cancel_event=None):
        key=normalized(text)
        for action in self.list_actions()['actions']:
            if key not in {normalized(alias) for alias in action['aliases']}:continue
            return self._execute(action,cancel_event)
        return None
    def get_action(self,identifier):
        if not isinstance(identifier,str):raise ValueError('Invalid quick-action ID')
        action=next((item for item in self.list_actions()['actions'] if item['id']==identifier),None)
        if action is None:raise ValueError('Quick action not found')
        return action
    def run_id(self,identifier,cancel_event=None):
        return self._execute(self.get_action(identifier),cancel_event)
    def _execute(self,action,cancel_event):
        if cancel_event and cancel_event.is_set():raise TaskCancelled('Cancelled before local action')
        kind=action['type']
        if kind in ('playlist','dashboard','web'):
            if not action['url']:
                return ExecutionResult(f'Chưa cấu hình URL cho {action["name"]}. Mở Chi tiết để điền URL.','needs_input',
                    spoken_reply='This shortcut needs a URL. Please configure it in Details.')
            if not self.open_url:raise RuntimeError('Browser helper unavailable')
            shown=self.open_url(action['url'])
            if shown.get('visibility_verified') is not True:return ExecutionResult('Chưa xác minh được tab đã hiện.','partial')
            return ExecutionResult(f'Đã mở {action["name"]}: {shown.get("current_url",action["url"])}','success',
                [{'label':'Mở tab đã cấu hình','state':'success','evidence':shown.get('current_url',action['url'])}])
        self.os_ops.cancel_event=cancel_event or Cancellation()
        if kind=='screens_off':
            if not self.os_ops.screens_off():raise RuntimeError('Windows did not accept display-off request')
            reply='Đã gửi lệnh tắt cả hai màn hình. Chuột hoặc phím có thể bật lại.'
        elif kind=='lock':
            if not self.os_ops.lock():raise RuntimeError('Windows did not lock this session')
            reply='Đã khóa phiên Windows hiện tại.'
        else:reply='Đã lưu ảnh màn hình: '+self.os_ops.screenshot()
        return ExecutionResult(reply,'success',[{'label':action['name'],'state':'success','evidence':reply}])
