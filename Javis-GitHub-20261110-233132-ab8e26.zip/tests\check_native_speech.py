"""Real Chrome/HTTP with synthetic recognition and stubbed native audio."""
from contextlib import nullcontext
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
import time
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'tools')]
from web_bridge import VoiceBridge
from webspeech_live_server import make_server
with tempfile.TemporaryDirectory() as folder:
    fixture=Path(folder);(fixture/'state').mkdir();(fixture/'webspeech-probe').mkdir();(fixture/'desktop').mkdir()
    (fixture/'desktop/PetHost.cs').write_text('// Native feature fixture')
    shutil.copy2(ROOT/'voice-config.json',fixture/'voice-config.json')
    for name in ('index.html','app.js','speech.js','style.css','yes.wav','done.wav'):shutil.copy2(ROOT/'webspeech-probe'/name,fixture/'webspeech-probe'/name)
    def no_model(_):raise AssertionError('No model allowed in native speech test')
    bridge=VoiceBridge(fixture,aliases=json.loads((fixture/'voice-config.json').read_text(encoding='utf-8-sig'))['wake_aliases'],runner_factory=no_model,mutex_factory=nullcontext)
    server=make_server(fixture,0,bridge);clips=[];server.audio.player=lambda path,event:clips.append(path.name)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'tests/check-speech-snapshot.ps1'),'-FixtureUrl',f'http://127.0.0.1:{server.server_port}/'],capture_output=True,encoding='utf-8-sig',errors='replace',timeout=25)
        print(result.stdout.strip());assert result.returncode==0,result.stderr
        until=time.monotonic()+2
        while len(clips)<1 and time.monotonic()<until:time.sleep(.02)
        assert clips==['done.wav'],clips
        print('PASS: real Chrome selected-voice Yes, authenticated wake, spoken local result and action chime once; no hardware audio/mic/model.')
    finally:bridge.close();server.shutdown();server.server_close();thread.join()
