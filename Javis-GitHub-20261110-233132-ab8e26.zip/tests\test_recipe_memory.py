import tempfile
import unittest
from pathlib import Path
from memory_store import MemoryStore
from recipe_memory import RecipeMemory


class RecipeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.memory=MemoryStore(Path(self.tmp.name));self.recipes=RecipeMemory(self.memory)
    def tearDown(self):self.tmp.cleanup()
    def definition(self):return dict(id='backend',name='Backend',aliases=['Mở backend'],executor='local',actions=[dict(type='open_workset',workspace_id='daily')])
    def test_explicit_versioned_alias_memory_is_not_fuzzy_or_job_retained(self):
        d=self.definition()
        with self.assertRaises(ValueError):self.recipes.save_recipe(d,'')
        self.recipes.save_recipe(d,'user-save-a')
        self.assertEqual(self.recipes.resolve_recipe('mo backend')['version'],1)
        self.assertIsNone(self.recipes.resolve_recipe('mo backend va xoa file'))
        d['actions'][0]['workspace_id']='other';self.recipes.save_recipe(d,'user-save-b')
        self.assertEqual(self.recipes.resolve_recipe('mở backend')['version'],2)
        self.recipes.restore_recipe_version('backend',1,'user-restore')
        self.assertEqual(self.recipes.resolve_recipe('mở backend')['actions'][0]['workspace_id'],'daily')
        self.recipes.set_recipe_enabled('backend',False)
        self.assertIsNone(self.recipes.resolve_recipe('mo backend'))
        self.memory.prune();self.assertEqual(len(self.recipes.list_recipes()),1)
    def test_collision_bad_actions_and_shell_parameters_rejected(self):
        self.recipes.save_recipe(self.definition(),'user')
        other=self.definition();other['id']='other'
        with self.assertRaises(ValueError):self.recipes.save_recipe(other,'user')
        for action in ({'type':'shell','command':'anything'}, {'type':'check_port','port':0}, {'type':'open_workset','workspace_id':'daily; anything'}):
            other['aliases']=['other'];other['actions']=[action]
            with self.assertRaises(ValueError):self.recipes.save_recipe(other,'user')
        self.assertEqual(self.recipes.resolve_recipe('mo backend')['id'],'backend')
