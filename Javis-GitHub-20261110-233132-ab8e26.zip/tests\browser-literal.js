JSON.stringify({message: 'Sóng Gió "Jarvis"', literal: '$HOME $(literal)'})
