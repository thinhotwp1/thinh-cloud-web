const assert=require('node:assert/strict');
const {setup,flush}=require('./check-webspeech-ui.cjs');
async function ready(options={}){const app=setup({silenceMs:10000,...options});await flush();await app.node('start').onclick();app.instances.at(-1).final('Hey Javis');await flush();assert.equal(app.state.phase,'task');return app;}
(async()=>{
  let app=await ready();let speech=app.instances.at(-1);speech.onspeechstart();speech.final('open dashboard');speech.onspeechend();await app.advance(9999);assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);await app.advance(1);assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,1);app.stop();
  for(const suffix of ['gửi ngay','gửi luôn','làm luôn','do it now','send now']){
    app=await ready();speech=app.instances.at(-1);speech.final('open dashboard '+suffix);await flush();
    const calls=app.calls.filter(c=>c.path==='/api/requests');assert.equal(calls.length,1,suffix);assert.equal(calls[0].body.text,'open dashboard');speech.onend();await app.advance(10000);assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,1);app.stop();
  }
  app=await ready();speech=app.instances.at(-1);speech.final('open dashboard');speech.onend();await app.advance(400);assert.ok(app.instances.length>=3,'Chrome early end must restart capture');
  const resumed=app.instances.at(-1);resumed.final('open dashboard');resumed.final('today',1);resumed.onspeechend();speech.onend();await app.advance(9999);assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);await app.advance(1);assert.equal(app.calls.find(c=>c.path==='/api/requests').body.text,'open dashboard today');app.stop();
  app=await ready();app.instances.at(-1).final('open dashboard');app.node('send-now').onclick();await flush();assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,1);app.stop();
  console.log('PASS: 10-second pause, immediate suffixes, early Chrome restart and one joined request.');
})().catch(e=>{console.error(e);process.exitCode=1;});
