const assert=require('node:assert/strict');
const {setup,flush}=require('./check-webspeech-ui.cjs');
async function running(){const app=setup({nativePet:true,runningJob:true,silenceMs:10000});await flush();await app.node('start').onclick();app.instances.at(-1).final('Hi Javis');await flush();app.instances.at(-1).final('long task');app.instances.at(-1).onend();await app.advance(10000);assert.equal(app.state.job.state,'running');return app;}
(async()=>{
 let app=await running();assert.equal(app.state.listening,true,'busy job must keep a wake listener');app.instances.at(-1).final('Cancel');await flush();assert.equal(app.calls.filter(c=>c.path==='/api/busy/cancel').length,0);assert.equal(app.state.job.state,'running');await app.node('mini-cancel').onclick();await flush();assert.equal(app.calls.filter(c=>c.path.endsWith('/cancel')).length,1);app.stop();
 app=await running();app.instances.at(-1).final('Hey Javis');await flush();assert.equal(app.calls.filter(c=>c.path==='/api/busy/arm').length,1);assert.equal(app.state.phase,'busy-task');
 app.instances.at(-1).final('open new dashboard send now');await flush();assert.equal(app.calls.filter(c=>c.path==='/api/busy/replace').length,1);assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,1);
 await app.advance(1600);assert.equal(app.state.job.id,'replace-test-request');assert.equal(app.state.job.outcome,'success');app.stop();
 app=await running();app.instances.at(-1).final('Hey Javis');await flush();assert.equal(app.state.phase,'busy-task');
 app.jobs.get('test-request').state='cancelled';await app.advance(1600);
 assert.equal(app.state.phase,'busy-task','an old cancelled job must not erase the replacement utterance');app.stop();
 app=await running();app.instances.at(-1).final('Hey Javis');await flush();
 app.instances.at(-1).final('Cancel');await flush();assert.equal(app.calls.filter(c=>c.path==='/api/busy/cancel').length,0,'busy-task voice Cancel must be ignored');
 assert.equal(app.calls.filter(c=>c.path==='/api/busy/replace').length,0);app.stop();
 app=await running();app.instances.at(-1).final('Hey Javis');await flush();app.instances.at(-1).final('open new dashboard send now');await flush();
 app.instances.at(-1).final('Cancel');await flush();
 assert.equal(app.calls.filter(c=>c.path==='/api/busy/cancel').length,0,'queued replacement must ignore voice Cancel');app.stop();
 app=await running();app.instances.at(-1).final('Hey Javis');await flush();app.instances.at(-1).final('open new dashboard send now');await flush();
 app.instances.at(-1).final('Hey Javis');await flush();
 assert.equal(app.calls.findLast(c=>c.path==='/api/busy/arm').body.active_job_id,'test-request','a third command must bind to the old active worker while replacement is queued');app.stop();
 app=setup({nativePet:true,silenceMs:10000});await flush();await app.node('start').onclick();app.instances.at(-1).final('Hey Javis');await flush();
 app.instances.at(-1).final('Cancel');await flush();assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0,'idle Cancel must never become a task');app.stop();
 console.log('PASS: button-only Cancel, busy wake, and one replacement without concurrent submission.');
})().catch(e=>{console.error(e);process.exitCode=1;});
