import json
from pathlib import Path
import tempfile
import unittest
from contextlib import nullcontext
from web_bridge import VoiceBridge


class WorkMemoryBridgeTests(unittest.TestCase):
    def test_local_sourced_reply_does_not_enter_later_codex_context(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);calls=[]
            class Runner:
                def __init__(self,on_event):pass
                def run(self,text):
                    calls.append(text)
                    return json.dumps(dict(version=2,outcome='success',reply='Finished.',response_kind='action',spoken_reply='',steps=[]))
            bridge=VoiceBridge(root,runner_factory=Runner,mutex_factory=nullcontext)
            try:
                bridge.work.import_items('dashboard',[dict(item_id='B',title='UI',status='blocked',observed_at='2026-11-06T09:00:00+07:00',source_ref='https://work.example/B',reason='Private design decision')])
                bridge.submit('why',bridge.arm('Hi Javis')['grant'],'Việc B vì sao chưa hoàn thành?');bridge.worker.join(2)
                self.assertEqual(calls,[])
                bridge.submit('read',bridge.arm('Hi Javis')['grant'],'read result');bridge.worker.join(2)
                self.assertEqual(bridge.status('read')['executor'],'local')
                self.assertIn('Private design decision',bridge.status('read')['reply'])
                bridge.submit('general',bridge.arm('Hi Javis')['grant'],'Explain a sorting algorithm');bridge.worker.join(2)
                self.assertEqual(len(calls),1)
                self.assertNotIn('Private design decision',calls[0])
                self.assertNotIn('https://work.example/B',calls[0])
            finally:bridge.close()
    def test_status_and_why_local_by_default_then_explicit_opt_in_uses_codex(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);calls=[];sandboxes=[]
            class Runner:
                def __init__(self,on_event):pass
                def run(self,text):
                    calls.append(text);sandboxes.append(getattr(self,'sandbox',None))
                    return json.dumps(dict(version=2,outcome='success',reply='B is blocked by design.',response_kind='answer',spoken_reply='Task B is blocked by a design decision.',steps=[dict(label='Read history',state='success',evidence='Dashboard B 2026-11-06')]))
            bridge=VoiceBridge(root,runner_factory=Runner,mutex_factory=nullcontext)
            try:
                bridge.work.import_items('dashboard',[dict(item_id='A',title='API',status='done',observed_at='2026-11-07T09:00:00+07:00',source_ref='https://work.example/A'),
                    dict(item_id='B',title='UI',status='blocked',observed_at='2026-11-06T09:00:00+07:00',source_ref='https://work.example/B',reason='Waiting for design decision')])
                bridge.submit('status',bridge.arm('Hi Javis')['grant'],'Việc A làm tới đâu rồi?');bridge.worker.join(2)
                self.assertEqual(bridge.status('status')['executor'],'local');self.assertEqual(calls,[])
                bridge.submit('why',bridge.arm('Hi Javis')['grant'],'Việc B vì sao chưa hoàn thành?');bridge.worker.join(2)
                self.assertEqual(bridge.status('why')['executor'],'local');self.assertEqual(calls,[])
                self.assertIn('Waiting for design decision',bridge.status('why')['reply'])
                bridge.work.set_ai_permission('dashboard',True)
                bridge.submit('why-ai',bridge.arm('Hi Javis')['grant'],'Việc B vì sao chưa hoàn thành?');bridge.worker.join(2)
                self.assertEqual(bridge.status('why-ai')['outcome'],'success');self.assertEqual(len(calls),1)
                self.assertIn('Waiting for design decision',calls[0]);self.assertIn('https://work.example/B',calls[0])
                self.assertEqual(sandboxes,['read-only'])
                self.assertFalse((root/'state/webspeech-requests.jsonl').exists(),'Raw task text/replies must not be copied into an unbounded JSONL log')
            finally:bridge.close()
