$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
Add-Type -Path (Join-Path $root 'tools/jarvis_windows.cs')
Add-Type -AssemblyName System.Windows.Forms
Add-Type @'
using System;using System.Runtime.InteropServices;using System.Windows.Forms;
public class JavisVisibilityForm : Form {protected override bool ShowWithoutActivation{get{return true;}}}
public static class JavisVisibilityTest {
 [DllImport("user32.dll")]static extern IntPtr GetWindow(IntPtr h,uint command);
 [DllImport("user32.dll",EntryPoint="GetWindowLongW")]static extern int Style(IntPtr h,int n);
 public static bool Pinned(IntPtr h){return (Style(h,-20)&8)!=0;}
 public static bool Above(IntPtr a,IntPtr b){for(var p=GetWindow(b,3);p!=IntPtr.Zero;p=GetWindow(p,3))if(p==a)return true;return false;}
}
'@ -ReferencedAssemblies System.Windows.Forms
$cover=New-Object JavisVisibilityForm
$subject=New-Object JavisVisibilityForm
$pin=New-Object JavisVisibilityForm
$cover.StartPosition='Manual';$subject.StartPosition='Manual';$pin.StartPosition='Manual'
$guard=$null
try{
 $cover.Text='Javis visibility cover';$cover.SetBounds(-1800,100,500,300);$cover.Show()
 $anchor=[JarvisWindowGuard]::Foreground()
 $guard=New-Object JarvisWindowGuard(-1800,100,500,300,([string[]]@('powershell')),'WindowsForms10.Window',([uint32[]]@($PID)))
 $subject.Text='Javis work fixture';$subject.Show()
 $pin.Text='Javis pin fixture';$pin.TopMost=$true;$pin.SetBounds(-1600,150,300,180);$pin.Show()
 $settle=(Get-Date).AddMilliseconds(150)
 while((Get-Date)-lt $settle){[Windows.Forms.Application]::DoEvents();Start-Sleep -Milliseconds 20}
 $anchor=[JarvisWindowGuard]::Foreground()
 $subject.SetBounds(-1750,120,450,280)
 $until=(Get-Date).AddMilliseconds(450)
 while((Get-Date)-lt $until){[Windows.Forms.Application]::DoEvents();Start-Sleep -Milliseconds 20}
 if(-not([JavisVisibilityTest]::Above($subject.Handle,$cover.Handle))){throw 'Work window was placed below an existing covering window.'}
 if(-not([JavisVisibilityTest]::Pinned($pin.Handle))){throw 'The window guard removed the floating panel pin.'}
 if(-not([JavisVisibilityTest]::Above($pin.Handle,$subject.Handle))){throw 'A normal work window covered the pinned controls.'}
 $pinBounds=[JarvisWindowGuard]::Bounds($pin.Handle)
 if($pinBounds[0] -ne -1600 -or $pinBounds[1] -ne 150 -or $pinBounds[2] -ne 300 -or $pinBounds[3] -ne 180){throw 'The window guard moved/resized the pinned panel.'}
 if([JarvisWindowGuard]::Foreground()-ne $anchor){throw 'Nonactivating placement changed keyboard focus.'}
 'PASS: work window raised above cover, pinned panel preserved, keyboard focus unchanged.'
}finally{if($guard){$guard.Dispose()};$pin.Dispose();$subject.Dispose();$cover.Dispose()}
