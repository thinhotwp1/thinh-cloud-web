import json
from pathlib import Path
import tempfile
import unittest
import sys
import threading
from datetime import datetime, timezone, timedelta
from contextlib import nullcontext
from browser_completion import completed_browser_targets
from web_bridge import VoiceBridge
from voice_core import CodexRunner
from process_control import TaskCancelled


class BrowserCompletionTests(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def event(self,voice=False):
        return {'type':'item.completed','item':{'type':'command_execution','exit_code':0,
            'command':f'powershell.exe -File "{self.root}/tools/Open-Chrome.ps1" '+('-VoicePage -Inspect' if voice else '-Url https://www.youtube.com/ -Inspect'),
            'aggregated_output':json.dumps({'target_id':'A'*32,'current_url':'https://www.youtube.com/'})+'\n'+json.dumps({'title':'YouTube'})}}
    def test_only_successful_own_browser_receipts_count(self):
        self.assertEqual(completed_browser_targets(self.root,self.event()),['A'*32])
        self.assertEqual(completed_browser_targets(self.root,self.event(True)),[])
        event=self.event();event['item']['exit_code']=1
        self.assertEqual(completed_browser_targets(self.root,event),[])
        event=self.event();event['item']['command']='echo Open-Chrome.ps1'
        self.assertEqual(completed_browser_targets(self.root,event),[])
    def test_expression_receipt_uses_fresh_private_observation_for_every_result_shape(self):
        (self.root/'state').mkdir()
        now=datetime.now(timezone.utc)
        path=self.root/'state/browser.json'
        event=self.event()
        event['item']['command']=f'powershell.exe -File "{self.root}/tools/Open-Chrome.ps1" -ExpressionFile action.js'
        for output in ['true',json.dumps({'url':'https://example.com','playing':True}),json.dumps({'target_id':'C'*32})]:
            path.write_text(json.dumps({'target_id':'B'*32,'observed_at':now.isoformat()}))
            event['item']['aggregated_output']=output
            self.assertEqual(completed_browser_targets(self.root,event,not_before=(now-timedelta(seconds=1)).isoformat()),['B'*32])
        path.write_text(json.dumps({'target_id':'B'*32,'observed_at':(now-timedelta(minutes=1)).isoformat()}))
        self.assertEqual(completed_browser_targets(self.root,event,not_before=now.isoformat()),[])
        path.write_text(json.dumps({'target_id':'B'*32,'observed_at':'invalid'}))
        self.assertEqual(completed_browser_targets(self.root,event,not_before=now.isoformat()),[])
    def test_bridge_reveals_before_success_and_does_not_touch_browser_for_other_work(self):
        event=self.event();revealed=[]
        class Runner:
            def __init__(self,on_event):self.emit=on_event
            def run(self,text):
                if text.startswith('browser'):self.emit(event)
                return json.dumps(dict(version=1,outcome='success',reply='ok',steps=[dict(label='Done',state='success',evidence='observed')]))
            def cancel(self):return True
        bridge=VoiceBridge(self.root,runner_factory=Runner,mutex_factory=nullcontext,
            browser_finalizer=lambda ids,cancel:revealed.append(ids) or {'visibility_verified':True,'focus_kept':True})
        try:
            for identifier,text in [('a','browser work'),('b','other work')]:
                bridge.submit(identifier,bridge.arm('Hi Javis')['grant'],text);bridge.worker.join(3)
                self.assertEqual(bridge.status(identifier)['outcome'],'success')
            self.assertEqual(revealed,[['A'*32]])
            bridge.browser_finalizer=lambda ids,cancel:{'visibility_verified':False,'focus_kept':True}
            bridge.submit('c',bridge.arm('Hi Javis')['grant'],'browser again');bridge.worker.join(3)
            self.assertEqual(bridge.status('c')['outcome'],'partial')
        finally:bridge.close()
    def test_real_fake_cli_progress_final_json_and_receipt_become_verified_done(self):
        (self.root/'state').mkdir(exist_ok=True)
        (self.root/'state/session.json').write_text(json.dumps({'thread_id':'11111111-2222-4333-8444-555555555555'}))
        final=json.dumps(dict(version=1,outcome='success',reply='Opened fixture',steps=[dict(label='Open',state='success',evidence='Fixture page observed')]))
        events=[{'type':'item.completed','item':{'type':'agent_message','text':'Opening browser...'}},self.event(),{'type':'item.completed','item':{'type':'agent_message','text':final}}]
        cli=self.root/'fake_cli.py'
        cli.write_text('import sys\nsys.stdin.read()\n'+'\n'.join('print('+repr(json.dumps(event))+')' for event in events))
        calls=[]
        bridge=VoiceBridge(self.root,runner_factory=lambda on_event:CodexRunner(self.root,cli=[sys.executable,str(cli)],on_event=on_event,result_contract=True),mutex_factory=nullcontext,
            browser_finalizer=lambda ids,cancel:calls.append(ids) or {'visibility_verified':True,'focus_kept':True})
        try:
            bridge.submit('fake-cli',bridge.arm('Hi Javis')['grant'],'open fixture');bridge.worker.join(4)
            job=bridge.status('fake-cli')
            self.assertEqual(job['state'],'completed');self.assertEqual(job['outcome'],'success')
            self.assertEqual(job['reply'],'Opened fixture');self.assertEqual(calls,[['A'*32]])
        finally:bridge.close()
    def test_cancellation_during_final_reveal_stays_cancelled(self):
        event=self.event();started=threading.Event()
        class Runner:
            def __init__(self,on_event):self.emit=on_event
            def run(self,text):self.emit(event);return json.dumps(dict(version=1,outcome='success',reply='ok',steps=[dict(label='Open',state='success',evidence='URL')]))
            def cancel(self):return False
        def reveal(ids,cancel):
            started.set();cancel.wait(2)
            if cancel.is_set():raise TaskCancelled('Cancelled final reveal')
            return {'visibility_verified':True}
        bridge=VoiceBridge(self.root,runner_factory=Runner,mutex_factory=nullcontext,browser_finalizer=reveal)
        try:
            bridge.submit('cancel',bridge.arm('Hi Javis')['grant'],'open fixture')
            self.assertTrue(started.wait(1));bridge.cancel('cancel');bridge.worker.join(3)
            self.assertEqual(bridge.status('cancel')['outcome'],'cancelled')
        finally:bridge.close()
