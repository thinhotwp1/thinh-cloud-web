$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase,System.Xaml,System.Web.Extensions,System.Windows.Forms,System.Drawing
$refs=@([Windows.Window].Assembly.Location,[Windows.Media.Imaging.BitmapDecoder].Assembly.Location,[Windows.Threading.Dispatcher].Assembly.Location,[System.Xaml.XamlReader].Assembly.Location,[Web.Script.Serialization.JavaScriptSerializer].Assembly.Location,[Windows.Forms.Screen].Assembly.Location,[Drawing.Point].Assembly.Location,[Uri].Assembly.Location,[Linq.Enumerable].Assembly.Location,[Xml.XmlReader].Assembly.Location)
Add-Type -Path (Join-Path $root 'desktop/PetHost.cs') -ReferencedAssemblies $refs
$flags=[Reflection.BindingFlags]'Instance,NonPublic'
$hostType=[JavisDesktop.PetHost]
$constructor=$hostType.GetConstructors($flags)|Select-Object -First 1
$pet=$constructor.Invoke([object[]]@([string]$root,[string]'http://127.0.0.1:8766/',[bool]$true,[bool]$false))
$script:captionPassed=$false
$timer=New-Object Windows.Threading.DispatcherTimer
$timer.Interval=[TimeSpan]::FromMilliseconds(100)
$timer.Add_Tick({
 $window=$hostType.GetField('window',$flags).GetValue($pet)
 if(-not $window -or -not $window.IsLoaded){return}
 $timer.Stop()
 try{
  $text=('W'*96)
  $json=New-Object Web.Script.Serialization.JavaScriptSerializer
  $value=$json.DeserializeObject((@{phase='speaking';status='Speaking - 1/2';heard=$text;dialogue_pending=$true;listener_connected=$true;sound_enabled=$true}|ConvertTo-Json -Compress))
  [void]$hostType.GetMethod('Update',$flags).Invoke($pet,[object[]]@($value))
  $window.UpdateLayout()
  $heard=$hostType.GetField('heard',$flags).GetValue($pet)
  $formatted=New-Object Windows.Media.FormattedText($text,[Globalization.CultureInfo]::InvariantCulture,[Windows.FlowDirection]::LeftToRight,(New-Object Windows.Media.Typeface('Segoe UI')),11,[Windows.Media.Brushes]::Black)
  $formatted.MaxTextWidth=$heard.ActualWidth
  if($heard.Text -ne $text -or $formatted.Height -gt $heard.ActualHeight+1){throw 'Spoken caption is clipped.'}
  $image=New-Object Windows.Media.Imaging.RenderTargetBitmap([int]$window.Width,[int]$window.Height,96,96,[Windows.Media.PixelFormats]::Pbgra32)
  $image.Render($window.Content);$encoder=New-Object Windows.Media.Imaging.PngBitmapEncoder;$encoder.Frames.Add([Windows.Media.Imaging.BitmapFrame]::Create($image))
  $stream=[IO.File]::Create((Join-Path $root 'state/pet-spoken-caption-check.png'));try{$encoder.Save($stream)}finally{$stream.Dispose()}
  [pscustomobject]@{caption_length=$text.Length;font=$heard.FontSize;required_height=$formatted.Height;available_height=$heard.ActualHeight}|ConvertTo-Json -Compress
  $script:captionPassed=$true
 }catch{[Console]::Error.WriteLine($_);$window.Close()}
})
$timer.Start()
[void]$hostType.GetMethod('Start',$flags).Invoke($pet,@())
if(-not $script:captionPassed){throw 'Native caption rendering failed.'}
'PASS: native speaking caption fits without clipping.'
