const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const code=fs.readFileSync(require('node:path').join(__dirname,'../webspeech-probe/speech.js'),'utf8');
async function test(){
 const utterances=[],voices=[{name:'Remote',lang:'en-US',localService:false},{name:'Microsoft David',lang:'en-US',localService:true},{name:'Microsoft Zira',lang:'en-US',localService:true},{name:'Other',lang:'vi-VN',localService:false}];
 const window={speechSynthesis:{getVoices:()=>voices,speak:u=>utterances.push(u),cancel(){}},SpeechSynthesisUtterance:function(text){this.text=text;},setTimeout,clearTimeout};
 vm.runInNewContext(code,{window});const speech=window.JavisSpeech;
 assert.equal(speech.voices().length,2);
 const first=speech.speak('Here is your summary.');await new Promise(setImmediate);utterances[0].onend();assert.equal(await first,true);assert.equal(utterances.length,1);assert.equal(utterances[0].voice.name,'Microsoft Zira');assert.equal(utterances[0].rate,.95);assert.ok(utterances[0].pitch>1 && utterances[0].pitch<=1.15);assert.equal(utterances[0].volume,.9);
 const second=speech.speak('Which project?');await new Promise(setImmediate);speech.stop();assert.equal(await second,false);utterances[1].onend();
 const third=speech.speak('Answer');await new Promise(setImmediate);utterances[2].onerror();assert.equal(await third,false);
 const longText='The dashboard has two overdue tasks. '.repeat(9),pages=speech.pages(longText),seen=[];
 assert.equal(pages.map(p=>p.text).join(''),longText);assert.ok(pages.every(p=>p.text.length<=180));
 const fourth=speech.speak(longText,{onPage:p=>seen.push(p)});await new Promise(setImmediate);
 utterances[3].onboundary({charIndex:pages[1].start});assert.equal(seen.at(-1).index,2);assert.equal(seen.at(-1).text,pages[1].text);
 speech.stop();assert.equal(await fourth,false);const count=seen.length;utterances[3].onboundary({charIndex:pages[1].start});assert.equal(seen.length,count);
 voices.length=0;assert.equal(await speech.speak('No voice'),false);console.log('PASS: female slow voice, complete paginated captions, completion/error/cancel and missing free voice.');
}test().catch(e=>{console.error(e);process.exitCode=1;});
