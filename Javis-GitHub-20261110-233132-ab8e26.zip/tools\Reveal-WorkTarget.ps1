param([Parameter(Mandatory=$true)][ValidatePattern('^[A-Fa-f0-9]{32}(?:,[A-Fa-f0-9]{32}){0,5}$')][string]$TargetIds)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
. (Join-Path $PSScriptRoot 'Chrome-Cdp.ps1')
. (Join-Path $PSScriptRoot 'Show-WorkWindow.ps1')
Add-Type -AssemblyName System.Windows.Forms
Add-Type -Path (Join-Path $PSScriptRoot 'jarvis_windows.cs')
$dpiContext=[JarvisWindowGuard]::UsePhysicalCoordinates()
$screen=[Windows.Forms.Screen]::AllScreens|Where-Object {-not $_.Primary}|Select-Object -First 1
if(-not $screen){$screen=[Windows.Forms.Screen]::PrimaryScreen}
$area=$screen.WorkingArea
$profile=Join-Path $root 'state/chrome-profile'
$pids=[uint32[]]@(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'"|Where-Object {
    $_.CommandLine -and $_.CommandLine.Contains($profile) -and $_.CommandLine -notmatch '\s--type='
}|ForEach-Object ProcessId)
if(-not $pids.Count){throw 'Owned browser is not running.'}
$mutex=New-Object Threading.Mutex($false,'Local\JarvisChromePage');$owned=$false;$client=$null
try{
    try{$owned=$mutex.WaitOne(12000)}catch [Threading.AbandonedMutexException]{$owned=$true}
    if(-not $owned){throw 'Another browser action is running.'}
    $client=Connect-JarvisCdp (Get-JarvisChromeEndpoint $root).webSocketDebuggerUrl
    $pages=@((Invoke-JarvisCdp $client 'Target.getTargets' @{}).targetInfos|Where-Object type -eq page)
    $rolesPath=Join-Path $root 'state/webspeech-live-browser.json'
    $voiceId=if(Test-Path $rolesPath){(Get-Content $rolesPath -Raw|ConvertFrom-Json).voice_target}else{''}
    $voice=$pages|Where-Object targetId -eq $voiceId|Select-Object -First 1
    $voiceWindow=if($voice){(Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$voiceId}).windowId}else{-1}
    $voiceWidth=if($voice){[Math]::Min(700,[int]($area.Width*.4))}else{0}
    $focus=[JarvisWindowGuard]::Foreground();$windows=@{};$ids=@($TargetIds -split ',')
    foreach($id in $ids){
        $page=$pages|Where-Object targetId -eq $id|Select-Object -First 1
        if(-not $page -or $id -eq $voiceId -or ($voiceId -and $page.openerId -eq $voiceId) -or $page.url -match '^http://(?:127\.0\.0\.1|localhost):876[56](?:/|$)'){throw 'Target is missing or is a protected listener/control.'}
        $window=Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$id}
        if($window.windowId -eq $voiceWindow){throw 'Target shares the protected voice window.'}
        if(-not $windows.ContainsKey([string]$window.windowId)){
            $shown=Show-JarvisWorkWindow $client $id $pids ($area.X+$voiceWidth) $area.Y ($area.Width-$voiceWidth) $area.Height
            if(-not $shown.visible){throw 'Work window could not be shown.'}
            $windows[[string]$window.windowId]=$shown
        }
    }
    @{visibility_verified=$true;placement_verified=$true;focus_kept=([JarvisWindowGuard]::Foreground() -eq $focus);targets=$ids;windows=@($windows.Values)}|ConvertTo-Json -Depth 6 -Compress
}finally{
    if($client){$client.socket.Dispose()};if($owned){$mutex.ReleaseMutex()};$mutex.Dispose()
    [JarvisWindowGuard]::RestoreCoordinates($dpiContext)
}
