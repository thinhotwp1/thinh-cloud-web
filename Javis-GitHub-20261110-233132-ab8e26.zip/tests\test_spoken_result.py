import json
import unittest
from pathlib import Path
import tempfile
from contextlib import nullcontext
from execution_result import parse_codex_result
from web_bridge import VoiceBridge
from desktop_tasks import DesktopRouter


class SpokenResultTests(unittest.TestCase):
    def payload(self,**values):
        return json.dumps(dict(version=2,outcome='success',reply='Có hai mục cần chú ý.',
            steps=[dict(label='Read dashboard',state='success',evidence='Two overdue items observed')],
            response_kind='answer',spoken_reply='Two items need your attention.',**values))
    def test_v2_answers_keep_english_speech_and_observed_success(self):
        result=parse_codex_result(self.payload())
        self.assertEqual(result.outcome,'success')
        self.assertEqual(result.response_kind,'answer')
        self.assertEqual(result.spoken_reply,'Two items need your attention.')
    def test_question_and_bounded_safe_speech(self):
        value=json.loads(self.payload());value.update(outcome='needs_input',response_kind='question',
            spoken_reply='Which project should I open?',question_options=['backend','frontend'])
        result=parse_codex_result(json.dumps(value))
        self.assertEqual(result.response_kind,'question');self.assertEqual(result.question_options,['backend','frontend'])
        value.update(spoken_reply='secret=abc '+ 'a'*900)
        result=parse_codex_result(json.dumps(value))
        self.assertNotIn('secret=abc',result.spoken_reply);self.assertLessEqual(len(result.spoken_reply),700)
    def test_long_spoken_answer_stops_at_a_complete_short_sentence(self):
        value=json.loads(self.payload());value['spoken_reply']='Here is the key result. '+('This extra explanation is too long to read aloud. '*20)
        result=parse_codex_result(json.dumps(value))
        self.assertLessEqual(len(result.spoken_reply),350);self.assertTrue(result.spoken_reply.endswith('.'))
    def test_shortening_clarification_keeps_the_question(self):
        value=json.loads(self.payload());value.update(outcome='needs_input',response_kind='question',
            spoken_reply=('I have finished the unambiguous steps and saved their results for this task. '*5)+'Which workspace should I open?')
        result=parse_codex_result(json.dumps(value));self.assertIn('Which workspace should I open?',result.spoken_reply);self.assertLessEqual(len(result.spoken_reply),350)
    def test_old_results_and_speech_never_promote_unverified_success(self):
        value=json.loads(self.payload());value.update(version=1);value.pop('response_kind');value.pop('spoken_reply')
        result=parse_codex_result(json.dumps(value));self.assertEqual(result.outcome,'success');self.assertEqual(result.response_kind,'action')
        value.update(version=2,response_kind='answer',spoken_reply='All done.',steps=[])
        self.assertEqual(parse_codex_result(json.dumps(value)).outcome,'unknown')
    def test_local_missing_workspace_asks_in_english_and_read_reuses_spoken_answer(self):
        with tempfile.TemporaryDirectory() as folder:
            calls=[];payload=self.payload()
            class Runner:
                def __init__(self,on_event):pass
                def run(self,text):calls.append(text);return payload
            bridge=VoiceBridge(Path(folder),runner_factory=Runner,mutex_factory=nullcontext)
            try:
                bridge.submit('missing',bridge.arm('Hey Javis')['grant'],'open workspace missing');bridge.worker.join(2)
                job=bridge.status('missing');self.assertIn('workspace',job['spoken_reply']);self.assertIn('question',job)
                bridge.submit('answer',bridge.arm('Hey Javis')['grant'],'what needs attention');bridge.worker.join(2)
                bridge.submit('read',bridge.arm('Hey Javis')['grant'],'read the result');bridge.worker.join(2)
                job=bridge.status('read');self.assertEqual(job['response_kind'],'answer');self.assertEqual(job['spoken_reply'],'Two items need your attention.')
                self.assertEqual(len(calls),1)
            finally:bridge.close()
    def test_bounded_local_information_is_spoken_without_model(self):
        with tempfile.TemporaryDirectory() as folder:
            router=DesktopRouter(Path(folder))
            for text,spoken in [('calculate 2 + 2','4'),('list workspaces','No workspaces are configured.')]:
                result=router.run(text)
                self.assertEqual(result.response_kind,'answer');self.assertEqual(result.spoken_reply,spoken)
