# Caller owns the Chrome mutex, CDP connection and owned-browser PID list.
function Show-JarvisWorkWindow($Client,[string]$TargetId,[uint32[]]$BrowserPids,[int]$X,[int]$Y,[int]$Width,[int]$Height) {
    $window=Invoke-JarvisCdp $Client 'Browser.getWindowForTarget' @{targetId=$TargetId}
    $handle=[IntPtr]::Zero
    $candidates=@([JarvisWindowGuard]::ChromeWindows($BrowserPids)|Where-Object {
        $isMin=[JarvisWindowGuard]::Minimized($_)
        $isMax=[JarvisWindowGuard]::Maximized($_)
        $r=[JarvisWindowGuard]::CdpBounds($_)
        $state=if($isMin){'minimized'}elseif($isMax){'maximized'}else{'normal'}
        $state -eq $window.bounds.windowState -and [JarvisWindowGuard]::NearBounds($r,$window.bounds.left,$window.bounds.top,$window.bounds.width,$window.bounds.height)
    })
    # A unique geometry/state match is already exact. Maximized geometry cannot
    # be challenged without first restoring it, so reject any ambiguity there.
    if($candidates.Count -eq 1){$handle=$candidates[0]}
    # Prove HWND/CDP identity by a reversible native geometry challenge. CDP's
    # setWindowBounds restores minimized Chrome with activation, so do not use it.
    # No saved HWND is trusted: Windows can recycle handles and bounds can match.
    foreach($candidate in $candidates){
        if($handle -ne [IntPtr]::Zero -or $window.bounds.windowState -eq 'maximized'){break}
        $minimized=[JarvisWindowGuard]::Minimized($candidate)
        $old=if($minimized){[JarvisWindowGuard]::RestoredBounds($candidate)}else{[JarvisWindowGuard]::Bounds($candidate)}
        $logical=[JarvisWindowGuard]::CdpBounds($candidate)
        if(-not [JarvisWindowGuard]::NearBounds($logical,$window.bounds.left,$window.bounds.top,$window.bounds.width,$window.bounds.height)){continue}
        $stageX=$X+13;$stageY=$Y+13;$stageW=$Width-43;$stageH=$Height-43
        # The exact target must change from its previous CDP bounds to our marker.
        if($window.bounds.left -eq $stageX -and $window.bounds.top -eq $stageY -and
           $window.bounds.width -eq $stageW -and $window.bounds.height -eq $stageH){$stageX+=7}
        try {
            if(-not [JarvisWindowGuard]::MarkGeometry($candidate,$stageX,$stageY,$stageW,$stageH)){continue}
            $actual=Invoke-JarvisCdp $Client 'Browser.getWindowForTarget' @{targetId=$TargetId}
            $actualRect=[int[]]@($actual.bounds.left,$actual.bounds.top,$actual.bounds.width,$actual.bounds.height)
            $marked=[JarvisWindowGuard]::CdpBounds($candidate)
            $changed=-not [JarvisWindowGuard]::NearBounds($actualRect,$window.bounds.left,$window.bounds.top,$window.bounds.width,$window.bounds.height)
            if($changed -and [JarvisWindowGuard]::NearBounds($actualRect,$marked[0],$marked[1],$marked[2],$marked[3])){$handle=$candidate}
        }finally{[void][JarvisWindowGuard]::MarkGeometry($candidate,$old[0],$old[1],$old[2],$old[3])}
        if($handle -ne [IntPtr]::Zero){break}
    }
    if($handle -eq [IntPtr]::Zero){throw 'Cannot identify the exact owned work window.'}
    $shown=[JarvisWindowGuard]::RevealWorkWindow($handle,$BrowserPids,$X,$Y,$Width,$Height)
    $actual=Invoke-JarvisCdp $Client 'Browser.getWindowForTarget' @{targetId=$TargetId}
    $actualRect=[int[]]@($actual.bounds.left,$actual.bounds.top,$actual.bounds.width,$actual.bounds.height)
    $logical=[JarvisWindowGuard]::CdpBounds($handle)
    if($actual.windowId -ne $window.windowId -or -not [JarvisWindowGuard]::NearBounds($actualRect,$logical[0],$logical[1],$logical[2],$logical[3]) -or $actual.bounds.windowState -ne 'normal'){$shown=$false}
    return @{window_id=$window.windowId;hwnd=$handle.ToInt64();visible=$shown}
}
