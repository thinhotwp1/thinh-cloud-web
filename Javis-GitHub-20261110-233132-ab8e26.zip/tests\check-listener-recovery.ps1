$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
$rolesPath=Join-Path $root 'state/webspeech-live-browser.json'
$saved=[IO.File]::ReadAllBytes($rolesPath)
try{
    $roles=Get-Content $rolesPath -Raw|ConvertFrom-Json
    $expected=$roles.voice_target;$roles.voice_target=[guid]::NewGuid().ToString('N')
    $roles|ConvertTo-Json|Set-Content $rolesPath -Encoding UTF8
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'tools/Show-VoiceDetails.ps1') -NoActivate
    if($LASTEXITCODE -ne 0){throw 'Stale listener target could not recover.'}
    if((Get-Content $rolesPath -Raw|ConvertFrom-Json).voice_target -ne $expected){throw 'Recovery did not resolve the existing owned listener.'}
    'PASS: stale remembered listener recovered without duplicate page or activation.'
}finally{[IO.File]::WriteAllBytes($rolesPath,$saved)}
