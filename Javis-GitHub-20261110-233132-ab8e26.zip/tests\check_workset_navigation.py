"""Explicit live-browser regression: preparation documents are never navigation success."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import subprocess
import threading
import time
from urllib.request import urlopen
import uuid

ROOT = Path(__file__).resolve().parents[1]
hits = []


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        hits.append(self.path)
        if self.path == '/slow':
            time.sleep(.3)
        body = '<!doctype html><meta charset="utf-8"><title>Javis navigation fixture</title><p>Sóng Gió</p>'.encode()
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *_):
        pass


server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
identifier = 'nav-' + uuid.uuid4().hex[:12]
fixture = ROOT / 'state' / ('workset-test-' + identifier)
fixture.mkdir()
url = f'http://127.0.0.1:{server.server_port}/slow'
manifest = fixture / 'workspaces.json'
manifest.write_text(json.dumps({'version': 1, 'workspaces': [
    {'id': identifier, 'name': 'Navigation fixture', 'enabled': True,
     'tabs': [{'id': 'slow', 'name': 'Slow local page', 'url': url}]}]}), encoding='utf-8')
created = []

try:
    def launch():
        result = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
                                 str(ROOT / 'tools/Open-Workset.ps1'), '-WorkspaceId', identifier,
                                 '-ConfigPath', str(manifest)], capture_output=True, encoding='utf-8-sig', timeout=40)
        assert result.returncode == 0, result.stderr
        return json.loads(result.stdout)

    first = launch()
    created = [tab['target_id'] for tab in first['tabs'] if tab.get('target_id')]
    assert first['tabs'][0]['state'] == 'opened', first
    assert first['tabs'][0]['current_url'] == url, first
    assert first['placement_verified'] and first['focus_kept'], first
    before = hits.count('/slow')
    second = launch()
    assert second['tabs'][0]['state'] == 'reused', second
    assert second['tabs'][0]['target_id'] == created[0], second
    assert hits.count('/slow') == before == 1, hits
    print('PASS: delayed HTTP navigation commits the requested document; reopening preserves it without another request.')
finally:
    port = (ROOT / 'state/chrome-profile/DevToolsActivePort').read_text().splitlines()[0]
    for target in created:
        try:
            with urlopen(f'http://127.0.0.1:{port}/json/close/{target}', timeout=3):
                pass
        except OSError:
            pass
    server.shutdown()
    server.server_close()
    thread.join()
