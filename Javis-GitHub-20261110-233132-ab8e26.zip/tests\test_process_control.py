"""Cancellation must stop actual owned processes, including descendants."""
import concurrent.futures
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
try:
    from process_control import Cancellation, TaskCancelled, run_cancellable
except ImportError:
    TaskCancelled = None
    run_cancellable = None
    Cancellation = None


class ProcessTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(run_cancellable, 'Owned process cancellation is not implemented')

    def test_precancelled_command_never_starts(self):
        with tempfile.TemporaryDirectory() as folder:
            marker = Path(folder) / 'started'
            cancel = threading.Event()
            cancel.set()
            with self.assertRaises(TaskCancelled):
                run_cancellable([sys.executable, '-c', 'import pathlib,sys;pathlib.Path(sys.argv[1]).touch()', str(marker)], cancel, 5)
            self.assertFalse(marker.exists())

    @unittest.skipUnless(os.name == 'nt', 'Windows suspended launch')
    def test_cancel_during_assignment_never_resumes_the_command(self):
        import process_control
        with tempfile.TemporaryDirectory() as folder:
            marker=Path(folder)/'must-not-start'
            cancel=Cancellation()
            assign=process_control.ProcessGroup.__init__
            resume=process_control._resume_owned_process
            def cancel_after_assignment(group,process):
                assign(group,process)
                cancel.set()
            def slow_resume(process):
                resume(process)
                until=time.monotonic()+1
                while not marker.exists() and time.monotonic()<until:time.sleep(.01)
            with patch.object(process_control.ProcessGroup,'__init__',cancel_after_assignment), patch.object(process_control,'_resume_owned_process',slow_resume):
                with self.assertRaises(TaskCancelled):
                    run_cancellable([sys.executable,'-c','import pathlib,sys;pathlib.Path(sys.argv[1]).touch()',str(marker)],cancel,4)
            self.assertFalse(marker.exists(),'A cancelled command resumed before cancellation ownership was registered')

    @unittest.skipUnless(os.name == 'nt', 'Windows job-object process trees')
    def test_cancel_stops_owned_parent_and_child_heartbeat(self):
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            heartbeat = folder / 'heartbeat'
            script = folder / 'parent.py'
            script.write_text('''import subprocess,sys,time
subprocess.Popen([sys.executable,"-c","import pathlib,sys,time; p=pathlib.Path(sys.argv[1]);\\nwhile True: p.write_text(str(time.monotonic())); time.sleep(.03)",sys.argv[1]])
print("parent ready",flush=True)
time.sleep(60)
''', encoding='utf-8')
            cancel = threading.Event()
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(run_cancellable, [sys.executable, str(script), str(heartbeat)], cancel, 8)
                try:
                    until = time.monotonic() + 4
                    while not heartbeat.exists() and time.monotonic() < until:
                        time.sleep(.02)
                    self.assertTrue(heartbeat.exists(), 'Child heartbeat did not start')
                    cancel.set()
                    with self.assertRaises(TaskCancelled):
                        future.result(timeout=4)
                    before = heartbeat.read_bytes()
                    time.sleep(.15)
                    self.assertEqual(heartbeat.read_bytes(), before, 'Owned descendant survived cancellation')
                finally:
                    cancel.set()

    def test_normal_command_returns_stdout_and_timeout_stops_it(self):
        completed = run_cancellable([sys.executable, '-c', 'print("ready")'], threading.Event(), 5)
        self.assertEqual(completed.stdout.strip(), 'ready')
        with self.assertRaises(subprocess.TimeoutExpired):
            run_cancellable([sys.executable, '-c', 'import time;time.sleep(60)'], threading.Event(), .15)

    @unittest.skipUnless(os.name == 'nt', 'Windows owned process trees')
    def test_launch_is_tracked_before_an_early_child_can_escape(self):
        from process_control import ProcessGroup
        with tempfile.TemporaryDirectory() as folder:
            folder=Path(folder);heartbeat=folder/'heartbeat';pidfile=folder/'child.pid'
            script=folder/'parent.py'
            script.write_text('''import pathlib,subprocess,sys,time
child=subprocess.Popen([sys.executable,"-c","import pathlib,sys,time; p=pathlib.Path(sys.argv[1]);\\nwhile True: p.write_text(str(time.monotonic())); time.sleep(.03)",sys.argv[1]],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
pathlib.Path(sys.argv[2]).write_text(str(child.pid))
time.sleep(60)
''',encoding='utf-8')
            original=ProcessGroup.__init__
            def delayed(group,process):
                time.sleep(.3)
                original(group,process)
            cancel=threading.Event()
            try:
                with patch.object(ProcessGroup,'__init__',delayed), concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future=pool.submit(run_cancellable,[sys.executable,str(script),str(heartbeat),str(pidfile)],cancel,8)
                    until=time.monotonic()+4
                    while not heartbeat.exists() and time.monotonic()<until:time.sleep(.02)
                    self.assertTrue(heartbeat.exists())
                    cancel.set()
                    with self.assertRaises(TaskCancelled):future.result(timeout=4)
                    before=heartbeat.read_bytes();time.sleep(.15)
                    self.assertEqual(heartbeat.read_bytes(),before,'Early child escaped before job assignment')
            finally:
                cancel.set()
                if pidfile.exists():
                    subprocess.run(['taskkill.exe','/PID',pidfile.read_text(),'/T','/F'],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)

    @unittest.skipUnless(os.name == 'nt', 'Windows owned process trees')
    def test_cancel_after_parent_exit_still_terminates_owned_descendants(self):
        with tempfile.TemporaryDirectory() as folder:
            folder=Path(folder);heartbeat=folder/'heartbeat';pidfile=folder/'child.pid'
            script=folder/'parent.py'
            script.write_text('''import pathlib,subprocess,sys,time
child=subprocess.Popen([sys.executable,"-c","import pathlib,sys,time; p=pathlib.Path(sys.argv[1]);\\nwhile True: p.write_text(str(time.monotonic())); time.sleep(.03)",sys.argv[1]],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
pathlib.Path(sys.argv[2]).write_text(str(child.pid))
while not pathlib.Path(sys.argv[1]).exists():time.sleep(.01)
''',encoding='utf-8')
            cancel=threading.Event();original=subprocess.Popen.communicate
            def completed(process,*args,**kwargs):
                result=original(process,*args,**kwargs)
                cancel.set()  # Exact race boundary: parent exited, descendants still alive.
                return result
            try:
                with patch.object(subprocess.Popen,'communicate',completed):
                    with self.assertRaises(TaskCancelled):
                        run_cancellable([sys.executable,str(script),str(heartbeat),str(pidfile)],cancel,5)
                before=heartbeat.read_bytes();time.sleep(.15)
                self.assertEqual(heartbeat.read_bytes(),before,'Cancellation left an owned background child alive')
            finally:
                if pidfile.exists():
                    subprocess.run(['taskkill.exe','/PID',pidfile.read_text(),'/T','/F'],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)


if __name__ == '__main__':
    unittest.main()
