$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
. (Join-Path $root 'tools/Chrome-Cdp.ps1')
Add-Type -Path (Join-Path $root 'tools/jarvis_windows.cs')
$client=Connect-JarvisCdp (Get-JarvisChromeEndpoint $root).webSocketDebuggerUrl
$statePath=Join-Path $root 'state/browser.json'
$saved=if(Test-Path $statePath){[IO.File]::ReadAllBytes($statePath)}else{$null}
$rolesPath=Join-Path $root 'state/webspeech-live-browser.json'
$savedRoles=[IO.File]::ReadAllBytes($rolesPath)
$target=''
try{
    $target=(Invoke-JarvisCdp $client 'Target.createTarget' @{url='about:blank';newWindow=$true;background=$true;focus=$false}).targetId
    @{target_id=$target;endpoint=(Get-JarvisChromeEndpoint $root).http}|ConvertTo-Json|Set-Content $statePath -Encoding UTF8
    $window=Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$target}
    [void](Invoke-JarvisCdp $client 'Browser.setWindowBounds' @{windowId=$window.windowId;bounds=@{windowState='minimized'}})
    $anchor=[JarvisWindowGuard]::Foreground()
    # A previously closed listener leaves a stale remembered target ID.
    $roles=Get-Content $rolesPath -Raw|ConvertFrom-Json
    $roles.voice_target=[guid]::NewGuid().ToString('N').ToUpperInvariant()
    $roles|ConvertTo-Json|Set-Content $rolesPath -Encoding UTF8
    $result=& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'tools/Open-Chrome.ps1') -Url about:blank
    if($LASTEXITCODE -ne 0){throw 'General browser navigation failed.'}
    [IO.File]::WriteAllBytes($rolesPath,$savedRoles)
    if(($result|ConvertFrom-Json).target_id -ne $target){throw 'General navigation replaced the requested target.'}
    $actual=Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$target}
    if($actual.bounds.windowState -ne 'normal'){throw 'General work window was not restored.'}
    if([JarvisWindowGuard]::Foreground() -ne $anchor){throw 'General work restoration stole keyboard focus.'}
    foreach($mode in @('maximized','minimized-from-maximized')){
        [void](Invoke-JarvisCdp $client 'Browser.setWindowBounds' @{windowId=$window.windowId;bounds=@{windowState='maximized'}})
        if($mode -eq 'minimized-from-maximized'){
            [void](Invoke-JarvisCdp $client 'Browser.setWindowBounds' @{windowId=$window.windowId;bounds=@{windowState='minimized'}})
        }
        Start-Sleep -Milliseconds 150
        $anchor=[JarvisWindowGuard]::Foreground()
        $result=& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'tools/Open-Chrome.ps1') -Url about:blank
        if($LASTEXITCODE -ne 0){throw "General restoration failed from $mode."}
        $actual=Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$target}
        if($actual.bounds.windowState -ne 'normal'){throw "Work window was not restored from $mode."}
        if([JarvisWindowGuard]::Foreground() -ne $anchor){throw "Restoration from $mode changed focus: before=$anchor after=$([JarvisWindowGuard]::Foreground()) target=$($actual.windowId)."}
    }
    'PASS: minimized general work tab restored/revealed in place, target reused, keyboard focus preserved.'
}finally{
    if($target){[void](Invoke-JarvisCdp $client 'Target.closeTarget' @{targetId=$target})}
    $client.socket.Dispose()
    [IO.File]::WriteAllBytes($rolesPath,$savedRoles)
    if($null -ne $saved){[IO.File]::WriteAllBytes($statePath,$saved)}
    else{Remove-Item -LiteralPath $statePath -ErrorAction SilentlyContinue}
}
