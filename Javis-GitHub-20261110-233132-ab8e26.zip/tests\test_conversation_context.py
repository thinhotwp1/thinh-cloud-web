from pathlib import Path
from contextlib import nullcontext
import json
import tempfile
import threading
import unittest
from unittest.mock import patch
from memory_store import MemoryStore
from web_bridge import VoiceBridge
from execution_result import ExecutionResult


class ConversationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.store=MemoryStore(self.root)
    def tearDown(self):self.temp.cleanup()
    def record(self,identifier,text,reply='Opened dashboard',outcome='success',executor='local'):
        job=dict(id=identifier,text=text,reply=reply,state='completed',outcome=outcome,executor=executor)
        self.store.begin_job(job,'g');self.store.finish_job(job,[dict(label='Open dashboard',state=outcome,evidence='http://localhost:47131/')])
    def test_context_survives_restart_is_bounded_and_not_raw_page_history(self):
        self.record('one','Open dashboard http://localhost:47131/?token=private')
        self.record('two','Dashboard này có gì đáng lưu ý?',reply='summary '*1000,executor='codex')
        self.store.begin_job(dict(id='current',text='unfinished',state='queued'),'g')
        context=MemoryStore(self.root).conversation_context('current')
        self.assertIn('47131',context);self.assertIn('Dashboard này',context)
        self.assertNotIn('private',context);self.assertNotIn('unfinished',context)
        self.assertLessEqual(len(context.encode()),6000)
    def test_browser_context_uses_small_redacted_observations_only(self):
        (self.root/'state/browser.json').write_text(json.dumps(dict(target_id='target',current_url='http://user:pass@localhost:47131/?token=secret#x',title='Dashboard',observed_at='2026-11-07T12:00:00Z',body='private page body')))
        context=self.store.conversation_context()
        self.assertIn('http://localhost:47131/',context)
        for secret in ('secret','user:pass','private page body'):self.assertNotIn(secret,context)
    def test_local_open_is_visible_to_next_codex_turn_without_extra_model_call(self):
        captured=[]
        class Runner:
            def __init__(self,on_event):pass
            def run(self,text):captured.append(text);return 'answer'
            def cancel(self):pass
        bridge=VoiceBridge(self.root,runner_factory=Runner,mutex_factory=nullcontext)
        def submit(identifier,text):
            bridge.submit(identifier,bridge.arm('Hi Javis')['grant'],text)
            bridge.worker.join(3);self.assertFalse(bridge.worker.is_alive());return bridge.status(identifier)
        try:
            with patch.object(bridge.desktop,'run',return_value=ExecutionResult('Opened http://localhost:47131/','success',[dict(label='Open dashboard',state='success',evidence='http://localhost:47131/')])):
                submit('open','mở dashboard localhost cổng 47131')
            self.assertEqual(captured,[])
            submit('follow','Dashboard này có gì đáng lưu ý?')
            self.assertEqual(len(captured),1)
            self.assertIn('47131',captured[0]);self.assertIn('RECENT CONVERSATION',captured[0])
            self.assertTrue(captured[0].startswith('Dashboard này có gì đáng lưu ý?'))
        finally:bridge.close()
    def test_prior_summary_does_not_turn_new_request_into_summary(self):
        self.record('summary','summarize today')
        captured=[]
        class Runner:
            def __init__(self,on_event):pass
            def run(self,text):captured.append(text);return 'answer'
            def cancel(self):pass
        bridge=VoiceBridge(self.root,runner_factory=Runner,mutex_factory=nullcontext)
        try:
            bridge.submit('new',bridge.arm('Hi Javis')['grant'],'open dashboard');bridge.worker.join(3)
            self.assertIn('RECENT CONVERSATION',captured[0]);self.assertNotIn('[HISTORICAL DATA',captured[0])
        finally:bridge.close()
