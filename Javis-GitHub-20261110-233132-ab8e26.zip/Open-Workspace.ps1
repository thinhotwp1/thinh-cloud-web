param([switch]$Describe)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$profile = Join-Path $root 'state\vscode-profile'
$extensions = Join-Path $env:USERPROFILE '.vscode\extensions'
$workspace = Join-Path $root 'Jarvis.code-workspace'
$code = Join-Path $env:LOCALAPPDATA 'Programs\Microsoft VS Code\Code.exe'
if (-not (Test-Path -LiteralPath $code)) { $code = Join-Path $env:ProgramFiles 'Microsoft VS Code\Code.exe' }
if (-not (Test-Path -LiteralPath $code)) { throw 'VS Code executable not found.' }
if ($Describe) {
    @{Executable=$code; Profile=$profile; Workspace=$workspace; ExistingProfilesModified=$false} | ConvertTo-Json
    exit 0
}
$mutex = New-Object System.Threading.Mutex($false, 'Local\JarvisWorkspaceLauncher')
$owned = $false
$guard = $null
try {
    try { $owned=$mutex.WaitOne(0) } catch [System.Threading.AbandonedMutexException] { $owned=$true }
    if (-not $owned) { throw 'Jarvis workspace is already opening.' }
    $existing = @(Get-CimInstance Win32_Process -Filter "Name='Code.exe'" | Where-Object {
        $_.CommandLine -and $_.CommandLine.Contains($profile) -and $_.CommandLine -notmatch '\s--type='
    })
    if ($existing.Count -gt 0) {
        Write-Host 'The dedicated Jarvis VS Code window is already open. Use its existing terminal.'
        exit 0
    }
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -Path (Join-Path $root 'tools\jarvis_windows.cs')
    $screen = [System.Windows.Forms.Screen]::AllScreens | Where-Object { -not $_.Primary } | Select-Object -First 1
    if (-not $screen) { $screen=[Windows.Forms.Screen]::PrimaryScreen }
    $area = $screen.WorkingArea
    $guard=New-Object JarvisWindowGuard($area.X,$area.Y,$area.Width,$area.Height,([string[]]@('Code')),'Chrome_WidgetWin_',([uint32[]]@()))
    $info = New-Object System.Diagnostics.ProcessStartInfo
    $info.FileName = $code
    # These paths cannot end in a backslash and come from the local filesystem.
    $info.Arguments = '--user-data-dir="{0}" --extensions-dir="{1}" --new-window "{2}"' -f $profile,$extensions,$workspace
    $info.UseShellExecute=$false
    $info.CreateNoWindow=$true
    $info.WindowStyle=[Diagnostics.ProcessWindowStyle]::Minimized
    $info.EnvironmentVariables.Remove('ELECTRON_RUN_AS_NODE')
    $p=[Diagnostics.Process]::Start($info)
    $guard.AllowProcess([uint32]$p.Id)
    $p.Dispose()
    # Observe startup without sending any keystrokes or changing app settings.
    $until=(Get-Date).AddSeconds(18)
    while((Get-Date) -lt $until) {
        $processes=@(Get-CimInstance Win32_Process -Filter "Name='Code.exe'" | Where-Object {
            $_.CommandLine -and $_.CommandLine.Contains($profile) -and $_.CommandLine -notmatch '\s--type='
        })
        foreach($process in $processes) { $guard.AllowProcess([uint32]$process.ProcessId) }
        Start-Sleep -Milliseconds 250
    }
    $guard.Dispose()
    $windows=@($guard.ManagedHandles() | ForEach-Object {
        @{handle=$_.ToInt64(); bounds=[JarvisWindowGuard]::Bounds($_)}
    })
    $windows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $root 'state\workspace-window.json') -Encoding UTF8
    $guard.Drain() | Set-Content -LiteralPath (Join-Path $root 'state\workspace-window.log') -Encoding UTF8
    if($windows.Count -eq 0) { throw 'VS Code startup timed out before a visible Jarvis window could be verified. No placement success is assumed; inspect state/workspace-window.log.' }
    foreach($window in $windows) {
        if($window.bounds[0] -ne $area.X -or $window.bounds[1] -ne $area.Y -or
            $window.bounds[2] -ne $area.Width -or $window.bounds[3] -ne $area.Height) {
            throw 'The dedicated VS Code window was created but its secondary-display bounds could not be verified.'
        }
    }
    Write-Host 'Jarvis workspace opened on the secondary display. Run task: Jarvis: Talk to Codex.'
} finally {
    if($guard) { $guard.Dispose() }
    if($owned) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
}
