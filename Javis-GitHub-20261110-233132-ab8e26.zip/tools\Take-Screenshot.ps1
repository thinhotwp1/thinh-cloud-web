param([Parameter(Mandatory=$true)][string]$OutputPath)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
$folder=[IO.Path]::GetFullPath((Join-Path $root 'state/screenshots'))
$target=[IO.Path]::GetFullPath($OutputPath)
if(-not [string]::Equals([IO.Path]::GetDirectoryName($target),$folder,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetExtension($target) -ne '.png') {throw 'Screenshot path must be a PNG inside Javis state/screenshots.'}
Add-Type -AssemblyName System.Windows.Forms,System.Drawing
if(-not ('JarvisWindowGuard' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'jarvis_windows.cs')}
$previous=[JarvisWindowGuard]::UsePhysicalCoordinates()
$image=$null
try {
  $screens=@([Windows.Forms.Screen]::AllScreens)
  $left=[int]::MaxValue;$top=[int]::MaxValue;$right=[int]::MinValue;$bottom=[int]::MinValue
  foreach($screen in $screens){
    $left=[Math]::Min($left,$screen.Bounds.Left);$top=[Math]::Min($top,$screen.Bounds.Top)
    $right=[Math]::Max($right,$screen.Bounds.Right);$bottom=[Math]::Max($bottom,$screen.Bounds.Bottom)
  }
  $width=[int]($right-$left);$height=[int]($bottom-$top)
  if($width -lt 1 -or $height -lt 1 -or [long]$width*$height -gt 50000000){throw 'Screen bounds exceed the capture limit.'}
  [IO.Directory]::CreateDirectory($folder)|Out-Null
  $image=New-Object -TypeName Drawing.Bitmap -ArgumentList @($width,$height)
  $graphics=[Drawing.Graphics]::FromImage($image)
  try{$graphics.CopyFromScreen([int]$left,[int]$top,0,0,$image.Size)}finally{$graphics.Dispose()}
  $image.Save($target,[Drawing.Imaging.ImageFormat]::Png)
  @{saved=$true;path=$target;width=$width;height=$height;monitors=$screens.Count}|ConvertTo-Json -Compress
}finally{if($image){$image.Dispose()};[JarvisWindowGuard]::RestoreCoordinates($previous)}
