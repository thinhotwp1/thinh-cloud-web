const assert=require('node:assert/strict'), fs=require('node:fs'), vm=require('node:vm');
const script=fs.readFileSync(require('node:path').join(__dirname,'../webspeech-probe/app.js'),'utf8');
const configuredAliases=JSON.parse(fs.readFileSync(require('node:path').join(__dirname,'../voice-config.json'),'utf8').replace(/^\uFEFF/, '')).wake_aliases;
const flush=async()=>{for(let i=0;i<12;i++)await new Promise(setImmediate);};
function setup({live=true,lostResponse=false,deferArms=false,deferMedia=false,fakeTimers=true,deferStop=false,runningJob=false,lostCancelResponse=false,deferAudio=false,deferCancel=false,inlineAudio=false,nativePet=false,outcome='success',nativeControls=[],terminalState='completed',deferNativeDone=false,withTTS=false,resultMetadata={},deferSpeech=false,deferYes=false,silenceMs=3000}={}) {
  const nodes=new Map(),calls=[],instances=[],jobs=new Map(),pendingArms=[],pendingMedia=[],pendingCancels=[],pendingNativeDone=[],ttsCalls=[],utterances=[];
  let fastConfig={version:1,actions:[{id:'favorites',type:'playlist',name:'Music',aliases:['play favorites'],url:null},{id:'today',type:'dashboard',name:'Today',aliases:['open today dashboard'],url:null},{id:'screens-off',type:'screens_off',name:'Screens off',aliases:['turn off screens']},{id:'lock',type:'lock',name:'Lock',aliases:['lock screen']},{id:'screenshot',type:'screenshot',name:'Screenshot',aliases:['take screenshot']}]};
  let configuredSilenceMs=silenceMs;
  const workPolicy=new Map();
  const timers=new Map();let clock=0,timerId=0;
  const schedule=(fn,ms)=>{const id=++timerId;timers.set(id,{fn,at:clock+ms});return id;};
  const advance=async ms=>{
    const end=clock+ms;
    while(true){const next=[...timers].filter(([,t])=>t.at<=end).sort((a,b)=>a[1].at-b[1].at)[0];if(!next)break;clock=next[1].at;timers.delete(next[0]);next[1].fn();await flush();}
    clock=end;await flush();
  };
  const stream=label=>({getAudioTracks:()=>[{label}],getTracks:()=>[{stop(){}}]});
  const node=id=>{if(!nodes.has(id))nodes.set(id,{value:id==='task-language'?'vi-VN':'',textContent:'',disabled:false});return nodes.get(id);};
  class Speech {
    constructor(){instances.push(this);}
    start(){this.onstart?.();}
    abort(){queueMicrotask(()=>this.onend?.());}
    stop(){this.stopCalls=(this.stopCalls||0)+1;if(!deferStop)queueMicrotask(()=>this.onend?.());}
    result(text,final,index=0){this.results??=[];const result=[{transcript:text}];result.isFinal=final;this.results[index]=result;this.onresult?.({resultIndex:index,results:this.results});}
    final(text,index=0){this.result(text,true,index);}
    interim(text,index=0){this.result(text,false,index);}
  }
  class Audio {
    constructor(){this.state='running';this.currentTime=0;this.destination={};}
    resume(){return Promise.resolve();}
    decodeAudioData(){return Promise.resolve({duration:.3});}
    createBufferSource(){const source={connect(){},disconnect(){},stop(){},start(){if(!deferAudio)queueMicrotask(()=>source.onended?.());}};audioSources.push(source);return source;}
    createGain(){return{gain:{setValueAtTime(){},linearRampToValueAtTime(){}},connect(){},disconnect(){}};}
    createOscillator(){return{frequency:{},connect(){},disconnect(){},start(){},stop(){queueMicrotask(()=>this.onended?.());}};}
  }
  const audioSources=[];
  const context=vm.createContext({console,atob,URLSearchParams,setTimeout:fakeTimers?schedule:setTimeout,clearTimeout:fakeTimers?id=>timers.delete(id):clearTimeout,AbortController,queueMicrotask,
    SpeechSynthesisUtterance:function(text){this.text=text;},
    crypto:{randomUUID:()=> 'test-request'},window:{SpeechRecognition:Speech,AudioContext:Audio,addEventListener(){},speechSynthesis:{getVoices:()=>withTTS||nativePet?[{name:'Microsoft David',lang:'en-US',localService:true},{name:'Microsoft Zira',lang:'en-US',localService:true}]:[],speak(u){ttsCalls.push(u.text);utterances.push(u);if(u.text==='Yes'?!deferYes:!deferSpeech)queueMicrotask(()=>u.onend?.());},cancel(){}}},
    document:{getElementById:node,body:{dataset:{}}},
    navigator:{mediaDevices:{getUserMedia:async()=>deferMedia?await new Promise((resolve,reject)=>pendingMedia.push({resolve,reject})):stream('Working USB microphone')}},
    fetch:async(path,options={})=>{
      calls.push({path,body:options.body?JSON.parse(options.body):null}); let value;
      if(path==='/yes.wav')return{ok:true,arrayBuffer:async()=>new ArrayBuffer(8)};
      if(path==='/config')value={native_pet:nativePet,execution_enabled:live,csrf_token:'token',wake_aliases:configuredAliases,session_id:'saved-session',silence_ms:configuredSilenceMs,ready_audio:inlineAudio?'UklGRg==':null};
      else if(path==='/api/voice-settings'){configuredSilenceMs=JSON.parse(options.body).silence_seconds*1000;value={silence_seconds:configuredSilenceMs/1000};}
      else if(path==='/api/pet/claim')value={lease:'lease'};
      else if(path==='/api/pet/publish'){value={controls:nativeControls.splice(0),native_connected:false,sound_enabled:true};}
      else if(path==='/api/pet/audio'&&JSON.parse(options.body).clip==='done'&&deferNativeDone)value=await new Promise(resolve=>pendingNativeDone.push(resolve));
      else if(path==='/api/pet/audio'||path==='/api/pet/audio/stop')value={played:true};
      else if(path==='/api/state')value={active:null};
      else if(path==='/api/workspaces')value={workspaces:[{id:'daily',name:'Hằng ngày',enabled:true,tabs:[]}]};
      else if(path==='/api/fast-actions')value=fastConfig;
      else if(path==='/api/fast-actions/save'){fastConfig=JSON.parse(options.body).config;value=fastConfig;}
      else if(path==='/api/work/import'){const input=JSON.parse(options.body);value={source:input.source,imported:input.items.length};}
      else if(path.startsWith('/api/work/policy?')){const source=new URLSearchParams(path.split('?')[1]).get('source');value={source,allow_ai:workPolicy.get(source)===true};}
      else if(path==='/api/work/policy'){const input=JSON.parse(options.body);workPolicy.set(input.source,input.allow_ai);value=input;}
      else if(path==='/api/work/goals')value={goals:[]};
      else if(path==='/api/work/goal')value={id:'goal1',name:JSON.parse(options.body).name};
      else if(path==='/api/work/decision')value={id:'decision1'};
      else if(path==='/api/arm')value=deferArms?await new Promise((resolve,reject)=>pendingArms.push({resolve,reject})):{grant:'one-grant'};
      else if(path==='/api/busy/arm')value={grant:'busy-grant',active_job_id:'test-request'};
      else if(path==='/api/busy/cancel'){const target=JSON.parse(options.body).active_job_id;if(jobs.has(target))jobs.get(target).state='cancelled';jobs.get('test-request').state='cancelled';value={id:target,state:'cancelled',outcome:'cancelled'};}
      else if(path==='/api/busy/replace'){
        const input=JSON.parse(options.body);
        jobs.get('test-request').state='cancelled';
        value={id:input.request_id,text:input.text,state:'queued',outcome:'unknown',events:[],replaces_job_id:'test-request'};
        jobs.set(value.id,value);
        schedule(()=>jobs.set(value.id,{...value,state:'completed',outcome:'success',response_kind:'action',reply:'new complete'}),200);
      }
      else if(path==='/api/disarm')value={ok:true};
      else if(path==='/api/requests'){
        const input=JSON.parse(options.body);value={id:input.request_id,text:input.text,outcome,state:runningJob?'running':terminalState,reply:'Đã mở',error:'',events:[],...resultMetadata};jobs.set(value.id,value);
        if(lostResponse)throw new Error('response lost');
      }else if(path==='/api/local-actions'){
        const input=JSON.parse(options.body),action=fastConfig.actions.find(item=>item.id===input.action_id);
        value={id:input.request_id,text:action.name,state:'completed',outcome:'success',executor:'local',response_kind:'action',reply:'Local action done',events:[]};jobs.set(value.id,value);
      }else if(path.startsWith('/api/jobs/')&&path.endsWith('/cancel')){
        value=jobs.get('test-request');value.state='cancelling';
        if(deferCancel)value=await new Promise(resolve=>pendingCancels.push(resolve));
        if(lostCancelResponse)throw new Error('cancel response lost');
      }else if(path.startsWith('/api/jobs/'))value=jobs.get(decodeURIComponent(path.slice('/api/jobs/'.length)));
      else if(path.startsWith('/api/questions/')&&path.endsWith('/arm'))value={grant:'answer-grant',expires_in:20};
      else if(path.startsWith('/api/questions/')&&path.endsWith('/dismiss'))value={ok:true};
      else if(path.startsWith('/api/questions/')&&path.endsWith('/answer')){const input=JSON.parse(options.body);value={id:input.request_id,text:input.text,outcome:'success',state:'completed',response_kind:'answer',spoken_reply:'The backend is open.',reply:'Opened backend.',events:[]};jobs.set(value.id,value);}
      else throw new Error('Unexpected endpoint '+path);
      return{ok:true,json:async()=>value};
    }});
  context.window.setTimeout=context.setTimeout;context.window.clearTimeout=context.clearTimeout;context.window.SpeechSynthesisUtterance=context.SpeechSynthesisUtterance;
  vm.runInContext(fs.readFileSync(require('node:path').join(__dirname,'../webspeech-probe/speech.js'),'utf8'),context);
  vm.runInContext(script,context);
  return{context,node,calls,instances,pendingArms,pendingMedia,pendingCancels,pendingNativeDone,ttsCalls,utterances,advance,stream,jobs,audioSources,state:context.window.jarvisProbeState,stop:()=>node('stop').onclick()};
}
module.exports={setup,flush};
if(require.main===module)(async()=>{
  const heartbeat=setup({nativePet:true,runningJob:true,nativeControls:[{id:'summary',action:'summary',payload:{}}]});
  await flush();await heartbeat.advance(7000);
  assert.equal(heartbeat.calls.filter(c=>c.path==='/api/requests').length,1);
  assert.ok(heartbeat.calls.filter(c=>c.path==='/api/pet/publish').length>=8,'long task must not stop pet heartbeat');heartbeat.stop();
  for(const outcome of ['success','partial','unknown','needs_input']){
    const native=setup({nativePet:true,outcome});await flush();await native.node('start').onclick();
    native.instances.at(-1).final('Hi Javis');await flush();
    assert.equal(native.ttsCalls.filter(text=>text==='Yes').length,1);
    native.instances.at(-1).final('open requested page');native.instances.at(-1).onend();await native.advance(3000);
    assert.equal(native.calls.filter(c=>c.path==='/api/pet/audio'&&c.body.clip==='done').length,outcome==='success'?1:0);
    native.stop();await flush();
  }
  let app=setup();await flush();await app.node('start').onclick();
  app.instances.at(-1).final('Hey Davis');await flush();
  assert.equal(app.instances.at(-1).lang,'vi-VN');
  const task=app.instances.at(-1);task.final('Mở YouTube bài Sóng Gió.');task.onend();task.onend();await app.advance(3000);
  assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,1);
  assert.equal(app.calls.find(c=>c.path==='/api/requests').body.text,'Mở YouTube bài Sóng Gió.');
  assert.equal(app.state.job.state,'completed');assert.equal(app.instances.at(-1).lang,'vi-VN');app.stop();
  app=setup({fakeTimers:true});await flush();await app.node('start').onclick();app.instances.at(-1).final('Hey Jarvis');await flush();
  let speech=app.instances.at(-1);speech.onspeechstart();speech.final('Open YouTube');speech.onspeechend();
  await app.advance(2999);assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);
  await app.advance(1);assert.equal(speech.stopCalls,1);assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,1);app.stop();
  app=setup({fakeTimers:true,deferStop:true});await flush();await app.node('start').onclick();app.instances.at(-1).final('Hey Jarvis');await flush();
  speech=app.instances.at(-1);speech.onspeechstart();speech.interim('Mở YouTube');speech.onspeechend();await app.advance(3000);
  assert.equal(speech.stopCalls,1);assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);
  speech.final('Mở YouTube bài Sóng Gió');speech.onend();await flush();
  assert.equal(app.calls.find(c=>c.path==='/api/requests').body.text,'Mở YouTube bài Sóng Gió');app.stop();
  // Chrome may remove its trailing interim hypothesis, even with resultIndex === results.length.
  for(const replacementWithFinal of [true,false]) {
    app=setup();await flush();await app.node('start').onclick();app.instances.at(-1).final('Hey Jarvis');await flush();
    speech=app.instances.at(-1);speech.onspeechstart();
    speech.interim('bắt đầu ngày làm việc',0);speech.interim('âm tạm bị Chrome bỏ',1);
    if(replacementWithFinal) {
      speech.results.length=1;speech.final('bắt đầu ngày làm việc',0);
    } else {
      speech.final('bắt đầu ngày làm việc',0);speech.results.length=1;
      speech.onresult({resultIndex:1,results:speech.results});
    }
    speech.onspeechend();await app.advance(2999);
    assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);
    await app.advance(1);
    assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,1,'A removed interim tail must not block the already-final task');
    assert.equal(app.calls.find(c=>c.path==='/api/requests').body.text,'bắt đầu ngày làm việc');app.stop();
  }
  app=setup();await flush();await app.node('start').onclick();app.instances.at(-1).final('Hey Jarvis');await flush();
  app.instances.at(-1).final('Canceled task');app.stop();await app.node('start').onclick();app.instances.at(-1).final('Hey Jarvis');await flush();
  app.instances.at(-1).onend();await app.advance(3000);
  assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);assert.equal(app.state.phase,'wake');app.stop();
  app=setup();await flush();await app.node('start').onclick();app.instances.at(-1).final('Hey Jarvis');await flush();
  speech=app.instances.at(-1);speech.onspeechstart();await app.advance(28000);speech.final('Complete task');speech.onspeechend();
  await app.advance(2000);assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);
  await app.advance(1000);assert.equal(speech.stopCalls,1);assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,1);app.stop();
  app=setup();await flush();await app.node('start').onclick();app.instances.at(-1).final('Hey Jarvis');await flush();
  speech=app.instances.at(-1);speech.onspeechstart();speech.final('Early engine end');speech.onspeechend();await app.advance(1000);speech.onend();await flush();
  assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);await app.advance(1999);
  assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);await app.advance(1);
  assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,1);app.stop();
  app=setup();await flush();await app.node('start').onclick();app.instances.at(-1).final('Hey Jarvis');await flush();
  speech=app.instances.at(-1);speech.onspeechstart();await app.advance(59000);speech.interim('Still speaking');await app.advance(1000);
  assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);assert.equal(app.state.phase,'error');app.stop();
  app=setup({fakeTimers:true,deferStop:true});await flush();await app.node('start').onclick();app.instances.at(-1).final('Hey Jarvis');await flush();
  speech=app.instances.at(-1);speech.onspeechstart();speech.final('Mở YouTube');speech.interim('bài Sóng Gió',1);speech.onspeechend();
  await app.advance(5000);assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);
  assert.equal(app.state.phase,'error');app.stop();
  app=setup({fakeTimers:true});await flush();await app.node('start').onclick();app.instances.at(-1).final('Hey Jarvis');await flush();
  speech=app.instances.at(-1);speech.onspeechstart();speech.final('Mở YouTube');speech.onspeechend();await app.advance(2000);
  speech.onspeechstart();speech.interim('bài Sóng Gió',1);await app.advance(2000);
  assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);
  speech.final('bài Sóng Gió',1);speech.onspeechend();await app.advance(3000);
  assert.equal(app.calls.find(c=>c.path==='/api/requests').body.text,'Mở YouTube bài Sóng Gió');app.stop();
  app=setup();await flush();await app.node('start').onclick();
  const old=app.instances.at(-1);old.final('Hey Jarvis');app.stop();await flush();
  old.final('Stale task');assert.equal(app.calls.filter(c=>c.path==='/api/arm').length,0);
  assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);
  for(const oldFails of [false,true]) {
    app=setup({deferArms:true});await flush();await app.node('start').onclick();
    app.instances.at(-1).final('Hey Jarvis');await flush();app.stop();
    await app.node('start').onclick();app.instances.at(-1).final('Hey Jarvis');await flush();
    assert.equal(app.pendingArms.length,1,'Only one authorization may be in flight');
    if(oldFails)app.pendingArms[0].reject(new Error('Old request failed'));
    else app.pendingArms[0].resolve({grant:'obsolete-grant'});
    await flush();
    app.pendingArms[1].resolve({grant:'new-current-grant'});await flush();
    assert.equal(vm.runInContext('armGrant',app.context),'new-current-grant');
    assert.equal(app.state.phase,'task');app.stop();
  }
  for(const oldFails of [false,true]) {
    app=setup({deferMedia:true});await flush();const oldStart=app.node('start').onclick();await flush();app.stop();
    const currentStart=app.node('start').onclick();await flush();
    app.pendingMedia[1].resolve(app.stream('Current microphone'));await currentStart;await flush();
    if(oldFails)app.pendingMedia[0].reject(new Error('Old permission rejected'));
    else app.pendingMedia[0].resolve(app.stream('Obsolete microphone'));
    await oldStart;await flush();assert.equal(app.state.microphone,'Current microphone');
    assert.equal(app.state.phase,'wake');assert.equal(app.instances.length,1);app.stop();
  }
  app=setup({lostResponse:true});await flush();await app.node('start').onclick();app.instances.at(-1).final('Hey Jarvis');await flush();
  app.instances.at(-1).final('Open YouTube');app.instances.at(-1).onend();await app.advance(3000);
  assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,1);assert.equal(app.state.job.state,'completed');app.stop();
  app=setup({deferArms:true});await flush();
  assert.equal(typeof app.node('manual-send').onclick,'function','Typed commands must be available in live mode');
  app.node('manual-input').value='Tính 2 + 2';
  const manual=app.node('manual-send').onclick();await flush();
  app.node('manual-send').onclick();await flush();
  assert.equal(app.pendingArms.length,1,'Double click must not create a second grant');
  app.pendingArms[0].resolve({grant:'manual-grant'});await manual;await flush();
  assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,1);
  assert.equal(app.calls.find(c=>c.path==='/api/requests').body.text,'Tính 2 + 2');
  assert.equal(app.instances.length,0,'Typed input must not acquire the microphone');
  app=setup({deferArms:true});await flush();await app.node('start').onclick();
  app.instances.at(-1).final('Hey Jarvis');await flush();
  app.node('manual-input').value='Tính 7 + 8';const overlapping=app.node('manual-send').onclick();await flush();
  assert.equal(app.pendingArms.length,1,'A typed arm must wait for an outstanding voice arm');
  app.pendingArms[0].resolve({grant:'obsolete-voice'});await flush();
  assert.equal(app.pendingArms.length,2);
  app.pendingArms[1].resolve({grant:'typed-after-voice'});await overlapping;await flush();
  assert.equal(app.calls.find(c=>c.path==='/api/requests').body.grant,'typed-after-voice');app.stop();
  for(const name of ['Jarvis','Javis','David','Dave','Davie','Davids','Devis','Jervis','Jarvies']) for(const greeting of ['Hi','Hey']) {
    app=setup();await flush();await app.node('start').onclick();app.instances.at(-1).final(greeting+' '+name);await flush();
    assert.equal(app.state.phase,'task',name+' must reach READY');
    assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);app.stop();
  }
  app=setup();await flush();await app.node('start').onclick();
  for(const text of ['Tôi gặp David hôm qua','Hey Davidson','Hey Daveville'])app.instances.at(-1).final(text);
  await flush();assert.equal(app.calls.filter(c=>c.path==='/api/arm').length,0);app.stop();
  app=setup();await flush();await app.node('start').onclick();app.instances.at(-1).final('Hey Jarvis');await flush();
  app.instances.at(-1).final('Hi Jarvis');await flush();await app.advance(3000);
  assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0,'Repeating the wake name after READY is not a Codex task');
  assert.equal(app.state.phase,'task');app.stop();
  app=setup();await flush();await app.node('start').onclick();app.instances.at(-1).final('Hi Javis');await flush();
  speech=app.instances.at(-1);speech.onspeechstart();
  const address=[{transcript:'Hi Jarvis'}];address.isFinal=true;
  const actualTask=[{transcript:'Tính 2 + 2'}];actualTask.isFinal=true;
  speech.results=[address,actualTask];speech.onresult({resultIndex:0,results:speech.results});
  speech.onspeechend();await app.advance(3000);
  assert.equal(app.calls.find(c=>c.path==='/api/requests')?.body.text,'Tính 2 + 2','A wake-only segment must not discard a task already in the same snapshot');app.stop();
  app=setup({runningJob:true,lostCancelResponse:true});await flush();await app.node('start').onclick();
  app.instances.at(-1).final('Hi David');await flush();speech=app.instances.at(-1);
  speech.final('Wrong task');speech.onspeechend();await app.advance(3000);
  assert.equal(app.state.job.state,'running');
  assert.equal(typeof app.node('mini-cancel').onclick,'function','Compact controls need a real cancel action');
  await app.node('mini-cancel').onclick();await flush();
  assert.equal(app.state.job.state,'cancelling');assert.equal(app.node('start').disabled,true);
  assert.equal(app.calls.filter(c=>c.path.endsWith('/cancel')).length,1,'Lost cancel reply is recovered by status, never resubmitted');
  app.jobs.get('test-request').state='cancelled';await app.advance(1500);
  assert.equal(app.state.job.state,'cancelled');assert.equal(app.state.phase,'wake');app.stop();
  app=setup();await flush();await app.node('start').onclick();app.instances.at(-1).final('Hi Javis');await flush();
  speech=app.instances.at(-1);speech.interim('Wrong pending words');
  await app.node('mini-cancel').onclick();await flush();speech.final('Late wrong words');await app.advance(3000);
  assert.equal(app.calls.filter(c=>c.path==='/api/requests').length,0);assert.equal(app.state.phase,'wake');
  app.node('compact-toggle').onclick();assert.equal(app.context.document.body.dataset.compact,'true');
  app.node('compact-toggle').onclick();assert.equal(app.context.document.body.dataset.compact,'false');app.stop();
  app=setup({deferAudio:true});await flush();await app.node('start').onclick();app.instances.at(-1).final('Hi Jarvis');await flush();
  assert.equal(app.calls.filter(c=>c.path==='/yes.wav').length,1,'READY uses the cached Yes audio asset');
  assert.notEqual(app.state.phase,'task','Capture must wait for Yes to finish');
  app.audioSources[0].onended();await flush();assert.equal(app.state.phase,'task');app.stop();
  app=setup({runningJob:true,deferCancel:true});await flush();await app.node('start').onclick();
  app.instances.at(-1).final('Hi Javis');await flush();speech=app.instances.at(-1);speech.final('cancel this');speech.onspeechend();await app.advance(3000);
  const delayedCancel=app.node('mini-cancel').onclick();await flush();
  app.jobs.get('test-request').state='cancelled';await app.advance(1500);
  assert.equal(app.state.phase,'wake');
  app.pendingCancels[0]({id:'test-request',state:'cancelling',events:[]});await delayedCancel;await flush();
  assert.equal(app.state.job.state,'cancelled','A late cancel snapshot must not overwrite terminal polling');
  app.instances.at(-1).final('Hi Javis');await flush();
  assert.equal(app.state.phase,'task');assert.equal(app.node('mini-cancel').disabled,false);app.stop();
  app=setup({inlineAudio:true});await flush();await app.node('start').onclick();app.instances.at(-1).final('Hi Javis');await flush();
  assert.equal(app.state.phase,'task');
  assert.equal(app.calls.filter(c=>c.path==='/yes.wav').length,0,'Configured Yes bytes must not depend on a separate media download');app.stop();
  app=setup({live:false});await flush();await app.node('start').onclick();app.instances.at(-1).final('Hey Jarvis');await flush();
  app.instances.at(-1).final('Diagnostic only');app.instances.at(-1).onend();await flush();
  assert.equal(app.calls.filter(c=>c.path.startsWith('/api/')).length,0);app.stop();
  console.log('PASS: wake -> task -> exactly one request; stop/late callbacks; lost response recovery; probe stays nonexecuting.');
})().catch(error=>{console.error(error);process.exit(1);});
