from contextlib import nullcontext
import json
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest
from voice_core import CodexRunner
from urllib.request import Request,urlopen
from urllib.error import HTTPError

sys.path[:0]=[str(Path(__file__).resolve().parents[1]),str(Path(__file__).resolve().parents[1]/'tools')]
from web_bridge import VoiceBridge
from webspeech_live_server import make_server

class HttpTests(unittest.TestCase):
    def test_quick_button_submits_typed_local_action_without_codex_fallback(self):
        config=self.bridge.desktop.fast.list_actions()
        config['actions'].append({'id':'docs','type':'web','name':'Docs','aliases':['open docs'],'url':'https://docs.example.com/'})
        self.bridge.desktop.fast.save(config)
        opened=[]
        self.bridge.desktop.fast.open_url=lambda url:opened.append(url) or {'current_url':url,'visibility_verified':True}
        grant=self.request('/api/arm',{'wake':'Hi Davis'})[1]['grant']
        self.assertEqual(self.request('/api/local-actions',{'request_id':'bad','grant':grant,'action_id':'unknown'})[0],400)
        status,job=self.request('/api/local-actions',{'request_id':'docs-1','grant':grant,'action_id':'docs'})
        self.assertEqual(status,202,job)
        until=time.monotonic()+2
        while time.monotonic()<until:
            result=self.request('/api/jobs/docs-1')[1]
            if result['state']=='completed':break
            time.sleep(.01)
        self.assertEqual(result['executor'],'local')
        self.assertEqual(result['outcome'],'success')
        self.assertEqual(opened,['https://docs.example.com/'])
        self.assertEqual(self.calls,[])
    def test_voice_silence_setting_is_bounded_persistent_and_live(self):
        self.assertEqual(self.request('/config')[1]['silence_ms'],10000)
        for seconds in (4,21,'10',True):
            self.assertEqual(self.request('/api/voice-settings',{'silence_seconds':seconds})[0],400)
        for seconds in (5,20):
            status,value=self.request('/api/voice-settings',{'silence_seconds':seconds})
            self.assertEqual(status,200,value)
            self.assertEqual(value['silence_seconds'],seconds)
            self.assertEqual(self.request('/config')[1]['silence_ms'],seconds*1000)
        saved=json.loads((self.root/'voice-config.json').read_text(encoding='utf-8'))
        self.assertEqual(saved['webspeech_silence_seconds'],20)
        self.assertEqual(saved['wake_aliases'],['Davis'])
    def test_near_wake_can_arm_but_does_not_submit_work_by_itself(self):
        status,value=self.request('/api/arm',{'wake':'Hey Darvis'})
        self.assertEqual(status,200,value)
        self.assertIn('grant',value)
        self.assertEqual(self.calls,[])
        self.assertEqual(self.request('/api/arm',{'wake':'Hey Devil'})[0],400)
        self.assertEqual(self.request('/api/arm',{'wake':'Hey Darvis, run a task'})[0],400)
    def test_live_server_cannot_bind_diagnostic_or_arbitrary_origin(self):
        for port in (8765,8767):
            server=None
            try:
                with self.assertRaisesRegex(ValueError,'8766'):
                    server=make_server(self.root,port,self.bridge)
            finally:
                if server: server.server_close()

    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name)
        (self.root/'state').mkdir()
        (self.root/'voice-config.json').write_text('{"wake_aliases":["Davis"]}')
        outer=self; self.calls=[]
        class Runner:
            def __init__(self,on_event): pass
            def run(self,text): outer.calls.append(text); return 'Đã nhận: '+text
            def cancel(self): pass
        self.bridge=VoiceBridge(self.root,aliases=['davis'],runner_factory=Runner,mutex_factory=nullcontext)
        self.server=make_server(self.root,0,self.bridge)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True); self.thread.start()
        self.url=f'http://127.0.0.1:{self.server.server_port}'
        self.token=self.request('/config')[1]['csrf_token']
    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.bridge.close(); self.thread.join(); self.temp.cleanup()
    def request(self,path,data=None,headers=None):
        h={'X-Jarvis-Token':getattr(self,'token','')}
        body=None
        if data is not None:
            h.update({'Origin':self.url,'Content-Type':'application/json'})
            body=data if isinstance(data,bytes) else json.dumps(data,ensure_ascii=False).encode()
        h.update(headers or {})
        try:
            with urlopen(Request(self.url+path,data=body,headers=h),timeout=3) as response:
                return response.status,json.load(response)
        except HTTPError as error: return error.code,json.load(error)
    def test_foreign_origin_wrong_host_and_missing_token_never_run(self):
        for headers in ({'Origin':'https://evil.example'}, {'X-Jarvis-Token':'wrong'}, {'Host':'evil.example'}):
            self.assertEqual(self.request('/api/arm',{'wake':'Hey Davis'},headers)[0],403)
        self.assertEqual(self.request('/api/state',headers={'X-Jarvis-Token':''})[0],403)
        self.assertEqual(self.calls,[])
    def test_question_endpoints_bind_listener_and_recover_duplicate_answer(self):
        outer=self
        class Runner:
            def __init__(self,on_event):pass
            def run(self,text):
                outer.calls.append(text)
                return json.dumps(dict(version=2,outcome='needs_input',reply='Which project?',response_kind='question',
                    spoken_reply='Which project should I open?',steps=[],question_options=['backend','frontend']))
        self.bridge.runner_factory=Runner
        lease=self.request('/api/pet/claim',{'client_id':'one'})[1]['lease']
        grant=self.request('/api/arm',{'wake':'Hi Davis'})[1]['grant']
        self.request('/api/requests',{'request_id':'question','grant':grant,'text':'open project'})
        self.bridge.worker.join(2);q=self.bridge.status('question')['question']
        route='/api/questions/'+q['id']
        self.assertEqual(self.request(route+'/arm',{'lease':'wrong'})[0],409)
        answer_grant=self.request(route+'/arm',{'lease':lease})[1]['grant']
        data=dict(lease=lease,grant=answer_grant,request_id='answer',text='backend')
        self.assertEqual(self.request(route+'/answer',data)[0],202);self.bridge.worker.join(2)
        self.assertEqual(self.request(route+'/answer',data)[0],202)
        self.assertEqual(len(self.calls),2)
        q2=self.bridge.status('answer')['question'];route2='/api/questions/'+q2['id']
        old=self.request(route2+'/arm',{'lease':lease})[1]['grant']
        self.assertEqual(self.request('/api/pet/audio/stop',{'generation':'previous-listener:old-cue'})[0],200)
        self.assertEqual(self.request(route2)[1]['status'],'pending')
        self.request('/api/pet/claim',{'client_id':'replacement'})
        self.assertEqual(self.request(route2+'/answer',{**data,'request_id':'stale','grant':old})[0],409)
        self.assertEqual(len(self.calls),2)
    def test_auth_rejection_drains_small_body_before_windows_socket_closes(self):
        import io
        from email.message import Message
        handler=self.server.RequestHandlerClass.__new__(self.server.RequestHandlerClass)
        handler.server=self.server;handler.path='/api/arm';handler.headers=Message()
        body=b'{"wake":"Hey Davis"}'
        for key,value in {'Host':self.url.removeprefix('http://'),'Origin':'https://wrong.example','Content-Length':str(len(body)),'Content-Type':'application/json'}.items():handler.headers[key]=value
        handler.rfile=io.BytesIO(body)
        class Connection:
            def settimeout(self,value):pass
        handler.connection=Connection();replies=[]
        handler.reply=lambda status,data:replies.append((status,handler.rfile.tell()))
        handler.do_POST()
        self.assertEqual(replies,[(403,len(body))]);self.assertEqual(self.calls,[])
    def test_malformed_json_and_oversized_requests_are_rejected(self):
        self.assertEqual(self.request('/api/arm',b'{')[0],400)
        self.assertEqual(self.request('/api/arm',b'x'*17000)[0],413)
        self.assertEqual(self.request('/api/arm',{}, {'Content-Type':'text/plain'})[0],415)
        self.assertEqual(self.calls,[])
    def test_workspace_catalog_requires_auth_and_does_not_execute(self):
        self.assertEqual(self.request('/api/workspaces',headers={'X-Jarvis-Token':''})[0],403)
        self.assertEqual(self.request('/api/workspaces'),(200,{'workspaces':[]}))
        self.assertEqual(self.calls,[])
    def test_fast_action_configuration_requires_auth_and_persists_urls(self):
        self.assertEqual(self.request('/api/fast-actions',headers={'X-Jarvis-Token':''})[0],403)
        status,config=self.request('/api/fast-actions');self.assertEqual(status,200)
        for item in config['actions']:
            if item['id']=='favorites':item['url']='https://www.youtube.com/playlist?list=PLabc'
            if item['id']=='today':item['url']='http://localhost:47131/'
        self.assertEqual(self.request('/api/fast-actions/save',{'config':config},headers={'Origin':'https://evil.example'})[0],403)
        self.assertEqual(self.request('/api/fast-actions/save',{'config':config})[0],200)
        self.assertEqual(self.request('/api/fast-actions')[1]['actions'][0]['url'],'https://www.youtube.com/playlist?list=PLabc')
        self.assertEqual(self.calls,[])
    def test_work_import_and_explicit_goal_have_auth_and_return_evidence(self):
        record=dict(item_id='A',title='API review',status='blocked',observed_at='2026-11-06T09:00:00+07:00',source_ref='https://work.example/A',reason='Waiting for API design')
        self.assertEqual(self.request('/api/work/import',{'source':'dashboard','items':[record]},headers={'X-Jarvis-Token':''})[0],403)
        self.assertEqual(self.request('/api/work/import',{'source':'dashboard','items':[record]})[0],200)
        status,goal=self.request('/api/work/goal',{'name':'Finish API','criteria':'Review approved'});self.assertEqual(status,200)
        self.assertEqual(self.request('/api/work/goals')[1]['goals'][0]['id'],goal['id'])
        self.assertEqual(self.request('/api/work/goal/delete',{'id':goal['id']})[0],200)
        self.assertEqual(self.request('/api/work/goals')[1]['goals'],[])
        self.assertEqual(self.bridge.work.evidence('Tại sao việc A chưa xong?')[0]['reason'],'Waiting for API design')
        self.assertEqual(self.calls,[])
    def test_pet_controls_recipes_and_verified_audio(self):
        self.assertEqual(self.request('/api/pet/state',headers={'X-Jarvis-Token':''})[0],403)
        lease=self.request('/api/pet/claim',{'client_id':'test'})[1]['lease']
        self.assertEqual(self.request('/api/pet/publish',{'lease':lease,'seq':1,'snapshot':{'phase':'wake','listening':True}})[0],200)
        self.assertTrue(self.request('/api/pet/state')[1]['listener_connected'])
        self.assertEqual(self.request('/api/pet/control',{'id':'x','action':'shell'})[0],400)
        self.assertEqual(self.request('/api/recipes')[1],{'recipes':[]})
        self.assertEqual(self.request('/api/pet/audio',{'clip':'done','cue_id':'x','generation':'g','job_id':'missing'})[0],404)
        grant=self.request('/api/arm',{'wake':'Hi Davis'})[1]['grant']
        self.request('/api/requests',{'request_id':'sound','grant':grant,'text':'format json {"a":1}'})
        until=time.monotonic()+2
        while self.request('/api/jobs/sound')[1]['state']!='completed' and time.monotonic()<until:time.sleep(.01)
        calls=[];self.server.audio.player=lambda path,event:calls.append(path.name)
        payload={'clip':'done','cue_id':'x','generation':'g','job_id':'sound'}
        self.assertTrue(self.request('/api/pet/audio',payload)[1]['played'])
        self.assertFalse(self.request('/api/pet/audio',payload)[1]['played'])
        self.assertEqual(calls,['done.wav']);self.assertEqual(self.calls,[])
    def test_completion_preview_does_not_need_or_claim_a_job(self):
        calls=[];self.server.audio.player=lambda path,event:calls.append(path.name)
        payload=dict(clip='done',preview=True,cue_id='preview',generation='test',gain=1)
        self.assertTrue(self.request('/api/pet/audio',payload)[1]['played'])
        self.assertEqual(calls,['done.wav']);self.assertEqual(self.calls,[])
        self.assertEqual(self.request('/api/pet/audio',{**payload,'preview':False,'cue_id':'invalid'})[0],404)
    def test_cancel_requires_origin_and_token_and_preserves_completed_jobs(self):
        route='/api/jobs/not-found/cancel'
        self.assertEqual(self.request(route,{},headers={'X-Jarvis-Token':''})[0],403)
        self.assertEqual(self.request(route,{},headers={'Origin':'https://evil.example'})[0],403)
        self.assertEqual(self.request(route,{})[0],404)
        grant=self.request('/api/arm',{'wake':'Hi Davis'})[1]['grant']
        self.request('/api/requests',{'request_id':'calc','grant':grant,'text':'calculate 2+2'})
        until=time.monotonic()+2
        while time.monotonic()<until:
            job=self.request('/api/jobs/calc')[1]
            if job['state']=='completed':break
            time.sleep(.01)
        status,result=self.request('/api/jobs/calc/cancel',{})
        self.assertEqual(status,200)
        self.assertEqual(result['state'],'completed')
        self.assertEqual(self.calls,[])
    def test_http_cancel_stops_a_real_fake_cli_process_and_allows_next_task(self):
        import sys
        session='11111111-2222-4333-8444-555555555555'
        (self.root/'state/session.json').write_text(json.dumps({'thread_id':session}),encoding='utf-8')
        cli=self.root/'fake_cli.py'
        cli.write_text('import pathlib,sys,time\nsys.stdin.read()\npathlib.Path("started").touch()\ntime.sleep(60)\n',encoding='utf-8')
        self.bridge.runner_factory=lambda on_event:CodexRunner(self.root,cli=[sys.executable,str(cli)],on_event=on_event)
        grant=self.request('/api/arm',{'wake':'Hi Davis'})[1]['grant']
        self.request('/api/requests',{'request_id':'blocking','grant':grant,'text':'BLOCK'})
        until=time.monotonic()+3
        while not (self.root/'started').exists() and time.monotonic()<until:time.sleep(.02)
        self.assertTrue((self.root/'started').exists())
        self.assertEqual(self.request('/api/jobs/blocking/cancel',{})[0],200)
        until=time.monotonic()+3
        while time.monotonic()<until:
            job=self.request('/api/jobs/blocking')[1]
            if job['state']=='cancelled':break
            time.sleep(.02)
        self.assertEqual(job['state'],'cancelled')
        self.assertEqual(self.request('/api/arm',{'wake':'Hi Davis'})[0],200)
    def test_busy_grant_replacement_and_bare_cancel_are_listener_bound(self):
        release=threading.Event();started=threading.Event();outer=self
        class Runner:
            def __init__(self,on_event):pass
            def run(self,text):
                outer.calls.append(text)
                if text.startswith('long task'):
                    started.set();release.wait(2)
                    from process_control import TaskCancelled
                    raise TaskCancelled('stopped')
                return json.dumps(dict(version=2,outcome='success',reply='new done',response_kind='action',spoken_reply='',steps=[dict(label='new',state='success',evidence='done')]))
            def cancel(self):release.set();return True
        self.bridge.runner_factory=Runner
        lease=self.request('/api/pet/claim',{'client_id':'listener'})[1]['lease']
        grant=self.request('/api/arm',{'wake':'Hi Davis'})[1]['grant']
        self.request('/api/requests',{'request_id':'old','grant':grant,'text':'long task'})
        self.assertTrue(started.wait(1))
        self.assertEqual(self.request('/api/busy/arm',{'lease':'forged','wake':'Hi Davis','active_job_id':'old'})[0],409)
        busy=self.request('/api/busy/arm',{'lease':lease,'wake':'Hi Davis','active_job_id':'old'})[1]['grant']
        payload={'lease':lease,'grant':busy,'active_job_id':'old','request_id':'replacement','text':'new task'}
        self.assertEqual(self.request('/api/busy/replace',payload)[0],202)
        self.assertEqual(self.request('/api/busy/replace',payload)[0],202)
        until=time.monotonic()+2
        while self.bridge.status('replacement')['outcome']=='unknown' and time.monotonic()<until:time.sleep(.01)
        self.assertEqual(self.bridge.status('replacement')['outcome'],'success');self.assertEqual(len(self.calls),2)
        self.assertEqual(self.request('/api/busy/cancel',{'lease':lease,'active_job_id':'old'})[0],409)
    def test_queued_replacement_can_be_cancelled_by_voice_and_native_pet(self):
        release=threading.Event();started=threading.Event();outer=self
        class Runner:
            def __init__(self,on_event):pass
            def run(self,text):
                outer.calls.append(text);started.set();release.wait(2)
                from process_control import TaskCancelled
                raise TaskCancelled('stopped')
            def cancel(self):return True
        self.bridge.runner_factory=Runner
        lease=self.request('/api/pet/claim',{'client_id':'listener'})[1]['lease']
        for index,route in enumerate(('voice','pet')):
            old='old'+str(index);new='new'+str(index)
            grant=self.request('/api/arm',{'wake':'Hi Davis'})[1]['grant']
            self.request('/api/requests',{'request_id':old,'grant':grant,'text':'long task '+str(index)})
            self.assertTrue(started.wait(1))
            busy=self.request('/api/busy/arm',{'lease':lease,'wake':'Hi Davis','active_job_id':old})[1]['grant']
            self.assertEqual(self.request('/api/busy/replace',{'lease':lease,'grant':busy,'active_job_id':old,'request_id':new,'text':'new task'})[0],202)
            if route=='voice':
                status,value=self.request('/api/busy/cancel',{'lease':lease,'active_job_id':new})
                self.assertEqual(status,200,value)
            else:
                status,value=self.request('/api/pet/control',{'id':'cancel-'+new,'action':'cancel_current','payload':{'job_id':new}})
                self.assertEqual(status,200,value)
            self.assertEqual(self.bridge.status(new)['outcome'],'cancelled')
            release.set();self.bridge.worker.join(2);release.clear();started.clear()
            self.assertEqual(len(self.calls),index+1)
    def test_work_source_ai_permission_requires_explicit_change(self):
        self.assertEqual(self.request('/api/work/policy?source=dashboard')[1]['allow_ai'],False)
        self.assertEqual(self.request('/api/work/policy',{'source':'dashboard','allow_ai':'yes'})[0],400)
        self.assertEqual(self.request('/api/work/policy',{'source':'dashboard','allow_ai':True})[0],200)
        self.assertEqual(self.request('/api/work/policy?source=dashboard')[1]['allow_ai'],True)
    def test_yes_clip_is_served_as_wav_without_text_encoding(self):
        folder=self.root/'webspeech-probe';folder.mkdir()
        clip=b'RIFF'+b'\x00'*32
        (folder/'yes.wav').write_bytes(clip)
        with urlopen(self.url+'/yes.wav',timeout=3) as response:
            self.assertEqual(response.headers['Content-Type'],'audio/wav')
            self.assertEqual(response.read(),clip)
        import base64
        self.assertEqual(base64.b64decode(self.request('/config')[1]['ready_audio']),clip)
    def test_http_round_trip_unicode_retry_and_no_stale_grant(self):
        grant=self.request('/api/arm',{'wake':'Hey Davis'})[1]['grant']
        payload={'request_id':'r1','grant':grant,'text':'Mở YouTube bài Sóng Gió.'}
        first=self.request('/api/requests',payload)
        self.assertEqual(first[0],202)
        self.assertEqual(self.request('/api/requests',payload)[0],202)
        until=time.monotonic()+2
        while time.monotonic()<until:
            job=self.request('/api/jobs/r1')[1]
            if job['state']=='completed': break
            time.sleep(.01)
        self.assertEqual(job['state'],'completed'); self.assertIn('Sóng Gió',job['reply'])
        self.assertEqual(self.calls,[payload['text']])
        self.assertEqual(self.request('/api/requests',{**payload,'request_id':'r2'})[0],409)

if __name__=='__main__': unittest.main()
