"""Persistent bounded questions; single ephemeral listener-bound answer grant.

Call under the owning VoiceBridge lock. No model or microphone work lives here.
"""
import json
import secrets
import uuid


class DialogueStore:
    def __init__(self,memory,clock):
        self.memory=memory;self.clock=clock;self.grant=None
        with memory.connection() as db:
            db.execute("UPDATE questions SET status='expired' WHERE status='pending'")
    @staticmethod
    def prepare(job):
        return dict(id=uuid.uuid4().hex,parent_job=job['id'],question=job['spoken_reply'],
            options=job.get('question_options',[])[:4],status='pending')
    def get(self,identifier):
        with self.memory.connection() as db:
            row=db.execute('SELECT record,status,child_job FROM questions WHERE id=?',(identifier,)).fetchone()
        if not row:raise ValueError('Question not found')
        return {**json.loads(row[0]),'status':row[1],'child_job':row[2]}
    def arm(self,identifier,lease):
        question=self.get(identifier)
        if question['status']!='pending':raise ValueError('Question expired or already answered')
        if self.grant:raise ValueError('Answer window already armed')
        token=secrets.token_urlsafe(24)
        self.grant=(identifier,lease,token,self.clock()+20)
        return dict(grant=token,expires_in=20,question=question)
    def validate(self,identifier,lease,token):
        grant=self.grant
        if (not grant or not isinstance(token,str) or grant[0]!=identifier or grant[1]!=lease
                or not secrets.compare_digest(grant[2],token) or self.clock()>=grant[3]):
            raise ValueError('Answer authorization expired or belongs to another listener')
        question=self.get(identifier)
        if question['status']!='pending':raise ValueError('Question already answered or dismissed')
        return question
    def dismiss(self,identifier=None,status='dismissed'):
        if not identifier or (self.grant and self.grant[0]==identifier):self.grant=None
        with self.memory.connection() as db:
            if identifier:db.execute("UPDATE questions SET status=? WHERE id=? AND status='pending'",(status,identifier))
            else:db.execute("UPDATE questions SET status=? WHERE status='pending'",(status,))
