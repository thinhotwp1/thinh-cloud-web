"""Real Chrome + authenticated HTTP, synthetic speech and deterministic fake agent."""
from contextlib import nullcontext
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'tools')]
from web_bridge import VoiceBridge
from webspeech_live_server import make_server

with tempfile.TemporaryDirectory() as folder:
    fixture=Path(folder);(fixture/'state').mkdir();(fixture/'webspeech-probe').mkdir();(fixture/'desktop').mkdir()
    (fixture/'desktop/PetHost.cs').write_text('// Native feature fixture')
    shutil.copy2(ROOT/'voice-config.json',fixture/'voice-config.json')
    for name in ('index.html','app.js','speech.js','style.css','yes.wav','done.wav'):shutil.copy2(ROOT/'webspeech-probe'/name,fixture/'webspeech-probe'/name)
    calls=[]
    class Runner:
        def __init__(self,on_event):pass
        def run(self,text):
            calls.append(text);first=len(calls)==1
            return json.dumps(dict(version=2,outcome='needs_input' if first else 'success',
                response_kind='question' if first else 'answer',reply='Which project?' if first else 'Backend selected.',
                spoken_reply='Which project should I open?' if first else 'The backend project is selected.',
                question_options=['backend','frontend'],steps=[] if first else [dict(label='Resolve project',state='success',evidence='User selected backend')]))
    bridge=VoiceBridge(fixture,runner_factory=Runner,mutex_factory=nullcontext)
    server=make_server(fixture,0,bridge);clips=[];server.audio.player=lambda path,event:clips.append(path.name)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'tests/check-dialogue-browser.ps1'),'-FixtureUrl',f'http://127.0.0.1:{server.server_port}/'],capture_output=True,encoding='utf-8-sig',errors='replace',timeout=45)
        print(result.stdout.strip());assert result.returncode==0,result.stderr
        assert len(calls)==2,calls
        assert 'CURRENT CLARIFICATION ANSWER' in calls[1] and 'open my project' in calls[1] and 'backend' in calls[1]
        assert clips==[],clips
        print('PASS: two authorized agent turns, contextual answer, no Done for question/answer, no actual mic/audio/model.')
    finally:bridge.close();server.shutdown();server.server_close();thread.join()
