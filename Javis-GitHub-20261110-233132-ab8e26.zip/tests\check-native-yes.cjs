const assert=require('node:assert/strict'),vm=require('node:vm');
const {setup,flush}=require('./check-webspeech-ui.cjs');
(async()=>{
 const app=setup({nativePet:true,deferYes:true});await flush();vm.runInContext('selectedVoice="Microsoft Zira"',app.context);
 await app.node('start').onclick();app.instances.at(-1).final('Hey Javis');await flush();
 assert.equal(app.ttsCalls[0],'Yes');assert.equal(app.utterances[0].voice.name,'Microsoft Zira');assert.equal(app.utterances[0].rate,.95);assert.equal(app.utterances[0].pitch,1.08);assert.equal(app.utterances[0].volume,.9);
 assert.equal(app.state.listening,false);assert.equal(app.calls.filter(c=>c.path==='/api/arm').length,0);
 app.utterances[0].onend();await flush();assert.equal(app.state.phase,'task');app.stop();
 const stopped=setup({nativePet:true,deferYes:true});await flush();await stopped.node('start').onclick();stopped.instances.at(-1).final('Hi Javis');await flush();stopped.stop();await flush();stopped.utterances[0].onend();await flush();assert.equal(stopped.state.listening,false);assert.equal(stopped.calls.filter(c=>c.path==='/api/arm').length,0);
 console.log('PASS: Yes uses selected voice/rate, waits before capture and stops without late wake grants.');
})().catch(e=>{console.error(e);process.exitCode=1;});
