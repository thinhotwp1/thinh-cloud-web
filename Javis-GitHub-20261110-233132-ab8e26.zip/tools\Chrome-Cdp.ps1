# Small shared transport; callers own the browser mutex and socket lifetime.
function Get-JarvisChromeEndpoint([string]$Root) {
    $lines=@(Get-Content -LiteralPath (Join-Path $Root 'state/chrome-profile/DevToolsActivePort') -ErrorAction Stop)
    if($lines.Count -lt 2 -or $lines[0] -notmatch '^\d+$'){throw 'Invalid owned Chrome endpoint.'}
    $http='http://127.0.0.1:'+([int]$lines[0])
    $version=(Invoke-WebRequest ($http+'/json/version') -UseBasicParsing -TimeoutSec 3).Content|ConvertFrom-Json
    if(([uri]$version.webSocketDebuggerUrl).AbsolutePath -ne $lines[1]){throw 'Owned Chrome endpoint mismatch.'}
    return @{http=$http;webSocketDebuggerUrl=$version.webSocketDebuggerUrl}
}
function Connect-JarvisCdp([string]$Url) {
    $socket=New-Object Net.WebSockets.ClientWebSocket
    $cts=New-Object Threading.CancellationTokenSource(5000)
    try{[void]$socket.ConnectAsync([uri]$Url,$cts.Token).GetAwaiter().GetResult()}
    catch{$socket.Dispose();throw}
    finally{$cts.Dispose()}
    return @{socket=$socket;counter=0}
}
function Invoke-JarvisCdp($Client,[string]$Method,[hashtable]$Parameters,[string]$SessionId='') {
    $Client.counter++
    $payload=@{id=$Client.counter;method=$Method;params=$Parameters}
    if($SessionId){$payload.sessionId=$SessionId}
    $bytes=[Text.Encoding]::UTF8.GetBytes(($payload|ConvertTo-Json -Depth 15 -Compress))
    $cts=New-Object Threading.CancellationTokenSource(10000)
    try{
        [void]$Client.socket.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,$cts.Token).GetAwaiter().GetResult()
        $buffer=New-Object byte[] 32768
        while($true){
            $stream=New-Object IO.MemoryStream
            try{
                do{
                    $part=$Client.socket.ReceiveAsync([ArraySegment[byte]]::new($buffer),$cts.Token).GetAwaiter().GetResult()
                    if($part.MessageType -eq [Net.WebSockets.WebSocketMessageType]::Close){throw 'Chrome disconnected.'}
                    $stream.Write($buffer,0,$part.Count)
                    if($stream.Length -gt 4194304){throw 'Chrome response exceeds 4 MB.'}
                }while(-not $part.EndOfMessage)
                $response=[Text.Encoding]::UTF8.GetString($stream.ToArray())|ConvertFrom-Json
            }finally{$stream.Dispose()}
            if($response.id -eq $Client.counter){
                if($response.error){throw ($response.error|ConvertTo-Json -Compress)}
                return $response.result
            }
        }
    }finally{$cts.Dispose()}
}
