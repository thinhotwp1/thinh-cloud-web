param([switch]$NoActivate)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
. (Join-Path $PSScriptRoot 'Chrome-Cdp.ps1')
try{$endpoint=Get-JarvisChromeEndpoint $root}catch{
    & (Join-Path $PSScriptRoot 'Open-Chrome.ps1') -Inspect|Out-Null
    $endpoint=Get-JarvisChromeEndpoint $root
}
$client=Connect-JarvisCdp $endpoint.webSocketDebuggerUrl
$mutex=New-Object Threading.Mutex($false,'Local\JarvisChromePage');$owned=$false
try{
    try{$owned=$mutex.WaitOne(15000)}catch [Threading.AbandonedMutexException]{$owned=$true}
    if(-not $owned){throw 'Another browser action is running.'}
    $path=Join-Path $root 'state/webspeech-live-browser.json'
    $roles=if(Test-Path $path){Get-Content $path -Raw|ConvertFrom-Json}else{$null}
    $pages=@((Invoke-JarvisCdp $client 'Target.getTargets' @{}).targetInfos)
    $voice=$pages|Where-Object {$_.type -eq 'page' -and $_.url -match '^http://127\.0\.0\.1:8766/(?:[?#]|$)'}|Sort-Object @{Expression={$_.targetId -ne $roles.voice_target}}|Select-Object -First 1
    if(-not $voice){
        $roles=& (Join-Path $PSScriptRoot 'Open-Voice-Page.ps1') -VoiceUrl 'http://127.0.0.1:8766/' -NoLock|ConvertFrom-Json
    }else{
        $roles=@{voice_target=$voice.targetId;work_target=$roles.work_target;endpoint=$endpoint.http;voice_url='http://127.0.0.1:8766/'}
        $roles|ConvertTo-Json|Set-Content -LiteralPath $path -Encoding UTF8
    }
    if($NoActivate){@{voice_target=$roles.voice_target}|ConvertTo-Json -Compress;return}
    $window=Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$roles.voice_target}
    [void](Invoke-JarvisCdp $client 'Browser.setWindowBounds' @{windowId=$window.windowId;bounds=@{windowState='normal'}})
    $session=(Invoke-JarvisCdp $client 'Target.attachToTarget' @{targetId=$roles.voice_target;flatten=$true}).sessionId
    [void](Invoke-JarvisCdp $client 'Runtime.evaluate' @{expression='document.body.dataset.compact="false"; true';returnByValue=$true} $session)
    [void](Invoke-JarvisCdp $client 'Page.bringToFront' @{} $session)
    [void](Invoke-JarvisCdp $client 'Target.detachFromTarget' @{sessionId=$session})
}finally{$client.socket.Dispose();if($owned){$mutex.ReleaseMutex()};$mutex.Dispose()}
