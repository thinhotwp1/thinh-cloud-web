"""Bounded desktop actions. Unknown requests remain untouched for Codex."""
import ast
from datetime import datetime, timedelta, timezone
import json
import math
import operator
from pathlib import Path
import re
import subprocess
import threading
import unicodedata
from urllib.parse import urlsplit
from process_control import Cancellation, run_cancellable, TaskCancelled
from execution_result import ExecutionResult


def normalized(text):
    text = unicodedata.normalize('NFD', text.lower().replace('đ', 'd'))
    return ' '.join(''.join(c for c in text if not unicodedata.combining(c)).strip(' .!?').split())


def compound(text):
    return bool(re.search(r'\b(?:roi|va|and|then|sau do)\b|[;&|]', normalized(text)))


def load_workspaces(root):
    path = Path(root) / 'workspaces.json'
    if not path.exists():
        return {'version': 1, 'default': None, 'workspaces': []}
    if path.stat().st_size > 65536:
        raise ValueError('workspaces.json exceeds 64 KB')
    config = json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(config, dict) or config.get('version') != 1:
        raise ValueError('workspaces.json requires version 1')
    workspaces = config.get('workspaces')
    if not isinstance(workspaces, list) or len(workspaces) > 20:
        raise ValueError('workspaces must be a list of at most 20 entries')
    ids, aliases = set(), {}
    for workspace in workspaces:
        if not isinstance(workspace, dict):
            raise ValueError('Invalid workspace entry')
        identifier = workspace.get('id', '')
        if not isinstance(identifier, str) or not re.fullmatch('[a-z][a-z0-9-]{0,31}', identifier) or identifier in ids:
            raise ValueError('Invalid or duplicate workspace ID')
        ids.add(identifier)
        if not isinstance(workspace.get('name'), str) or not workspace['name'].strip():
            raise ValueError('Workspace name is required')
        if not isinstance(workspace.get('enabled'), bool):
            raise ValueError('Workspace enabled must be true or false')
        names = workspace.get('aliases', [])
        if not isinstance(names, list) or len(names) > 20 or any(not isinstance(n, str) or not n.strip() for n in names):
            raise ValueError('Invalid workspace aliases')
        for name in [identifier, workspace['name'], *names]:
            alias = normalized(name)
            if alias in aliases and aliases[alias] != identifier:
                raise ValueError('Duplicate workspace alias: ' + name)
            aliases[alias] = identifier
        project = workspace.get('workspace_path')
        if project is not None and (not isinstance(project, str) or not Path(project).is_absolute()):
            raise ValueError('workspace_path must be an absolute path or null')
        logs = workspace.get('logs_path')
        if logs is not None:
            if not isinstance(logs, str) or not logs or Path(logs).is_absolute() or '..' in Path(logs).parts or not project:
                raise ValueError('logs_path must stay inside workspace_path')
        tabs, tab_ids = workspace.get('tabs'), set()
        if not isinstance(tabs, list) or len(tabs) > 6:
            raise ValueError('Each workspace supports at most 6 tabs')
        for tab in tabs:
            if not isinstance(tab, dict):
                raise ValueError('Invalid tab entry')
            slot = tab.get('id', '')
            if not isinstance(slot, str) or not re.fullmatch('[a-z][a-z0-9-]{0,31}', slot) or slot in tab_ids:
                raise ValueError('Invalid or duplicate tab ID')
            tab_ids.add(slot)
            if not isinstance(tab.get('name'), str) or not tab['name'].strip():
                raise ValueError('Tab name is required')
            url = tab.get('url')
            if url is not None:
                if not isinstance(url, str) or len(url) > 2048:
                    raise ValueError('Invalid tab URL')
                parsed = urlsplit(url)
                if (url != 'about:blank' and (parsed.scheme not in ('http', 'https') or not parsed.hostname)) or parsed.username or parsed.password:
                    raise ValueError('Only http/https URLs without credentials are accepted')
                if parsed.hostname in ('localhost', '127.0.0.1', '::1') and parsed.port in (8765, 8766):
                    raise ValueError('Voice pages cannot be configured as work tabs')
    if config.get('default') is not None and config['default'] not in ids:
        raise ValueError('Unknown default workspace')
    return config


def calculate(expression):
    if len(expression) > 128:
        raise ValueError('Expression too long')
    tree = ast.parse(expression, mode='eval')
    if sum(1 for _ in ast.walk(tree)) > 50:
        raise ValueError('Expression too complex')
    operations = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
                  ast.Div: operator.truediv, ast.Mod: operator.mod, ast.Pow: operator.pow}

    def value(node):
        if isinstance(node, ast.Constant) and type(node.value) in (int, float) and abs(node.value) <= 1e12:
            result = node.value
        elif isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            result = value(node.operand) * (-1 if isinstance(node.op, ast.USub) else 1)
        elif isinstance(node, ast.BinOp) and type(node.op) in operations:
            left, right = value(node.left), value(node.right)
            if isinstance(node.op, ast.Pow) and (abs(right) > 10 or left == 0 and right < 0):
                raise ValueError('Exponent too large')
            result = operations[type(node.op)](left, right)
        else:
            raise ValueError('Only arithmetic is supported')
        if type(result) not in (int, float) or not math.isfinite(result) or abs(result) > 1e30:
            raise ValueError('Result outside supported range')
        return result

    return value(tree.body)


class DesktopRouter:
    def __init__(self, root, open_workset=None,fast_actions=None):
        self.root = Path(root)
        self.open_workset = open_workset or self._open_workset
        self.execution = threading.local()
        if fast_actions is None:
            from fast_actions import FastActionCatalog
            fast_actions=FastActionCatalog(self.root,open_url=self._open_fast_url)
        self.fast=fast_actions

    def _open_fast_url(self,url):
        result=self._run_process(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',
            str(self.root/'tools/Open-Chrome.ps1'),'-Url',url],timeout=40,encoding='utf-8-sig')
        if result.returncode:raise RuntimeError((result.stderr or result.stdout)[-700:])
        return json.loads(result.stdout)

    def run_fast(self,text,cancel_event=None):
        self.execution.cancel_event = cancel_event or Cancellation()
        if self.execution.cancel_event.is_set():
            raise TaskCancelled('Task cancelled before fast routing.')
        return self.fast.run(text,self.execution.cancel_event)
    def run_fast_id(self,identifier,cancel_event=None):
        self.execution.cancel_event = cancel_event or Cancellation()
        if self.execution.cancel_event.is_set():
            raise TaskCancelled('Task cancelled before fast routing.')
        return self.fast.run_id(identifier,self.execution.cancel_event)

    def _run_process(self, args, timeout, encoding='utf-8'):
        return run_cancellable(args, self.execution.cancel_event, timeout, encoding=encoding)

    def _open_workset(self, workspace_id):
        result = self._run_process(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass',
                                 '-File', str(self.root / 'tools/Open-Workset.ps1'), '-WorkspaceId', workspace_id],
                                timeout=100, encoding='utf-8-sig')
        if result.returncode:
            raise RuntimeError((result.stderr or result.stdout).strip()[-3000:])
        return json.loads(result.stdout)

    def catalog(self):
        return [{**workspace, 'path_exists': bool(workspace.get('workspace_path') and Path(workspace['workspace_path']).is_dir())}
                for workspace in load_workspaces(self.root)['workspaces']]

    def _workspace(self, name):
        config = load_workspaces(self.root)
        name = normalized(name or config.get('default') or '')
        return next((w for w in config['workspaces'] if name in
                     {normalized(n) for n in [w['id'], w['name'], *w.get('aliases', [])]}), None)

    def run(self, text, cancel_event=None):
        self.execution.cancel_event = cancel_event or Cancellation()
        if self.execution.cancel_event.is_set():
            raise TaskCancelled('Task cancelled before routing.')
        fast=self.run_fast(text,self.execution.cancel_event)
        if fast is not None:return fast
        value=self._route(text)
        if value is None or isinstance(value,ExecutionResult):return value
        return ExecutionResult(value,'success',[{'label':'Xử lý trực tiếp','state':'success','evidence':str(value)[:300]}])

    def execute_action(self,action,cancel_event=None):
        kind=action.get('type')
        if kind=='open_workset':text='open workspace '+action['workspace_id']
        elif kind=='check_port':text='check port '+str(action['port'])
        elif kind=='calculate':text='calculate '+action['expression']
        elif kind=='format_json':text='format json '+action['json']
        elif kind=='read_logs':text='show logs '+action['workspace_id']
        elif kind=='time':text='time in '+action['place']
        else:raise ValueError('Unsupported recipe action')
        result=self.run(text,cancel_event)
        if result is None:raise ValueError('Recipe action was not a bounded local operation')
        return result

    def _route(self, text):
        command = normalized(text)
        workspace_match = re.fullmatch(r'(?:mo bo(?: cong viec)?|open (?:workspace|workset)|bat dau (?:ngay )?lam viec)(?: (.+))?', command)
        if workspace_match:
            name = workspace_match[1]
            if name and compound(name):
                return None
            workspace = self._workspace(name)
            if workspace is None:
                return ExecutionResult('Không tìm thấy bộ công việc. Hãy xem danh sách bộ đã cấu hình.','needs_input',spoken_reply='Which configured workspace should I open? You can ask me to list workspaces.')
            if not workspace['enabled']:
                return ExecutionResult(f"{workspace['name']}: chưa cấu hình; không mở ứng dụng.",'needs_input',spoken_reply='That workspace is not configured. Which enabled workspace should I use instead?')
            result = self.open_workset(workspace['id'])
            lines = [f"Bộ {workspace['name']}:"]
            labels = {'reused': 'dùng lại', 'opened': 'đã mở', 'unconfigured': 'chưa cấu hình', 'error': 'lỗi'}
            for tab in result['tabs']:
                lines.append(f"- {tab['name']}: {labels.get(tab['state'], tab['state'])}" +
                             (f" — {tab['error']}" if tab.get('error') else ''))
            if result.get('placement_verified') is False:
                lines.append('Chưa xác minh được vị trí trên màn hình đã chọn; kiểm tra cửa sổ trước khi tiếp tục.')
            if result.get('visibility_verified') is False:
                lines.append('Chưa xác minh được cửa sổ đã hiện ra; không coi việc mở ngầm là đã hiển thị thành công.')
            if result.get('focus_kept') is False:
                lines.append('Focus đã thay đổi trong lúc mở; chưa xác minh giữ được bàn phím ở cửa sổ trước đó.')
            project = workspace.get('workspace_path')
            if not project or not Path(project).is_dir():
                lines.append('Thư mục dự án chưa cấu hình hoặc không tồn tại.')
            else:
                lines.append(f'Thư mục dự án: {project} (không đổi cửa sổ VS Code đang dùng).')
            lines.append('Mở tab không chứng minh dịch vụ local đã sẵn sàng.')
            steps=[{'label':t['name'],'state':'success' if t['state'] in ('reused','opened') else 'partial',
                    'evidence':t.get('current_url') or t.get('error') or t['state']} for t in result['tabs']]
            outcome='partial' if any(t['state'] not in ('reused','opened') for t in result['tabs']) else 'success'
            if result.get('placement_verified') is not True or result.get('visibility_verified') is not True:outcome='partial'
            return ExecutionResult('\n'.join(lines),outcome,steps)
        if command in ('co nhung bo cong viec nao', 'danh sach bo cong viec', 'list workspaces'):
            workspaces=self.catalog()
            reply='\n'.join(f"- {w['name']} ({w['id']}): {'sẵn sàng' if w['enabled'] else 'chưa cấu hình'}" for w in workspaces) or 'Chưa có bộ công việc.'
            spoken='Configured workspaces: '+', '.join(w['name'] for w in workspaces)+'.' if workspaces else 'No workspaces are configured.'
            return ExecutionResult(reply,'success',[{'label':'List configured workspaces','state':'success','evidence':str(len(workspaces))+' configured'}],'answer',spoken)
        port_match = re.fullmatch(r'(?:kiem tra|check) (?:port|cong) (\d+)', command)
        if port_match:
            port = int(port_match[1])
            if not 1 <= port <= 65535:
                return ExecutionResult('Port phải nằm trong khoảng 1–65535.','needs_input',spoken_reply='Which TCP port should I check? Please choose a number between one and sixty five thousand five hundred thirty five.')
            result = self._run_process(['netstat.exe', '-ano', '-p', 'tcp'], timeout=8)
            if result.returncode:
                raise RuntimeError('Windows port lookup failed: '+result.stderr[-500:])
            matches = []
            for line in result.stdout.splitlines():
                fields = line.split()
                if len(fields) >= 5 and fields[0] == 'TCP' and fields[1].rsplit(':', 1)[-1] == str(port) and fields[-2].upper() == 'LISTENING':
                    matches.append(f'{fields[1]} — PID {fields[-1]}')
            reply=f'Port {port}:\n' + ('\n'.join(dict.fromkeys(matches)) if matches else 'Không thấy tiến trình TCP đang lắng nghe tại thời điểm kiểm tra.')
            return ExecutionResult(reply,'success',[{'label':'Check TCP port','state':'success','evidence':reply}],'answer',f'Port {port} has {len(set(matches))} listening entries.' if matches else f'No TCP listener was found on port {port}.')
        time_match = re.fullmatch(r'(?:may gio o|gio o|time in) (viet nam|vietnam|utc|nhat ban|japan)', command)
        if time_match:
            offset = {'viet nam': 7, 'vietnam': 7, 'utc': 0, 'nhat ban': 9, 'japan': 9}[time_match[1]]
            now=datetime.now(timezone(timedelta(hours=offset)))
            reply=now.strftime('%Y-%m-%d %H:%M:%S') + f' UTC+{offset:02}:00'
            return ExecutionResult(reply,'success',[{'label':'Read local clock','state':'success','evidence':reply}],'answer',now.strftime('The time is %H:%M')+f', UTC plus {offset}.')
        arithmetic = re.fullmatch(r'(?:tính|calculate)\s+(.+)', text.strip(), re.I | re.S)
        if arithmetic:
            if compound(arithmetic[1]):
                return None
            try:
                value=str(calculate(arithmetic[1].strip()))
                return ExecutionResult(value,'success',[{'label':'Calculate expression','state':'success','evidence':value}],'answer',value)
            except (ValueError, SyntaxError, ArithmeticError, RecursionError):
                return ExecutionResult('Không tính được: chỉ hỗ trợ biểu thức số học ngắn, có giới hạn.','needs_input',spoken_reply='Please give me a short arithmetic expression to calculate.')
        formatting = re.fullmatch(r'(?:định dạng json|format json)\s+(.+)', text.strip(), re.I | re.S)
        if formatting:
            try:
                def reject_constant(value):
                    raise ValueError(value)
                payload = formatting[1].strip()
                value, end = json.JSONDecoder(parse_constant=reject_constant).raw_decode(payload)
                if payload[end:].strip():
                    if compound(payload[end:]):
                        return None
                    raise ValueError('Trailing JSON data')
                return json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)
            except (ValueError, RecursionError):
                return ExecutionResult('JSON không hợp lệ; chưa thay đổi dữ liệu.','needs_input',spoken_reply='That JSON is not valid. Could you provide the corrected JSON?')
        log_match = re.fullmatch(r'(?:xem log|doc log|show logs?)(?: cua| for)? (.+)', command)
        if log_match:
            if compound(log_match[1]):
                return None
            workspace = self._workspace(log_match[1])
            if not workspace or not workspace['enabled'] or not workspace.get('logs_path'):
                return ExecutionResult('Dự án/log chưa cấu hình.','needs_input',spoken_reply='Which configured project and log folder should I use?')
            project = Path(workspace['workspace_path']).resolve()
            logs = (project / workspace['logs_path']).resolve()
            if not logs.is_relative_to(project):
                raise ValueError('logs_path must stay inside the registered project')
            if not logs.is_dir():
                return ExecutionResult('Thư mục log không tồn tại.','needs_input',spoken_reply='The configured log folder does not exist. Which existing log folder should I read?')
            files = [f for f in logs.iterdir() if f.suffix.lower() in ('.log', '.txt') and f.is_file()
                     and f.resolve().is_relative_to(project)]
            if not files:
                return 'Không có file .log/.txt trong thư mục log.'
            latest = max(files, key=lambda f: f.stat().st_mtime)
            with latest.open('rb') as stream:
                stream.seek(max(0, latest.stat().st_size - 16000))
                tail = stream.read(16000).decode('utf-8', errors='replace')
            return ExecutionResult(f'{latest.name} — tối đa 16 KB cuối:\n{tail}','success',
                [{'label':'Đọc log mới nhất','state':'success','evidence':latest.name}])
        return None
