param([switch]$SkipVenv)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$state=Join-Path $root 'state'
[void][IO.Directory]::CreateDirectory($state)

foreach($name in @('voice-config','workspaces')){
    $target=Join-Path $root ($name+'.json')
    $example=Join-Path $root ($name+'.example.json')
    if(-not(Test-Path -LiteralPath $example)){throw "Missing template: $example"}
    if(-not(Test-Path -LiteralPath $target)){Copy-Item -LiteralPath $example -Destination $target}
}

$venvPython=Join-Path $root '.venv\Scripts\python.exe'
if(-not $SkipVenv){
    if(-not(Test-Path -LiteralPath $venvPython)){
        $launcher=Get-Command py.exe -ErrorAction SilentlyContinue
        if($launcher){& $launcher.Source -3 -m venv (Join-Path $root '.venv')}
        else {
            $python=Get-Command python.exe -ErrorAction SilentlyContinue
            if(-not $python){throw 'Python 3 is required. Install it manually, then rerun Setup-Javis.ps1.'}
            & $python.Source -m venv (Join-Path $root '.venv')
        }
        if($LASTEXITCODE -ne 0){throw 'Python virtual environment creation failed.'}
    }
    & $venvPython -c 'import sys; assert sys.version_info >= (3, 10), "Python 3.10+ required"'
    if($LASTEXITCODE -ne 0){throw 'Python 3.10 or newer is required.'}
}

[pscustomobject]@{
    root=$root
    state_ready=(Test-Path -LiteralPath $state)
    venv_ready=(Test-Path -LiteralPath $venvPython)
    voice_config_ready=(Test-Path -LiteralPath (Join-Path $root 'voice-config.json'))
    workspaces_ready=(Test-Path -LiteralPath (Join-Path $root 'workspaces.json'))
    session_initialized=(Test-Path -LiteralPath (Join-Path $state 'session.json'))
} | ConvertTo-Json -Compress
