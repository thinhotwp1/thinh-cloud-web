param([string]$Url, [switch]$Inspect, [string]$Expression, [switch]$VoicePage, [string]$ExpressionFile, [switch]$NoReveal)
$ErrorActionPreference = 'Stop'
if($NoReveal -and ($Url -or $Expression -or $ExpressionFile)){throw 'NoReveal supports passive inspection only.'}
if($VoicePage -and $Url) { throw 'Voice-page mode supports inspection only; navigation belongs to its launcher.' }
if (-not $Url -and -not $Inspect -and -not $Expression -and -not $ExpressionFile) { throw 'Specify -Url, -Inspect, -Expression, or -ExpressionFile.' }
if ($Url) {
    $parsedUrl = $null
    if (-not [uri]::TryCreate($Url, [UriKind]::Absolute, [ref]$parsedUrl) -or
        ($parsedUrl.Scheme -notin @('http','https') -and $Url -ne 'about:blank')) {
        throw 'Only http/https URLs and about:blank are accepted.'
    }
}
$root = Split-Path $PSScriptRoot
if(-not ('JarvisWindowGuard' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'jarvis_windows.cs')}
$dpiContext=[JarvisWindowGuard]::UsePhysicalCoordinates()
. (Join-Path $PSScriptRoot 'Chrome-Cdp.ps1')
. (Join-Path $PSScriptRoot 'Show-WorkWindow.ps1')
if($ExpressionFile) {
    if($Expression) {throw 'Use either -Expression or -ExpressionFile.'}
    $scriptPath=[IO.Path]::GetFullPath($ExpressionFile)
    if(-not $scriptPath.StartsWith($root+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase) -or
       [IO.Path]::GetExtension($scriptPath) -ne '.js') {throw 'ExpressionFile must be a .js file inside Jarvis.'}
    $Expression=Get-Content -LiteralPath $scriptPath -Raw -Encoding UTF8
    if(-not $Expression.Trim()) {throw 'ExpressionFile is empty.'}
}
$profile = Join-Path $root 'state\chrome-profile'
$portFile = Join-Path $profile 'DevToolsActivePort'
$browserState = Join-Path $root 'state\browser.json'
$browserMutex = New-Object System.Threading.Mutex($false, 'Local\JarvisChromePage')
$ownsMutex = $false
$guard = $null
$socket = $null
function Save-BrowserObservation([string]$CurrentUrl,[string]$Title) {
    if($VoicePage){return}
    try {
    $safeUrl=''
    $uri=$null
    if([uri]::TryCreate($CurrentUrl,[UriKind]::Absolute,[ref]$uri) -and $uri.Scheme -in @('http','https')){
        $builder=New-Object UriBuilder($uri)
        $builder.UserName='';$builder.Password='';$builder.Query='';$builder.Fragment=''
        $safeUrl=$builder.Uri.AbsoluteUri
    }
    $safeTitle=($Title -replace '(?i)\b(token|password|secret|api[_-]?key|authorization)\s*[:=]\s*[^\s,;]+','$1=[redacted]')
    if($safeTitle.Length -gt 160){$safeTitle=$safeTitle.Substring(0,160)}
    $record=@{target_id=$target.id;endpoint=$endpoint;current_url=$safeUrl;title=$safeTitle;observed_at=[DateTime]::UtcNow.ToString('o')}
    $temporary=$browserState+'.tmp'
    [IO.File]::WriteAllText($temporary,($record|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $temporary -Destination $browserState -Force
    }catch{Write-Verbose 'Browser observation was unavailable; the action result is unchanged.'}
}
function Show-SelectedWorkWindow {
        if($guard){$guard.Dispose();$script:guard=$null}
        Add-Type -AssemblyName System.Windows.Forms
        if(-not ('JarvisWindowGuard' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'jarvis_windows.cs')}
        $screen=[Windows.Forms.Screen]::AllScreens|Where-Object {-not $_.Primary}|Select-Object -First 1
        if(-not $screen){$screen=[Windows.Forms.Screen]::PrimaryScreen}
        $area=$screen.WorkingArea
        $voiceWidth=if($voiceId){[Math]::Min(700,[int]($area.Width*.4))}else{0}
        $pids=[uint32[]]@(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'"|Where-Object {
            $_.CommandLine -and $_.CommandLine.Contains($profile) -and $_.CommandLine -notmatch '\s--type='
        }|ForEach-Object {$_.ProcessId})
        $metadata=Connect-JarvisCdp $script:browserWebSocket
        try {
            if($voiceId){
                $voiceWindow=Invoke-JarvisCdp $metadata 'Browser.getWindowForTarget' @{targetId=$voiceId}
                $workWindow=Invoke-JarvisCdp $metadata 'Browser.getWindowForTarget' @{targetId=$target.id}
                if($workWindow.windowId -eq $voiceWindow.windowId){throw 'Work tab shares the listener window. Move it into a separate Chrome window before continuing.'}
            }
            $visible=Show-JarvisWorkWindow $metadata $target.id $pids ($area.X+$voiceWidth) $area.Y ($area.Width-$voiceWidth) $area.Height
            if(-not $visible.visible){throw 'Work browser window could not be shown.'}
        }finally{$metadata.socket.Dispose()}
    return $visible
}
function Get-BrowserEndpoint {
    if (-not (Test-Path -LiteralPath $portFile)) { return $null }
    try {
        $lines = @(Get-Content -LiteralPath $portFile -ErrorAction Stop)
        if ($lines.Count -lt 2 -or $lines[0] -notmatch '^\d+$') { return $null }
        $endpoint = 'http://127.0.0.1:' + [int]$lines[0]
        $version = Invoke-RestMethod -Uri "$endpoint/json/version" -TimeoutSec 1
        # Verify this is the browser endpoint recorded by our own isolated profile.
        if (([uri]$version.webSocketDebuggerUrl).AbsolutePath -ne $lines[1]) { return $null }
        $script:browserWebSocket = $version.webSocketDebuggerUrl
        return $endpoint
    } catch { return $null }
}
function Invoke-PageCommand([string]$Method, [hashtable]$Parameters) {
    $cts = New-Object System.Threading.CancellationTokenSource(10000)
    try {
        $payload = @{ id=1; method=$Method; params=$Parameters } | ConvertTo-Json -Depth 12 -Compress
        $bytes = [Text.Encoding]::UTF8.GetBytes($payload)
        [void]$socket.SendAsync([ArraySegment[byte]]::new($bytes), [Net.WebSockets.WebSocketMessageType]::Text, $true, $cts.Token).GetAwaiter().GetResult()
        $buffer = New-Object byte[] 16384
        while ($true) {
            $stream = New-Object IO.MemoryStream
            try {
                do {
                    $received = $socket.ReceiveAsync([ArraySegment[byte]]::new($buffer), $cts.Token).GetAwaiter().GetResult()
                    if ($received.MessageType -eq [Net.WebSockets.WebSocketMessageType]::Close) { throw 'Chrome closed the connection.' }
                    $stream.Write($buffer, 0, $received.Count)
                } while (-not $received.EndOfMessage)
                $response = [Text.Encoding]::UTF8.GetString($stream.ToArray()) | ConvertFrom-Json
            } finally { $stream.Dispose() }
            if ($response.id -eq 1) {
                if ($response.error) { throw ($response.error | ConvertTo-Json -Compress) }
                return $response.result
            }
        }
    } finally { $cts.Dispose() }
}
try {
    try { $ownsMutex = $browserMutex.WaitOne(15000) } catch [System.Threading.AbandonedMutexException] { $ownsMutex = $true }
    if (-not $ownsMutex) { throw 'Another Jarvis browser request is still running.' }
    $endpoint = Get-BrowserEndpoint
    if (-not $endpoint) {
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -Path (Join-Path $PSScriptRoot 'jarvis_windows.cs')
        $screen = [System.Windows.Forms.Screen]::AllScreens | Where-Object { -not $_.Primary } | Select-Object -First 1
        if (-not $screen) { $screen=[Windows.Forms.Screen]::PrimaryScreen }
        $area = $screen.WorkingArea
        $chrome = @(
            "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
            "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
            "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
        ) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
        if (-not $chrome) { throw 'Google Chrome not found. Install it manually; Jarvis will not modify installed apps.' }
        New-Item -ItemType Directory -Path $profile -Force | Out-Null
        $guard = New-Object JarvisWindowGuard($area.X,$area.Y,$area.Width,$area.Height,([string[]]@('chrome')),'Chrome_WidgetWin_',([uint32[]]@()))
        $arguments = '--user-data-dir="{0}" --remote-debugging-address=127.0.0.1 --remote-debugging-port=0 --no-first-run --no-default-browser-check --new-window --window-position={1},{2} --window-size={3},{4} about:blank' -f $profile,$area.X,$area.Y,$area.Width,$area.Height
        $launched = Start-Process -FilePath $chrome -ArgumentList $arguments -WindowStyle Minimized -PassThru
        $guard.AllowProcess([uint32]$launched.Id)
        $launched.Dispose()
        $deadline = (Get-Date).AddSeconds(15)
        do {
            Start-Sleep -Milliseconds 150
            $endpoint = Get-BrowserEndpoint
        } while (-not $endpoint -and (Get-Date) -lt $deadline)
        if (-not $endpoint) { throw 'Jarvis Chrome did not expose its local debugging endpoint.' }
    }
    $voiceId = ''
    $voiceStatePath = Join-Path $root 'state\webspeech-live-browser.json'
    if(Test-Path -LiteralPath $voiceStatePath) { $voiceId=(Get-Content -Raw -LiteralPath $voiceStatePath | ConvertFrom-Json).voice_target }
    $allTargets = @((Invoke-RestMethod -Uri "$endpoint/json/list" -TimeoutSec 3))
    if($voiceId -and -not ($allTargets|Where-Object {$_.id -eq $voiceId -and $_.type -eq 'page'})){$voiceId=''}
    $controlIds = @()
    if($voiceId) {
        $metadata = Connect-JarvisCdp $script:browserWebSocket
        try {
            $controlIds = @((Invoke-JarvisCdp $metadata 'Target.getTargets' @{}).targetInfos |
                Where-Object {$_.openerId -eq $voiceId} | ForEach-Object {$_.targetId})
        } finally {$metadata.socket.Dispose()}
    }
    $worksetIds = @()
    $pendingMarkerPrefix = ([uri](Join-Path $root 'state\workset-pending.html')).AbsoluteUri + '#jarvis-'
    $worksetStatePath = Join-Path $root 'state\worksets.json'
    if(Test-Path -LiteralPath $worksetStatePath) {
        $worksets = Get-Content -LiteralPath $worksetStatePath -Raw -Encoding UTF8 | ConvertFrom-Json
        $worksetIds = @($worksets.tabs | Where-Object target_id | ForEach-Object { $_.target_id })
    }
    $targets = @($allTargets | Where-Object {
        $_.type -eq 'page' -and $_.id -ne $voiceId -and $_.id -notin $controlIds -and $_.id -notin $worksetIds -and
        -not $_.url.StartsWith($pendingMarkerPrefix,[StringComparison]::OrdinalIgnoreCase) -and
        $_.url -notmatch '^http://127\.0\.0\.1:876[56](?:/|$)'
    })
    $remembered = $null
    if (Test-Path -LiteralPath $browserState) { $remembered = Get-Content -Raw -Encoding UTF8 -LiteralPath $browserState | ConvertFrom-Json }
    $target = if($VoicePage){$allTargets|Where-Object id -eq $voiceId|Select-Object -First 1}else{$targets | Where-Object id -eq $remembered.target_id | Select-Object -First 1}
    if($VoicePage -and -not $target) {throw 'No fixed voice page is open.'}
    if (-not $target) { $target = $targets | Select-Object -First 1 }
    if (-not $target) {
        $roles = & (Join-Path $PSScriptRoot 'Open-Voice-Page.ps1') -EnsureWorkOnly -NoLock | ConvertFrom-Json
        $target = (Invoke-RestMethod -Uri "$endpoint/json/list" -TimeoutSec 3) | Where-Object id -eq $roles.work_target | Select-Object -First 1
        if(-not $target) { throw 'Work tab could not be created without taking over the voice page.' }
    }
    if(-not $VoicePage) { @{ target_id=$target.id; endpoint=$endpoint } | ConvertTo-Json | Set-Content -LiteralPath $browserState -Encoding UTF8 }
    $socket = New-Object Net.WebSockets.ClientWebSocket
    $connectTimeout = New-Object System.Threading.CancellationTokenSource(5000)
    try { [void]$socket.ConnectAsync([uri]$target.webSocketDebuggerUrl,$connectTimeout.Token).GetAwaiter().GetResult() } finally { $connectTimeout.Dispose() }
    if(-not $VoicePage -and ($Url -or $Expression)){[void](Show-SelectedWorkWindow)}
    if ($Url) {
        $result = Invoke-PageCommand 'Page.navigate' @{url=$Url}
        if ($result.errorText) { throw $result.errorText }
        # An acknowledgment is not a completed navigation. Wait for the new
        # document so inspection/actions cannot accidentally run on the old page.
        $loaderId = $result.loaderId
        $deadline = (Get-Date).AddSeconds(15)
        $ready = $false
        do {
            $tree = Invoke-PageCommand 'Page.getFrameTree' @{}
            if (-not $loaderId -or $tree.frameTree.frame.loaderId -eq $loaderId) {
                $status = Invoke-PageCommand 'Runtime.evaluate' @{expression='JSON.stringify({url:location.href,title:document.title,ready:document.readyState})'; returnByValue=$true}
                $pageStatus = $status.result.value | ConvertFrom-Json
                if ($pageStatus.ready -in @('interactive','complete')) { $ready=$true; break }
            }
            Start-Sleep -Milliseconds 100
        } while ((Get-Date) -lt $deadline)
        if (-not $ready) { throw 'Navigation is still loading. Inspect again before interacting with the page.' }
        $shown=Show-SelectedWorkWindow
        Save-BrowserObservation $pageStatus.url $pageStatus.title
        [pscustomobject]@{target_id=$target.id; requested_url=$Url; current_url=$pageStatus.url; reused_tab=$true; visibility_verified=$shown.visible; window_id=$shown.window_id} | ConvertTo-Json -Compress
    }
    if ($Inspect -or $Expression) {
        $javascript = if ($Expression) { $Expression } else {
            'JSON.stringify({target_id:' + ($target.id|ConvertTo-Json -Compress) + ',title:document.title,url:location.href,text:document.body?document.body.innerText.slice(0,6000):"",links:Array.from(document.querySelectorAll("a[href]")).slice(0,30).map(a=>({text:a.innerText,url:a.href}))})'
        }
        $result = Invoke-PageCommand 'Runtime.evaluate' @{expression=$javascript; returnByValue=$true; awaitPromise=$true; userGesture=$true}
        if ($result.exceptionDetails) { throw ($result.exceptionDetails | ConvertTo-Json -Depth 8 -Compress) }
        if(-not $VoicePage){
            try{
                $observation=Invoke-PageCommand 'Runtime.evaluate' @{expression='JSON.stringify({url:location.href,title:document.title})';returnByValue=$true}
                if(-not $observation.exceptionDetails){$observed=$observation.result.value|ConvertFrom-Json;Save-BrowserObservation $observed.url $observed.title}
            }catch{Write-Verbose 'Target no longer exposes metadata; action output is retained.'}
        }
        if(-not $VoicePage -and -not $NoReveal -and -not $Expression){[void](Show-SelectedWorkWindow)}
        $result.result.value
    }
    if ($guard) { Start-Sleep -Seconds 2 }
} finally {
    if ($socket) { $socket.Dispose() }
    if ($guard) { $guard.Dispose() }
    if ($ownsMutex) { $browserMutex.ReleaseMutex() }
    $browserMutex.Dispose()
    [JarvisWindowGuard]::RestoreCoordinates($dpiContext)
}
