"""Quick actions must stay bounded, exact and independent of Codex."""
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
try:
    from desktop_tasks import DesktopRouter
except ImportError:
    DesktopRouter = None


class DesktopTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(DesktopRouter, 'The desktop router has not been implemented')
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.project = self.root / 'project'
        (self.project / 'logs').mkdir(parents=True)
        self.config = {'version': 1, 'default': 'daily', 'workspaces': [
            {'id': 'daily', 'name': 'Hằng ngày', 'aliases': ['hằng ngày', 'daily'],
             'enabled': True, 'workspace_path': str(self.project), 'logs_path': 'logs',
             'tabs': [{'id': 'prs', 'name': 'Pull requests', 'url': 'https://github.com/pulls'}]},
            {'id': 'frontend', 'name': 'Frontend', 'aliases': [], 'enabled': False,
             'workspace_path': None, 'logs_path': None, 'tabs': []}]}
        self.save()
        self.opened = []

        def open_workset(workspace_id):
            self.opened.append(workspace_id)
            return {'tabs': [{'name': 'Pull requests', 'state': 'reused', 'current_url': 'https://github.com/pulls'}]}

        self.router = DesktopRouter(self.root, open_workset=open_workset)

    def save(self):
        (self.root / 'workspaces.json').write_text(json.dumps(self.config, ensure_ascii=False), encoding='utf-8')

    def test_workspace_alias_and_default_report_real_result(self):
        result = self.router.run('Bắt đầu ngày làm việc.')
        self.assertIn('Pull requests', result)
        self.assertIn('dùng lại', result)
        self.assertEqual(self.opened, ['daily'])
        self.assertIn('Pull requests', self.router.run('Open workspace daily'))

    def test_compound_and_unknown_requests_fall_back_intact(self):
        for text in ('Mở bộ hằng ngày rồi xóa file', 'Mở YouTube bài Sóng Gió',
                     'check port 3000 and kill it', 'calculate 2+2 and open GitHub',
                     'tính 2+2 và mở GitHub', 'format json {} and open GitHub',
                     'xem log daily và kiểm tra port 3000'):
            with self.subTest(text=text):
                self.assertIsNone(self.router.run(text))
        self.assertEqual(self.opened, [])

    def test_disabled_or_unknown_workspace_does_not_launch(self):
        self.assertIn('chưa cấu hình', self.router.run('Mở bộ frontend').lower())
        self.assertIn('không tìm thấy', self.router.run('Mở bộ nonexistent').lower())
        self.assertEqual(self.opened, [])

    def test_failed_window_verification_is_visible(self):
        self.router.open_workset = lambda _: {'tabs': [], 'placement_verified': False, 'focus_kept': False}
        result = self.router.run('Mở bộ daily')
        self.assertIn('chưa xác minh', result.lower())
        self.assertIn('focus', result.lower())

    def test_manifest_reload_and_missing_path_are_visible(self):
        self.config['workspaces'][0]['workspace_path'] = str(self.root / 'missing')
        self.save()
        result = self.router.run('Mở bộ daily')
        self.assertIn('không tồn tại', result.lower())
        self.assertIn('Pull requests', result)

    def test_catalog_exposes_configuration_gaps_without_launching(self):
        catalog = self.router.catalog()
        self.assertEqual([w['id'] for w in catalog], ['daily', 'frontend'])
        self.assertFalse(catalog[1]['enabled'])
        self.assertEqual(self.opened, [])

    def test_duplicate_alias_and_executable_url_rejected_before_launch(self):
        self.config['workspaces'][1]['aliases'] = ['daily']
        self.save()
        with self.assertRaisesRegex(ValueError, 'alias'):
            self.router.run('Mở bộ daily')
        self.config['workspaces'][1]['aliases'] = []
        self.config['workspaces'][0]['tabs'][0]['url'] = 'javascript:alert(1)'
        self.save()
        with self.assertRaises(ValueError):
            self.router.run('Mở bộ daily')
        self.assertEqual(self.opened, [])

    def test_calculator_uses_arithmetic_without_python_execution(self):
        self.assertIn('14', self.router.run('Tính 2 + 3 * 4'))
        self.assertIn('4', self.router.run('calculate (6 + 2) / 2'))
        for text in ('tính __import__("os").getcwd()', 'tính 2**99999999', 'tính 1/0'):
            self.assertIn('không tính được', self.router.run(text).lower())

    def test_timezone_is_explicit_and_unknown_location_uses_codex(self):
        self.assertIn('UTC+07:00', self.router.run('Mấy giờ ở Việt Nam'))
        self.assertIn('UTC+09:00', self.router.run('time in Japan'))
        self.assertIsNone(self.router.run('time in London'))

    def test_json_formatting_keeps_unicode_and_reports_invalid_input(self):
        result = self.router.run('format json {"tên":"Sóng Gió","n":2}')
        self.assertEqual(json.loads(result), {'tên': 'Sóng Gió', 'n': 2})
        self.assertIn('\n', result)
        self.assertEqual(json.loads(self.router.run('format json {"text":"and rồi và"}')), {'text':'and rồi và'})
        for text in ('format json {', 'format json {"n":NaN}'):
            self.assertIn('JSON không hợp lệ', self.router.run(text))

    def test_latest_log_is_bounded_and_does_not_include_older_file(self):
        old = self.project / 'logs/old.log'
        new = self.project / 'logs/new.log'
        old.write_text('old content', encoding='utf-8')
        os.utime(old, (100, 100))
        new.write_text('x' * 40000 + '\nlast error Sóng Gió', encoding='utf-8')
        result = self.router.run('Xem log của daily')
        self.assertIn('new.log', result)
        self.assertIn('last error Sóng Gió', result)
        self.assertLess(len(result), 18000)
        self.assertNotIn('old content', result)

    def test_log_directory_escape_is_rejected(self):
        self.config['workspaces'][0]['logs_path'] = '../outside'
        self.save()
        with self.assertRaisesRegex(ValueError, 'logs_path'):
            self.router.run('xem log daily')

    def test_port_lookup_filters_exact_listeners_and_keeps_ipv6_pid(self):
        table = '  TCP  127.0.0.1:3000  0.0.0.0:0  LISTENING  1234\n' \
                '  TCP  [::1]:3000  [::]:0  LISTENING  5678\n' \
                '  TCP  127.0.0.1:3000  127.0.0.1:99  ESTABLISHED  9999\n' \
                '  TCP  127.0.0.1:13000  0.0.0.0:0  LISTENING  8888\n'
        with patch.object(self.router, '_run_process', return_value=SimpleNamespace(stdout=table,stderr='',returncode=0)):
            result = self.router.run('Kiểm tra port 3000')
        self.assertIn('PID 1234', result)
        self.assertIn('PID 5678', result)
        self.assertNotIn('9999', result)
        self.assertNotIn('8888', result)
        self.assertIn('1–65535', self.router.run('check port 99999'))


if __name__ == '__main__':
    unittest.main()
