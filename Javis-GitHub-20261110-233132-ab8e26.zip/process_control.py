"""Cancellation scoped to a launched process and its owned descendants."""
import ctypes
from ctypes import wintypes
import os
from pathlib import Path
import subprocess
import threading
import time


class TaskCancelled(RuntimeError):
    pass


class Cancellation(threading.Event):
    """Serialize cancellation against releasing live process-tree ownership."""
    def __init__(self):
        super().__init__()
        self.ownership_lock = threading.RLock()
        self.groups = set()

    def set(self):
        with self.ownership_lock:
            super().set()
            for group in tuple(self.groups):
                group.terminate()

    def track(self, group):
        with self.ownership_lock:
            self.groups.add(group)
            if self.is_set():
                group.terminate()

    def release(self, group):
        with self.ownership_lock:
            cancelled = self.is_set()
            if cancelled:
                group.terminate()
            self.groups.discard(group)
            group.close()
            return cancelled


class ProcessGroup:
    def __init__(self, process):
        self.process = process
        self.job = None
        self.lock = threading.Lock()
        if os.name == 'nt':
            kernel = ctypes.WinDLL('kernel32', use_last_error=True)
            kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
            kernel.CreateJobObjectW.restype = wintypes.HANDLE
            kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            kernel.OpenProcess.restype = wintypes.HANDLE
            kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
            kernel.AssignProcessToJobObject.restype = wintypes.BOOL
            kernel.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]
            kernel.TerminateJobObject.restype = wintypes.BOOL
            kernel.CloseHandle.argtypes = [wintypes.HANDLE]
            self.kernel = kernel
            job = kernel.CreateJobObjectW(None, None)
            owned_process = kernel.OpenProcess(0x0100 | 0x0001, False, process.pid)
            try:
                if job and owned_process and kernel.AssignProcessToJobObject(job, owned_process):
                    self.job = job
                else:
                    error = ctypes.get_last_error()
                    if job:
                        kernel.CloseHandle(job)
                    raise OSError(error, 'Cannot assign owned process to a private job; launch remains suspended.')
            finally:
                if owned_process:
                    kernel.CloseHandle(owned_process)

    def terminate(self):
        with self.lock:
            if self.job and self.kernel.TerminateJobObject(self.job, 1):
                return
            if self.process.poll() is None:
                if os.name == 'nt':
                    taskkill = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32/taskkill.exe'
                    result = subprocess.run([str(taskkill), '/PID', str(self.process.pid), '/T', '/F'],
                                            capture_output=True, timeout=5, creationflags=subprocess.CREATE_NO_WINDOW)
                    if result.returncode and self.process.poll() is None:
                        raise RuntimeError('Could not confirm owned process-tree termination.')
                else:
                    self.process.terminate()

    def close(self):
        with self.lock:
            if self.job:
                # No KILL_ON_JOB_CLOSE: normal completion keeps deliberately
                # started services alive. Only explicit cancellation terminates.
                self.kernel.CloseHandle(self.job)
                self.job = None


def _resume_owned_process(process):
    class ThreadEntry(ctypes.Structure):
        _fields_ = [('size', wintypes.DWORD), ('usage', wintypes.DWORD),
                    ('thread_id', wintypes.DWORD), ('process_id', wintypes.DWORD),
                    ('priority', wintypes.LONG), ('delta', wintypes.LONG), ('flags', wintypes.DWORD)]
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    kernel.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    kernel.Thread32First.argtypes = kernel.Thread32Next.argtypes = [wintypes.HANDLE, ctypes.POINTER(ThreadEntry)]
    kernel.Thread32First.restype = kernel.Thread32Next.restype = wintypes.BOOL
    kernel.OpenThread.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenThread.restype = wintypes.HANDLE
    kernel.ResumeThread.argtypes = [wintypes.HANDLE]
    kernel.ResumeThread.restype = wintypes.DWORD
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    snapshot = kernel.CreateToolhelp32Snapshot(0x00000004, 0)
    if snapshot == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        entry = ThreadEntry(); entry.size = ctypes.sizeof(entry)
        present = kernel.Thread32First(snapshot, ctypes.byref(entry))
        while present:
            if entry.process_id == process.pid:
                thread = kernel.OpenThread(0x0002, False, entry.thread_id)
                if not thread:
                    raise ctypes.WinError(ctypes.get_last_error())
                try:
                    if kernel.ResumeThread(thread) == 0xFFFFFFFF:
                        raise ctypes.WinError(ctypes.get_last_error())
                    return
                finally:
                    kernel.CloseHandle(thread)
            present = kernel.Thread32Next(snapshot, ctypes.byref(entry))
        raise RuntimeError('Owned suspended process thread not found.')
    finally:
        kernel.CloseHandle(snapshot)


def start_owned_process(args, *, cancellation=None, **kwargs):
    flags = kwargs.pop('creationflags', 0)
    if os.name == 'nt':
        flags |= 0x00000004  # CREATE_SUSPENDED: no descendant can start before assignment.
    process = subprocess.Popen(args, creationflags=flags, **kwargs)
    group = None
    try:
        group = ProcessGroup(process)
        if isinstance(cancellation, Cancellation):
            cancellation.track(group)
            if cancellation.is_set():
                raise TaskCancelled('Cancelled while the command was still suspended.')
        if os.name == 'nt':
            _resume_owned_process(process)
        return process, group
    except Exception:
        process.kill()
        process.wait(timeout=5)
        if group:
            if isinstance(cancellation, Cancellation):
                cancellation.release(group)
            else:
                group.close()
        for stream in (process.stdin, process.stdout, process.stderr):
            if stream:
                stream.close()
        raise


def run_cancellable(args, cancel_event, timeout, *, encoding='utf-8', cwd=None):
    if cancel_event.is_set():
        raise TaskCancelled('Task cancelled before process creation.')
    process, group = start_owned_process(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               text=True, encoding=encoding, errors='replace', cwd=cwd,
                               creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0), cancellation=cancel_event)
    deadline = time.monotonic() + timeout
    try:
        while True:
            if cancel_event.is_set():
                group.terminate()
                process.communicate(timeout=5)
                raise TaskCancelled('Owned process stopped after cancellation.')
            if time.monotonic() >= deadline:
                group.terminate()
                process.communicate(timeout=5)
                raise subprocess.TimeoutExpired(args, timeout)
            try:
                stdout, stderr = process.communicate(timeout=.1)
                if cancel_event.is_set():
                    group.terminate()
                    raise TaskCancelled('Task cancelled.')
                return subprocess.CompletedProcess(args, process.returncode, stdout, stderr)
            except subprocess.TimeoutExpired:
                continue
    finally:
        if process.poll() is None:
            group.terminate()
            process.wait(timeout=5)
        process.stdout.close()
        process.stderr.close()
        cancelled = cancel_event.release(group) if isinstance(cancel_event, Cancellation) else cancel_event.is_set()
        if not isinstance(cancel_event, Cancellation):
            if cancelled:
                group.terminate()
            group.close()
        if cancelled:
            raise TaskCancelled('Task cancelled; owned group terminated.')
