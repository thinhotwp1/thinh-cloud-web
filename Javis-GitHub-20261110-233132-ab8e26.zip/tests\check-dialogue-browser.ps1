param([Parameter(Mandatory=$true)][string]$FixtureUrl,[switch]$BusyMode,[string]$WakeText='Hey Javis')
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
. (Join-Path $root 'tools/Chrome-Cdp.ps1')
$client=Connect-JarvisCdp (Get-JarvisChromeEndpoint $root).webSocketDebuggerUrl
$target='';$session=''
function Evaluate([string]$Expression){
 $reply=Invoke-JarvisCdp $client 'Runtime.evaluate' @{expression=$Expression;returnByValue=$true;awaitPromise=$true} $session
 if($reply.exceptionDetails){throw ($reply.exceptionDetails|ConvertTo-Json -Depth 6 -Compress)}
 $reply.result.value
}
function Wait-Phase([string]$Phase){
 $until=(Get-Date).AddSeconds(16)
 do{Start-Sleep -Milliseconds 100;$state=Evaluate 'JSON.stringify(window.jarvisProbeState)'|ConvertFrom-Json;if($state.phase -eq $Phase){return $state}}while((Get-Date) -lt $until)
 throw "Expected $Phase, got $($state|ConvertTo-Json -Depth 4 -Compress)"
}
try{
 $target=(Invoke-JarvisCdp $client 'Target.createTarget' @{url='about:blank';newWindow=$true;background=$true;focus=$false}).targetId
 $session=(Invoke-JarvisCdp $client 'Target.attachToTarget' @{targetId=$target;flatten=$true}).sessionId
 [void](Invoke-JarvisCdp $client 'Page.enable' @{} $session)
 $adapter=@'
window.__recognizers=[];window.__spoken=[];
window.SpeechRecognition=class {constructor(){window.__recognizers.push(this);}start(){queueMicrotask(()=>this.onstart?.());}abort(){queueMicrotask(()=>this.onend?.());}stop(){queueMicrotask(()=>this.onend?.());}};
Object.defineProperty(window,'speechSynthesis',{value:{getVoices:()=>[{name:'Microsoft David fixture',lang:'en-US',localService:true}],addEventListener(){},cancel(){},speak(u){window.__spoken.push(u.text);queueMicrotask(()=>u.onend?.());}}});
window.SpeechSynthesisUtterance=class {constructor(text){this.text=text;}};
navigator.mediaDevices.getUserMedia=async()=>({getAudioTracks:()=>[{label:'Synthetic input only'}],getTracks:()=>[{stop(){}}]});
window.__say=text=>{const r=[{transcript:text}];r.isFinal=true;window.__recognizers.at(-1).onresult({resultIndex:0,results:[r]});};
'@
 [void](Invoke-JarvisCdp $client 'Page.addScriptToEvaluateOnNewDocument' @{source=$adapter} $session)
 [void](Invoke-JarvisCdp $client 'Page.navigate' @{url=$FixtureUrl} $session)
 [void](Wait-Phase 'idle')
 [void](Evaluate 'document.getElementById("start").onclick().then(()=>true)')
 [void](Wait-Phase 'wake')
 if((Evaluate '__recognizers.at(-1).lang') -ne 'vi-VN'){throw 'Vietnamese mode did not set the wake recognizer language.'}
 [void](Evaluate ('__say('+($WakeText|ConvertTo-Json -Compress)+');true'));[void](Wait-Phase 'task')
 if($BusyMode){
  [void](Evaluate '__say("investigate old work send now");true')
  [void](Wait-Phase 'busy-wake')
  [void](Evaluate ('__say('+($WakeText|ConvertTo-Json -Compress)+');true'))
  [void](Wait-Phase 'busy-task')
  [void](Evaluate '__say("investigate new work send now");true')
  $state=Wait-Phase 'wake'
  if($state.job.state -ne 'completed' -or $state.job.outcome -ne 'success' -or $state.job.id -notmatch '^replace-'){throw 'Replacement did not complete in the owned session.'}
  [void](Evaluate 'document.getElementById("stop").click();true')
  'PASS: real Chrome busy wake -> one queued replacement -> old cancelled -> new completed.'
  return
 }
 [void](Evaluate '__say("open my project");__recognizers.at(-1).onend();true')
 [void](Wait-Phase 'answer')
 [void](Evaluate '__say("backend");__recognizers.at(-1).onend();true')
 $state=Wait-Phase 'wake'
 $spoken=Evaluate 'JSON.stringify(__spoken.filter(t=>t!=="Yes"))'|ConvertFrom-Json
 if(-not (Evaluate '__spoken.includes("Yes")')){throw 'Selected-voice acknowledgement did not speak.'}
 if($spoken.Count -ne 2 -or $spoken[0] -ne 'Which project should I open?' -or $spoken[1] -ne 'The backend project is selected.'){throw 'English dialogue playback did not match the two turns.'}
 if($state.job.parent_question_id -eq $null -or $state.job.outcome -ne 'success'){throw 'Answer did not finish as the contextual child.'}
 [void](Evaluate 'document.getElementById("stop").click();true')
 'PASS: actual Chrome adapter -> question speech -> answer capture -> same-task reply speech -> wake.'
}finally{
 if($target){try{[void](Invoke-JarvisCdp $client 'Target.closeTarget' @{targetId=$target})}catch{}}
 $client.socket.Dispose()
}
