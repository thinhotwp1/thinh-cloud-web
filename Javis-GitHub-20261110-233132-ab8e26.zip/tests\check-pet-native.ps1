$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
if(-not(Test-Path -LiteralPath (Join-Path $root 'desktop/PetHost.cs'))){throw 'Native pet host is not implemented.'}
& powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File (Join-Path $root 'Start-Pet.ps1') -SelfTest
if($LASTEXITCODE -ne 0){throw 'Native pet self-test failed.'}
