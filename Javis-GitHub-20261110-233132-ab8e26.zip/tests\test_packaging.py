"""A publishable package must be runnable without private profiles or the Sprig sprite."""
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
import zipfile


ROOT=Path(__file__).resolve().parents[1]


class PackagingTests(unittest.TestCase):
    def test_public_package_is_small_private_free_and_has_a_fallback_pet(self):
        with tempfile.TemporaryDirectory(prefix='javis-package-test-') as folder:
            result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',
                str(ROOT/'Package-Javis.ps1'),'-OutputRoot',folder],capture_output=True,
                text=True,encoding='utf-8',errors='replace',timeout=60)
            self.assertEqual(result.returncode,0,result.stderr or result.stdout)
            package=json.loads(result.stdout.splitlines()[-1])
            archive=Path(package['zip']);source=Path(package['folder'])
            self.assertTrue(archive.is_file())
            self.assertLess(archive.stat().st_size,4_000_000)
            with zipfile.ZipFile(archive) as zipped:
                names=set(zipped.namelist())
                for required in ('README.md','Setup-Javis.ps1','Package-Javis.ps1','AGENTS.md','.gitignore',
                                 'voice-config.example.json','workspaces.example.json',
                                 'desktop/PetHost.cs','webspeech-probe/app.js',
                                 'packaging/.gitignore.public','packaging/AGENTS.public.md'):
                    self.assertIn(required,names)
                self.assertFalse(any(name.startswith(('state/','.venv/','dist/','tasks/')) for name in names))
                self.assertNotIn('assets/pet/spritesheet.webp',names)
                self.assertNotIn('workspaces.json',names)
                self.assertNotIn('voice-config.json',names)
                readme=zipped.read('README.md').decode('utf-8')
                self.assertNotIn(str(Path.home()).replace('\\','/'),readme)
            setup=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',
                str(source/'Setup-Javis.ps1')],capture_output=True,text=True,
                encoding='utf-8',errors='replace',timeout=45)
            self.assertEqual(setup.returncode,0,setup.stderr or setup.stdout)
            self.assertTrue((source/'state').is_dir())
            self.assertTrue((source/'voice-config.json').is_file())
            self.assertTrue((source/'workspaces.json').is_file())
            self.assertTrue((source/'.venv/Scripts/python.exe').is_file())
            self.assertFalse((source/'state/session.json').exists())
            pet=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',
                str(source/'Start-Pet.ps1'),'-SelfTest'],capture_output=True,text=True,
                encoding='utf-8',errors='replace',timeout=30)
            self.assertEqual(pet.returncode,0,pet.stderr or pet.stdout)
            self.assertTrue(json.loads(pet.stdout.splitlines()[-1])['passed'])


if __name__=='__main__':unittest.main()
