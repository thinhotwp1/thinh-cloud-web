$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
. (Join-Path $root 'tools/Chrome-Cdp.ps1')
Add-Type -Path (Join-Path $root 'tools/jarvis_windows.cs')
Add-Type -AssemblyName System.Windows.Forms
Add-Type @'
using System;using System.Runtime.InteropServices;
public class JavisCompletionZ {
 [DllImport("user32.dll")]static extern IntPtr GetWindow(IntPtr h,uint cmd);
 public static bool Above(IntPtr a,IntPtr b){for(var h=GetWindow(b,3);h!=IntPtr.Zero;h=GetWindow(h,3))if(h==a)return true;return false;}
}
'@
$client=Connect-JarvisCdp (Get-JarvisChromeEndpoint $root).webSocketDebuggerUrl
$target='';$cover=''
try{
    $target=(Invoke-JarvisCdp $client 'Target.createTarget' @{url='about:blank';newWindow=$true;background=$true;focus=$false;left=100;top=100;width=800;height=600}).targetId
    $window=Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$target}
    [void](Invoke-JarvisCdp $client 'Browser.setWindowBounds' @{windowId=$window.windowId;bounds=@{windowState='minimized'}})
    $screen=[Windows.Forms.Screen]::AllScreens|Where-Object {-not $_.Primary}|Select-Object -First 1
    if(-not $screen){$screen=[Windows.Forms.Screen]::PrimaryScreen}
    $a=$screen.WorkingArea
    $cover=(Invoke-JarvisCdp $client 'Target.createTarget' @{url='about:blank';newWindow=$true;background=$true;focus=$false;left=($a.X+720);top=20;width=($a.Width-760);height=($a.Height-40)}).targetId
    $anchor=[JarvisWindowGuard]::Foreground()
    $result=& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'tools/Reveal-WorkTarget.ps1') -TargetIds $target
    if($LASTEXITCODE -ne 0){throw 'Final visibility check failed.'}
    $result=$result|ConvertFrom-Json
    if(-not $result.visibility_verified -or -not $result.focus_kept){throw 'Target did not become visible without activating.'}
    $actual=Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$target}
    if($actual.bounds.windowState -ne 'normal' -or $actual.bounds.left -lt $a.X -or $actual.bounds.left+$actual.bounds.width -gt $a.Right){throw 'Target is minimized or off the selected monitor.'}
    $profile=Join-Path $root 'state/chrome-profile'
    $pids=[uint32[]]@(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'"|Where-Object {$_.CommandLine -and $_.CommandLine.Contains($profile) -and $_.CommandLine -notmatch '\s--type='}|ForEach-Object ProcessId)
    $coverWindow=Invoke-JarvisCdp $client 'Browser.getWindowForTarget' @{targetId=$cover}
    $coverHandle=[JarvisWindowGuard]::FindChromeWindow($pids,$coverWindow.bounds.left,$coverWindow.bounds.top,$coverWindow.bounds.width,$coverWindow.bounds.height)
    if($coverHandle -ne [IntPtr]::Zero -and -not [JavisCompletionZ]::Above([IntPtr]([long]$result.windows[0].hwnd),$coverHandle)){throw 'Work window stayed beneath the cover.'}
    $roles=Get-Content (Join-Path $root 'state/webspeech-live-browser.json') -Raw|ConvertFrom-Json
    $previousPreference=$ErrorActionPreference;$ErrorActionPreference='Continue'
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'tools/Reveal-WorkTarget.ps1') -TargetIds $roles.voice_target 2>$null|Out-Null
    $rejectExit=$LASTEXITCODE;$ErrorActionPreference=$previousPreference
    if($rejectExit -eq 0){throw 'Finalizer allowed the voice window.'}
    if([JarvisWindowGuard]::Foreground() -ne $anchor){throw 'Finalizer changed keyboard focus.'}
    'PASS: exact minimized work target restored on selected monitor, focus preserved, voice rejected.'
}finally{
    foreach($id in @($target,$cover)|Where-Object {$_}){try{[void](Invoke-JarvisCdp $client 'Target.closeTarget' @{targetId=$id})}catch{}}
    $client.socket.Dispose()
}
