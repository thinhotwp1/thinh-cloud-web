$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot
$launcher = Join-Path $root 'Start-Codex.ps1'
if (-not (Test-Path -LiteralPath $launcher)) { throw 'FAIL: persistent voice launcher missing' }
$description = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $launcher -Describe
if ($LASTEXITCODE -ne 0) { throw 'Launcher description failed' }
$info = $description | ConvertFrom-Json
if ($info.WorkingDirectory -ne $root) { throw 'Wrong working directory' }
if ($info.Arguments -notcontains 'danger-full-access' -or $info.Arguments -notcontains 'never') { throw 'Full access is not scoped to this invocation' }
if ($info.SessionId -and $info.Arguments -notcontains 'resume') { throw 'Existing session is not reused' }
if ($info.SessionId -and $info.Arguments -notcontains '--no-daemon') { throw 'Bundled extension CLI must resume without the unavailable daemon package' }
if ($info.GlobalConfigEdited) { throw 'Global configuration must not change' }
'PASS: dedicated folder, per-process Full Access, no-daemon startup, existing-session reuse.'
