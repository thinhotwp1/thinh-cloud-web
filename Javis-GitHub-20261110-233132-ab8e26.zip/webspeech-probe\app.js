'use strict';
const $ = id => document.getElementById(id);
const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const state = window.jarvisProbeState = {
  supported: Boolean(Recognition), phase: 'idle', listening: false,
  lastFinal: '', request: '', error: '', microphone: '', events: [], live: false, job: null
};
let aliases = [], shouldRun = false, recognizer = null, generation = 0;
let retryTimer, deadlineTimer, quietTimer, flushTimer, networkStableTimer, networkFailures=0, pendingGreeting = '', greetingAt = 0, audioContext;
let silenceMs = 10000;
let csrfToken = '', armGrant = null, jobBusy = false, runEpoch = 0;
let manualPending = false;
let armQueue = Promise.resolve();
let cancelPending = false, floatingWindow = null, floatingPending = false, readyAudioPromise, readyAudioBase64 = '';
let nativePet = false, petLease = '', petSequence = 0, petAck = [], petBusy = false, soundEnabled = true;
const petClient = crypto.randomUUID(), handledControls = new Set();
let currentAudio = '', audioSequence = 0, speakingResolve = null, playbackEpoch = 0;
let pendingQuestion=null, answerGrant=null, answerWindowTimer=null, speechBusy=false, cueGain=1, selectedVoice='';
let speechCaption=null;
let fastActionConfig=null;
let captureEpoch=0,lastCaptureFinal='',requestFinalizeCapture=null;
let busyGrant=null,busyTarget=null,busyWake='';
const immediateSuffix=/(?:^|[\s,;:!?])(?:gửi ngay|gửi luôn|làm luôn|do it now|send now)[.!?]*\s*$/i;
async function dismissPendingQuestion() {
  const question=pendingQuestion;pendingQuestion=null;answerGrant=null;clearTimeout(answerWindowTimer);answerWindowTimer=null;
  if(question && petLease)await api(`/api/questions/${encodeURIComponent(question.id)}/dismiss`,{lease:petLease}).catch(()=>{});
}
function notice(text, phase, duration = 3500) { state.notice = {text,phase,until:Date.now()+duration}; renderPanel(); }
function activeNotice() { return state.notice && state.notice.until > Date.now() ? state.notice : null; }
async function stopSpeaking() {
  playbackEpoch++;
  window.JavisSpeech?.stop();void dismissPendingQuestion();
  window.speechSynthesis?.cancel(); if(speakingResolve) speakingResolve();
  if(nativePet && currentAudio) await api('/api/pet/audio/stop',{generation:currentAudio}).catch(()=>{});
}
async function playCue(clip, job, preview=false) {
  if(!nativePet) { if(clip==='yes') return playTone(); return; }
  if(!soundEnabled) return;
  if(clip==='yes'){
    speechBusy=true;stopRecognition();controls();
    try{if(!await window.JavisSpeech?.speak('Yes',{voice:selectedVoice}))throw new Error('Acknowledgement voice stopped or unavailable. Preview a voice and try again.');}
    finally{speechBusy=false;controls();}
    return;
  }
  if(clip==='done')stopRecognition();
  const generation = `${petClient}:audio:${++audioSequence}`; currentAudio = generation;
  try { await api('/api/pet/audio',{cue_id:crypto.randomUUID(),clip,generation,job_id:job?.id,preview,gain:clip==='done'?cueGain:1}); }
  finally { if(currentAudio===generation)currentAudio=''; }
}
async function speakReply(text) {
  if(!soundEnabled)return false;
  speechBusy=true;stopRecognition();controls();
  try {
    const completed=await window.JavisSpeech?.speak(text,{voice:selectedVoice,onPage:page=>{speechCaption=page;state.spoken=page;renderPanel();}});
    if(!completed)notice('Speech stopped or unavailable. Read the result in Details.','waiting',6000);
    return completed===true;
  }finally{speechCaption=null;state.spoken=null;speechBusy=false;controls();}
}
async function armPendingAnswer(intent) {
  const question=pendingQuestion;if(!question || !shouldRun)return false;
  if(!petLease)petLease=(await api('/api/pet/claim',{client_id:petClient})).lease;
  const value=await api(`/api/questions/${encodeURIComponent(question.id)}/arm`,{lease:petLease});
  if(intent!==runEpoch || !shouldRun || pendingQuestion!==question){void dismissPendingQuestion();return false;}
  answerGrant=value.grant;
  answerWindowTimer=setTimeout(()=>{stopRecognition();void dismissPendingQuestion();state.notice=null;if(shouldRun)startRecognition('wake');notice('Answer window expired. Call Javis to continue.','waiting',6000);},Math.max(20000,silenceMs+10000));
  state.notice=null;startRecognition('answer');return true;
}
async function sendAnswer(text) {
  const question=pendingQuestion,grant=answerGrant,intent=runEpoch;
  if(!question || !grant || jobBusy || !text.trim())return;
  pendingQuestion=null;answerGrant=null;clearTimeout(answerWindowTimer);answerWindowTimer=null;stopRecognition();
  const id=`answer-${crypto.randomUUID()}`;jobBusy=true;state.job={id,text,state:'submitting',events:[]};controls();
  status('Continuing your task…','Using your answer with the original request.','executing');
  try {
    let job;try{job=await api(`/api/questions/${encodeURIComponent(question.id)}/answer`,{lease:petLease,grant,request_id:id,text});}
    catch(error){try{job=await api(`/api/jobs/${encodeURIComponent(id)}`);}catch(_){throw error;}}
    state.job=job;await watchJob(job.id,intent);
  }catch(error){jobBusy=false;fail(`Could not submit answer: ${error.message}`);}
}
async function pumpPet() {
  if(!nativePet || petBusy)return;
  petBusy=true;
  try {
    if(!petLease) petLease=(await api('/api/pet/claim',{client_id:petClient})).lease;
    const n=activeNotice(),caption=speechBusy?speechCaption:null;
    const value=await api('/api/pet/publish',{lease:petLease,seq:++petSequence,ack:petAck,
      snapshot:{phase:caption?'speaking':n?.phase||state.phase,status:caption?`Speaking · ${caption.index}/${caption.total}`:n?.text||$('status').textContent,
        heard:caption?.text||state.lastHeard||pendingQuestion?.question||'',request:state.request,error:state.panelError||state.error,
        listening:state.listening,wants_mic:shouldRun,dialogue_pending:Boolean(pendingQuestion||speechBusy),epoch:`${petClient}:${runEpoch}`}});
    petAck=[];soundEnabled=value.sound_enabled;
    if(value.native_connected && floatingWindow && !floatingWindow.closed)floatingWindow.close();
    for(const command of value.controls){
      petAck.push(command.id);if(handledControls.has(command.id))continue;handledControls.add(command.id);
      if(handledControls.size>200)handledControls.delete(handledControls.values().next().value);
      if(command.action==='mic_on' && !shouldRun && !jobBusy && !manualPending)void $('start').onclick();
      if(command.action==='mic_off')stop();
      if(command.action==='cancel_current' && command.payload.epoch===`${petClient}:${runEpoch}`)await cancelCurrent();
      if(command.action==='quick_screenshot')void submitFastAction('screenshot');
      if(command.action==='quick_lock')void submitFastAction('lock');
      if(command.action==='quick_screens_off')void submitFastAction('screens-off');
      if(command.action==='show_details'){document.body.dataset.compact='false';renderPanel();}
      if((command.action==='summary'||command.action==='read_result')&&!jobBusy){
        $('manual-input').value=command.action==='summary'?'tổng hợp những việc hôm nay':'đọc kết quả';void sendTyped();
      }
      if(command.action==='stop_speaking' || command.action==='sound_off'){if(command.action==='sound_off')soundEnabled=false;await stopSpeaking();if(state.phase==='answer' || state.phase==='speaking'){stopRecognition();if(!jobBusy && shouldRun)startRecognition('wake');}}
      if(command.action==='send_now'&&(!jobBusy||state.phase==='busy-task'))requestFinalizeCapture?.();
    }
  } catch(error) {
    state.petError=error.message;
    if(/Invalid session token/i.test(error.message)){
      try{const config=await (await fetch('/config',{cache:'no-store'})).json();csrfToken=config.csrf_token;petLease='';petSequence=0;}catch(_){}
    }
  }
  finally {petBusy=false;if(nativePet)setTimeout(pumpPet,600);}
}

function panelDocuments() {
  return floatingWindow && !floatingWindow.closed ? [document, floatingWindow.document] : [document];
}
function renderPanel() {
  const canCancel = Boolean(pendingQuestion || speechBusy) || (jobBusy ? Boolean(state.job && !['completed','failed','cancelled','interrupted','submitting'].includes(state.job.state))
    : shouldRun && ['tone','task','finalizing','answer'].includes(state.phase));
  const last = state.panelError || state.error || (jobBusy ? state.job?.text || state.request : ['task','finalizing'].includes(state.phase) ? state.request
    : state.job?.state === 'cancelled' ? 'Đã hủy lượt thực thi. Có thể gọi lại tên.' : state.job?.reply || state.job?.error || state.request)
    || 'Gọi Hi Javis, chờ “Yes” rồi nói nhiệm vụ.';
  for (const doc of panelDocuments()) {
    doc.getElementById('mini-status').textContent = activeNotice()?.text || $('status').textContent;
    doc.getElementById('mini-last').textContent = last;
    doc.getElementById('mini-last').title = last;
    const mic = doc.getElementById('mini-mic');
    mic.textContent = shouldRun ? 'Tắt mic' : 'Bật mic';
    mic.disabled = manualPending || (!shouldRun && (jobBusy || !state.supported || !aliases.length));
    const cancel = doc.getElementById('mini-cancel');
    cancel.disabled = !canCancel || cancelPending || (jobBusy && state.job?.state === 'cancelling');
    cancel.textContent = cancelPending || (jobBusy && state.job?.state === 'cancelling') ? 'Đang hủy' : 'Hủy';
    doc.getElementById('compact-toggle').textContent = document.body.dataset.compact === 'true' ? 'Chi tiết' : 'Gọn';
    doc.getElementById('pip-toggle').disabled = floatingPending;
    doc.getElementById('pip-toggle').textContent = doc === document ? 'Nổi' : 'Gọn';
  }
}
function toggleCompact() {
  state.panelError = '';
  document.body.dataset.compact = document.body.dataset.compact === 'true' ? 'false' : 'true';
  if (floatingWindow && !floatingWindow.closed) {
    document.body.dataset.compact = 'false'; floatingWindow.close(); window.focus();
  }
  renderPanel();
}
function bindPanel(doc) {
  doc.getElementById('mini-mic').onclick = () => shouldRun ? stop() : $('start').onclick();
  doc.getElementById('mini-cancel').onclick = cancelCurrent;
  doc.getElementById('compact-toggle').onclick = toggleCompact;
  doc.getElementById('pip-toggle').onclick = doc === document ? openFloating : () => {
    try { floatingWindow.resizeTo(360, 205); }
    catch (error) { state.panelError = `Chưa thu nhỏ được: ${error.message}`; renderPanel(); }
  };
}
async function openFloating() {
  if(nativePet){
    try{await api('/api/pet/control',{id:crypto.randomUUID(),action:'show_pet',payload:{}});}
    catch(error){state.panelError=error.message;renderPanel();}return;
  }
  if (floatingPending) return;
  if (floatingWindow && !floatingWindow.closed) { floatingWindow.focus(); return; }
  if (!window.documentPictureInPicture?.requestWindow) {
    document.body.dataset.compact = 'true';
    state.panelError = 'Chrome này chưa hỗ trợ bảng nổi. Có thể thu nhỏ cửa sổ với giao diện gọn.'; renderPanel();
    return;
  }
  floatingPending = true; state.panelError = ''; renderPanel();
  try {
    const pip = await window.documentPictureInPicture.requestWindow({width:360,height:205,preferInitialWindowPlacement:true});
    floatingWindow = pip;
    pip.document.title = 'Javis';
    const link = pip.document.createElement('link');
    link.rel = 'stylesheet'; link.href = new URL('/style.css', window.location.href).href;
    pip.document.head.appendChild(link);
    pip.document.body.dataset.floating = 'true';
    pip.document.body.appendChild($('mini-panel').cloneNode(true));
    bindPanel(pip.document);
    pip.addEventListener('pagehide', () => { if (floatingWindow === pip) floatingWindow = null; renderPanel(); });
  } catch (error) { state.panelError = `Chưa mở được bảng nổi: ${error.message}`; $('error').textContent = state.panelError; }
  finally { floatingPending = false; renderPanel(); }
}
async function cancelCurrent() {
  if (cancelPending) return;
  if(pendingQuestion || speechBusy){runEpoch++;stopRecognition();await stopSpeaking();state.notice=null;jobBusy=false;controls();if(shouldRun)startRecognition('wake');return;}
  if (!jobBusy) {
    if (!shouldRun) return;
    runEpoch++; stopRecognition(); disarm(); state.request = ''; $('request').value = '';
    startRecognition('wake'); return;
  }
  const job = state.job;
  if (!job || ['completed','failed','cancelled','interrupted','submitting'].includes(job.state)) return;
  cancelPending = true;
  status('Đang yêu cầu hủy', 'Chỉ nghe nhiệm vụ mới khi lượt chạy đã dừng.', 'executing'); controls();
  try {
    let value;
    try { value = await api(`/api/jobs/${encodeURIComponent(job.id)}/cancel`, {}); }
    catch (error) {
      value = await api(`/api/jobs/${encodeURIComponent(job.id)}`);
      if (!['cancelling','cancelled','completed','failed','interrupted'].includes(value.state)) throw error;
    }
    if (jobBusy && state.job?.id === job.id && !['completed','failed','cancelled','interrupted'].includes(state.job.state)) state.job = value;
  } catch (error) {
    state.error = `Chưa xác minh được yêu cầu hủy: ${error.message}. Lượt chạy vẫn được theo dõi.`;
    $('error').textContent = state.error;
  } finally { cancelPending = false; controls(); }
}

async function acknowledgeBusy(wake){
  const intent=runEpoch,activeId=state.job?.state==='queued'&&state.job?.replaces_job_id?state.job.replaces_job_id:state.job?.id;
  if(!activeId)return;
  busyTarget=activeId;busyWake=wake;
  stopRecognition();status('Đã nhận tên gọi','Đang nói “Yes”…','tone');notice('Yes','tone',1500);
  try{
    await playCue('yes');if(!shouldRun||intent!==runEpoch)return;
    if(!petLease)petLease=(await api('/api/pet/claim',{client_id:petClient})).lease;
    const value=await api('/api/busy/arm',{lease:petLease,wake,active_job_id:activeId});
    if(!shouldRun||intent!==runEpoch)return;
    busyGrant=value.grant;busyTarget=activeId;busyWake=wake;startRecognition('busy-task');
  }catch(error){
    const live=await api('/api/state').catch(()=>({active:{id:activeId}}));
    if(!live.active){runEpoch++;jobBusy=false;armGrant=(await requestArm(wake)).grant;startRecognition('task');return;}
    if(live.active.id!==activeId){
      try{
        const value=await api('/api/busy/arm',{lease:petLease,wake,active_job_id:live.active.id});
        if(!shouldRun||intent!==runEpoch)return;
        busyGrant=value.grant;busyTarget=live.active.id;busyWake=wake;startRecognition('busy-task');return;
      }catch(_){/* The owner or task changed again; keep the listener active. */}
    }
    if(shouldRun)startRecognition('busy-wake');else fail(error.message);
  }
}
async function executeReplacement(){
  const text=state.request.trim(),grant=busyGrant,oldId=busyTarget,wake=busyWake,intent=++runEpoch;
  busyGrant=null;stopRecognition();
  if(!text){if(shouldRun)startRecognition('busy-wake');return;}
  const id=`replace-${crypto.randomUUID()}`;
  state.job={id,text,state:'queued',events:[],replaces_job_id:oldId};controls();
  status('Đang dừng nhiệm vụ cũ','Nhiệm vụ mới sẽ bắt đầu sau khi worker cũ dừng.','executing');
  try{
    let job;try{job=await api('/api/busy/replace',{lease:petLease,grant,active_job_id:oldId,request_id:id,text});}
    catch(error){try{job=await api(`/api/jobs/${encodeURIComponent(id)}`);}catch(_){
      const live=await api('/api/state');
      if(!live.active){jobBusy=false;armGrant=(await requestArm(wake)).grant;state.request=text;await executeTask();return;}
      throw error;
    }}
    state.job=job;if(shouldRun)startRecognition('busy-wake');
    await watchJob(id,intent);
  }catch(error){jobBusy=false;fail(`Chưa thay được nhiệm vụ: ${error.message}`);}
}

function requestArm(wake) {
  const pending = armQueue.then(() => api('/api/arm', { wake }));
  armQueue = pending.catch(() => {});
  return pending;
}

async function loadWorksets() {
  if (!state.live) return;
  try {
    const value = await api('/api/workspaces');
    $('worksets').textContent = value.workspaces.map(workset => `${workset.name} (${workset.id}) — ${workset.enabled ? 'đã bật' : 'chưa cấu hình'}\n`
      + workset.tabs.map(tab => `  • ${tab.name}: ${tab.url || 'chưa có URL'}`).join('\n')).join('\n\n') || 'Chưa có bộ công việc.';
  } catch (error) { $('worksets').textContent = `Không đọc được bộ công việc: ${error.message}`; }
}
async function loadFastActions(){
  try{
    fastActionConfig=await api('/api/fast-actions');
    for(const [id,prefix] of [['favorites','favorites'],['today','today']]){
      const action=fastActionConfig.actions.find(item=>item.id===id);
      if(action){$(`${prefix}-url`).value=action.url||'';$(`${prefix}-aliases`).value=action.aliases.join(', ');}
    }
    for(const id of ['screenshot','lock','screens-off']){
      const action=fastActionConfig.actions.find(item=>item.id===id);
      if(action)$(`${id}-aliases`).value=action.aliases.join(', ');
    }
    renderWebActions();
    $('fast-status').textContent='Có thể lưu URL và tên gọi mà không cần sửa code.';
  }catch(error){$('fast-status').textContent=`Không đọc được tác vụ nhanh: ${error.message}`;}
}
async function saveFastActions(){
  if(!fastActionConfig)return;
  const config=JSON.parse(JSON.stringify(fastActionConfig));
  for(const [id,prefix] of [['favorites','favorites'],['today','today']]){
    const action=config.actions.find(item=>item.id===id);if(!action)continue;
    action.url=$(`${prefix}-url`).value.trim()||null;
    action.aliases=$(`${prefix}-aliases`).value.split(',').map(text=>text.trim()).filter(Boolean);
  }
  for(const id of ['screenshot','lock','screens-off']){
    const action=config.actions.find(item=>item.id===id);
    if(action)action.aliases=$(`${id}-aliases`).value.split(',').map(text=>text.trim()).filter(Boolean);
  }
  try{fastActionConfig=await api('/api/fast-actions/save',{config});renderWebActions();$('fast-status').textContent='Đã lưu tác vụ nhanh; có thể gọi tên đã cấu hình.';}
  catch(error){$('fast-status').textContent=`Chưa lưu: ${error.message}`;}
}
function renderWebActions(){
  $('web-list').textContent=fastActionConfig?.actions.filter(item=>item.type==='web')
    .map(item=>`${item.id} · ${item.name}\n${item.url}\nGọi: ${item.aliases.join(', ')}`).join('\n\n')||'Chưa có web tự thêm.';
}
async function saveWebAction(){
  if(!fastActionConfig)return;
  const action={id:$('web-id').value.trim(),type:'web',name:$('web-name').value.trim(),
    aliases:$('web-aliases').value.split(',').map(value=>value.trim()).filter(Boolean),url:$('web-url').value.trim()};
  if(!action.id||!action.name||!action.url||!action.aliases.length){$('web-status').textContent='Cần mã, tên, URL và ít nhất một câu gọi.';return;}
  const config=JSON.parse(JSON.stringify(fastActionConfig));
  const index=config.actions.findIndex(item=>item.id===action.id);
  if(index>=0 && config.actions[index].type!=='web'){$('web-status').textContent='Mã này thuộc tác vụ có sẵn; chọn mã web khác.';return;}
  if(index>=0)config.actions[index]=action;else config.actions.push(action);
  try{fastActionConfig=await api('/api/fast-actions/save',{config});renderWebActions();$('web-status').textContent=`Đã lưu web ${action.name}.`;}
  catch(error){$('web-status').textContent=`Chưa lưu web: ${error.message}`;}
}
function loadWebAction(){
  const action=fastActionConfig?.actions.find(item=>item.id===$('web-id').value.trim() && item.type==='web');
  if(!action){$('web-status').textContent='Không tìm thấy mã web đã lưu.';return;}
  $('web-name').value=action.name;$('web-url').value=action.url||'';$('web-aliases').value=action.aliases.join(', ');
  $('web-status').textContent=`Đã nạp ${action.name}; sửa rồi bấm Thêm / cập nhật web.`;
}
async function removeWebAction(){
  const id=$('web-id').value.trim();
  if(!fastActionConfig?.actions.some(item=>item.id===id&&item.type==='web')){$('web-status').textContent='Không tìm thấy mã web đã lưu.';return;}
  const config=JSON.parse(JSON.stringify(fastActionConfig));config.actions=config.actions.filter(item=>item.id!==id);
  try{fastActionConfig=await api('/api/fast-actions/save',{config});renderWebActions();$('web-status').textContent=`Đã xóa web ${id}.`;}
  catch(error){$('web-status').textContent=`Chưa xóa web: ${error.message}`;}
}
async function submitFastAction(id){
  if(jobBusy||manualPending||pendingQuestion){$('fast-status').textContent='Javis đang bận; đợi lượt hiện tại kết thúc rồi bấm lại.';return;}
  const action=fastActionConfig?.actions.find(item=>item.id===id);
  if(!action||!action.aliases?.length){$('fast-status').textContent='Tác vụ nhanh chưa được nạp hoặc thiếu câu gọi.';return;}
  await sendTyped(action.name,action.id);
}
async function sendTyped(overrideText,actionId) {
  const text = typeof overrideText==='string' ? overrideText.trim() : $('manual-input').value.trim();
  if (!state.live || jobBusy || manualPending || !text) return;
  if(pendingQuestion){
    manualPending=true;stopRecognition();controls();
    try{
      if(!petLease)petLease=(await api('/api/pet/claim',{client_id:petClient})).lease;
      if(!answerGrant)answerGrant=(await api(`/api/questions/${encodeURIComponent(pendingQuestion.id)}/arm`,{lease:petLease})).grant;
      await sendAnswer(text);
    }catch(error){fail(error.message);}finally{manualPending=false;controls();}return;
  }
  state.panelError = '';
  const intent = ++runEpoch;
  manualPending = true; stopRecognition(); disarm(); controls();
  try {
    const value = await requestArm('Hey Jarvis');
    if (intent !== runEpoch) { disarm(value.grant); return; }
    armGrant = value.grant;
    state.request = text; $('request').value = text;
    await executeTask(actionId);
  } catch (error) { if (intent === runEpoch) fail(`Chưa gửi được nhiệm vụ: ${error.message}`); }
  finally { manualPending = false; controls(); }
}

async function api(path, data) {
  const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetch(path, { method: data === undefined ? 'GET' : 'POST',
      headers: { 'X-Jarvis-Token': csrfToken, ...(data === undefined ? {} : { 'Content-Type': 'application/json' }) },
      body: data === undefined ? undefined : JSON.stringify(data), cache: 'no-store', signal: controller.signal });
    const value = await response.json();
    if (!response.ok) throw new Error(value.error || `HTTP ${response.status}`);
    return value;
  } finally { clearTimeout(timer); }
}
function disarm(grant = armGrant) {
  if (grant === armGrant) armGrant = null;
  if (state.live && grant) void api('/api/disarm', { grant }).catch(error => log(`DISARM | ${error.message}`));
}
async function watchJob(id, intent) {
  try {
    while (true) {
      if(intent!==runEpoch&&state.job?.id!==id)return;
      const job = await api(`/api/jobs/${encodeURIComponent(id)}`);
      if(intent!==runEpoch&&state.job?.id!==id)return;
      if(['completed','failed','cancelled','interrupted'].includes(job.state)&&busyTarget===id&&['tone','busy-task','finalizing'].includes(state.phase))return;
      state.job = job;
      const executor = job.executor === 'local' ? 'Javis trực tiếp' : 'Codex';
      $('job-status').textContent = job.state === 'completed' ? `${executor}: đã hoàn tất${job.elapsed_seconds === undefined ? '' : ` (${job.elapsed_seconds}s)`}.` : job.state === 'failed' ? `${executor} báo lỗi.` : job.state === 'cancelled' ? 'Đã hủy lượt thực thi.' : job.state === 'cancelling' ? 'Đang hủy — chờ tiến trình dừng…' : `${executor} đang thực hiện nhiệm vụ…`;
      $('reply').textContent = job.state === 'cancelled' ? 'Đã dừng lượt chạy. Các thao tác đã hoàn tất vẫn được giữ.' : job.reply || job.error || job.cancel_error || job.events.join('\n\n');
      if (job.state === 'cancelling') status('Đang hủy nhiệm vụ', 'Chờ xác nhận dừng trước khi gọi lại.', 'executing');
      controls();
      if (['completed','failed','cancelled','interrupted'].includes(job.state)) {
        log(`CODEX ${job.state.toUpperCase()} | ${id}`);
        if(job.outcome==='needs_input' && job.replaces_job_id){
          const live=await api('/api/state');
          if(live.active){
            notice('Nhiệm vụ mới chưa chạy: tác vụ cũ dừng quá 30 giây. Xem Chi tiết.', 'waiting', 10000);
            state.job=live.active;jobBusy=true;controls();
            if(shouldRun)startRecognition('busy-wake');
            void watchJob(live.active.id,intent);
            return;
          }
        }
        const speechTicket = playbackEpoch;
        if(job.state==='interrupted'){shouldRun=false;stopRecognition();}
        const message=job.state==='interrupted'?'Da gian doan - xem Chi tiet':job.state==='cancelled'?'Đã hủy':job.state==='failed'?'Có lỗi — xem Chi tiết':
          job.outcome==='success'?'Done':job.outcome==='partial'?'Chưa đủ — xem Chi tiết':job.outcome==='needs_input'?'Cần bạn — xem Chi tiết':'Cần kiểm tra kết quả';
        const kind=job.response_kind||'action';
        notice(message,job.outcome==='success'?'done':job.state==='cancelled'?'idle':job.outcome==='failed'?'error':'waiting',6000);
        try {
          if(nativePet && job.state==='completed' && job.outcome==='success' && kind==='action')await playCue('done',job);
          const explicit=/(?:đọc (?:lại )?(?:kết quả|câu trả lời)|cho tôi nghe|bằng giọng nói|thành tiếng|read (?:the )?(?:answer|result)|speak aloud)/i.test(job.text||'');
          if(job.state==='completed' && speechTicket===playbackEpoch && intent===runEpoch && (kind!=='action'||explicit)){
            if(kind==='question' && job.question){pendingQuestion=job.question;state.lastHeard='';}
            state.notice=null;status(kind==='question'?'Javis needs your answer':'Javis is speaking',job.spoken_reply||'Read the full result in Details.','speaking');
            const spoken=await speakReply(job.spoken_reply || (explicit ? job.reply : ''));
            if(kind==='question' && spoken && speechTicket===playbackEpoch && intent===runEpoch && shouldRun && pendingQuestion){
              jobBusy=false;controls();if(await armPendingAnswer(intent))return;
            }
            if(kind==='question' && pendingQuestion)notice(job.spoken_reply||job.reply,'waiting',20000);
          }
        } catch(error) {notice(`Chưa phát được âm thanh: ${error.message}`,'waiting',6000);}
        jobBusy = false; controls();
        if (intent === runEpoch){if(shouldRun)startRecognition('wake');else status('Mic đã dừng', 'Kết quả nhiệm vụ được hiển thị bên dưới.', 'idle');}
        return;
      }
      await new Promise(resolve => setTimeout(resolve, 1500));
    }
  } catch (error) {
    jobBusy = true;
    fail(`Không đọc được kết quả: ${error.message}. Không tự gửi lại lệnh; tải lại trang để kiểm tra nhiệm vụ đang chạy.`);
  }
}
async function executeTask(actionId) {
  if (jobBusy) return;
  const text = state.request.trim(), intent = runEpoch, grant = armGrant;
  stopRecognition();
  if (!text) {
    disarm();
    if (shouldRun) startRecognition('wake');
    return;
  }
  armGrant = null; jobBusy = true; controls();
  const requestId = crypto.randomUUID();
  state.job = {id:requestId,text,state:'submitting',events:[]}; controls();
  status('Đang gửi nhiệm vụ', 'Javis xử lý trực tiếp hoặc giao Codex. Mic tạm nghỉ trong lúc xử lý.', 'executing');
  $('reply').textContent = ''; $('job-status').textContent = 'Đang gửi…';
  try {
    let job;
    try { job = actionId ? await api('/api/local-actions',{request_id:requestId,grant,action_id:actionId})
      : await api('/api/requests', { request_id: requestId, grant, text }); }
    catch (error) {
      // A lost response may already have started work. Recover by the same ID,
      // never replay the command under a new ID.
      try { job = await api(`/api/jobs/${encodeURIComponent(requestId)}`); }
      catch (_) { throw error; }
    }
    state.job = job; log(`CODEX ACCEPTED | ${requestId}`);
    status('Javis đang thực hiện', 'Bấm Hủy trên pet/Chi tiết hoặc gọi Javis để đổi nhiệm vụ.', 'executing');
    if(shouldRun)startRecognition('busy-wake');
    await watchJob(job.id, intent);
  } catch (error) { jobBusy = false; fail(`Chưa gửi được nhiệm vụ: ${error.message}`); }
}

function log(text) {
  const line = `${new Date().toLocaleTimeString()}  ${text}`;
  state.events.push(line);
  state.events = state.events.slice(-80);
  $('log').textContent = state.events.join('\n');
}
function status(text, instruction, phase) {
  state.phase = phase;
  $('status').textContent = text;
  $('instruction').textContent = instruction;
  renderPanel();
}
function controls() {
  $('start').disabled = shouldRun || jobBusy || manualPending || !state.supported || !aliases.length;
  $('stop').disabled = !shouldRun;
  $('task-language').disabled = shouldRun;
  $('manual-send').disabled = !state.live || jobBusy || manualPending;
  $('manual-input').disabled = jobBusy || manualPending;
  $('preview-voice').disabled=jobBusy||manualPending||speechBusy||Boolean(pendingQuestion);
  $('preview-done').disabled=jobBusy||manualPending||speechBusy||Boolean(pendingQuestion);
  $('tone').disabled=jobBusy||manualPending||speechBusy||Boolean(pendingQuestion);
  $('send-now').disabled=!shouldRun||(jobBusy&&state.phase!=='busy-task')||manualPending||!state.request.trim()||!['task','busy-task','finalizing'].includes(state.phase);
  document.body.dataset.listening = String(state.listening);
  renderPanel();
}
function stopRecognition() {
  generation++;
  captureEpoch++;requestFinalizeCapture=null;
  clearTimeout(retryTimer); clearTimeout(deadlineTimer); clearTimeout(quietTimer); clearTimeout(flushTimer); clearTimeout(networkStableTimer);
  quietTimer = null; flushTimer = null;
  const old = recognizer; recognizer = null;
  if (old) { try { old.abort(); } catch (_) {} }
  state.listening = false;
  controls();
}
function stop() {
  void stopSpeaking();
  runEpoch++; shouldRun = false; stopRecognition(); disarm();
  status('Đã dừng mic', jobBusy ? 'Nhiệm vụ đã gửi vẫn tiếp tục; kết quả sẽ hiện bên dưới.' : 'Bấm Bắt đầu nghe để thử lại.', 'idle');
}
function fail(message) {
  void dismissPendingQuestion();
  runEpoch++; shouldRun = false; stopRecognition(); disarm();
  state.error = message; $('error').textContent = message;
  status('Chưa thể nghe', 'Kiểm tra thông báo bên dưới, rồi bấm Bắt đầu nghe.', 'error');
  log(`ERROR | ${message}`);
}
function ensureAudio() {
  if(nativePet)return Promise.resolve();
  if (!audioContext) audioContext = new (window.AudioContext || window.webkitAudioContext)();
  return audioContext.resume();
}
async function playTone() {
  await ensureAudio();
  if (audioContext.state !== 'running') throw new Error('Chrome chưa cho phát âm thanh. Bấm Thử “Yes”.');
  if (!readyAudioPromise) {
    const bytes = readyAudioBase64 ? Promise.resolve(Uint8Array.from(atob(readyAudioBase64), value => value.charCodeAt(0)).buffer)
      : fetch('/yes.wav').then(response => {
        if (!response.ok) throw new Error('Không đọc được âm thanh Yes.');
        return response.arrayBuffer();
      });
    readyAudioPromise = bytes.then(value => audioContext.decodeAudioData(value)).catch(error => { readyAudioPromise = null; throw error; });
  }
  const buffer = await readyAudioPromise;
  await new Promise((resolve,reject) => {
    const source = audioContext.createBufferSource(); source.buffer = buffer; source.connect(audioContext.destination);
    const timer = setTimeout(() => { source.onended = null; try { source.stop(); } catch (_) {} source.disconnect(); reject(new Error('Âm thanh Yes không kết thúc đúng hạn.')); }, 5000);
    source.onended = () => { clearTimeout(timer); source.disconnect(); resolve(); };
    source.start();
  });
  log('READY AUDIO | Yes đã phát qua đầu ra Chrome');
}
function nearWakeName(candidate) {
  const fold=value=>value.toLowerCase().replace(/đ/g,'d').normalize('NFD').replace(/\p{M}/gu,'').replace(/\s+/g,'');
  const oneEdit=(left,right)=>{
    if(Math.abs(left.length-right.length)>1)return false;
    let i=0,j=0,changes=0;
    while(i<left.length&&j<right.length){
      if(left[i]===right[j]){i++;j++;continue;}
      if(++changes>1)return false;
      if(left.length>=right.length)i++;
      if(left.length<=right.length)j++;
    }
    return changes+Number(i<left.length||j<right.length)<=1;
  };
  const vector=value=>{
    const padded=`^${value}$`,counts=new Map();
    for(let i=0;i<padded.length-1;i++){const gram=padded.slice(i,i+2);counts.set(gram,(counts.get(gram)||0)+1);}
    return counts;
  };
  candidate=fold(candidate);
  if(!/^[a-z]{5,12}$/.test(candidate))return false;
  const first=vector(candidate),firstNorm=[...first.values()].reduce((sum,count)=>sum+count*count,0);
  return aliases.some(name=>{
    const alias=fold(name);
    if(!/^[a-z]{5,12}$/.test(alias)||!oneEdit(candidate,alias))return false;
    const second=vector(alias),dot=[...first].reduce((sum,[gram,count])=>sum+count*(second.get(gram)||0),0);
    const secondNorm=[...second.values()].reduce((sum,count)=>sum+count*count,0);
    return dot/Math.sqrt(firstNorm*secondNorm)>=.70;
  });
}
function parseWake(text) {
  const names = aliases.map(name => name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  const prefix = new RegExp('^\\s*(?:(?:hey|hay|hi|hai|hello|ê|chào)[\\s,]+)?(?:'
    + names.join('|') + ')\\b[\\s,.:;!?–—-]*(?:ơi\\b[\\s,.:;!?–—-]*)?', 'i');
  const nearPrefix=/^\s*(?:hey|hay|hi|hai|hello|ê|chào)[\s,]+([\p{L}]{5,12})\b[\s,.:;!?–—-]*(?:ơi\b[\s,.:;!?–—-]*)?/iu;
  const nearPhrasePrefix=/^\s*(?:hey|hay|hi|hai|hello|ê|chào)[\s,]+([\p{L}]{2,8}\s+[\p{L}]{2,8})\b[\s,.:;!?–—-]*(?:ơi\b[\s,.:;!?–—-]*)?/iu;
  const original = text.normalize('NFC').trim();
  let remaining = original, matched = false, found;
  while (true) {
    found=prefix.exec(remaining);
    if(!found){const near=nearPrefix.exec(remaining)||nearPhrasePrefix.exec(remaining);if(!near||!nearWakeName(near[1]))break;found=near;}
    matched = true; remaining = remaining.slice(found[0].length).trim();
  }
  return { matched, remaining, wake: matched ? original.slice(0, original.length - remaining.length).trim() : '' };
}
async function acknowledge(wake) {
  state.panelError = '';
  const intent = runEpoch;
  stopRecognition();
  status('Đã nhận tên gọi', 'Đang nói “Yes”…', 'tone');
  notice('Yes','tone',1500);
  try { await playCue('yes'); } catch (error) {
    if (shouldRun && intent === runEpoch) fail(error.message);
    return;
  }
  if (!shouldRun || intent !== runEpoch) return;
  if (state.live) {
    try {
      const value = await requestArm(wake);
      if (!shouldRun || intent !== runEpoch) { disarm(value.grant); return; }
      armGrant = value.grant;
    } catch (error) {
      if (shouldRun && intent === runEpoch) fail(error.message);
      return;
    }
  }
  if (shouldRun && intent === runEpoch) startRecognition('task');
}
function finishTask() {
  if(pendingQuestion && answerGrant){void sendAnswer(state.request.trim());return;}
  if(busyGrant){void executeReplacement();return;}
  if (state.live) { void executeTask(); return; }
  const request = state.request.trim();
  shouldRun = false; stopRecognition();
  if (request) {
    status('Đã nhận nhiệm vụ — chưa gửi', 'Bản thử không gọi Codex. Bấm Bắt đầu nghe để thử tiếp.', 'done');
    log(`PROBE ONLY | ${request}`);
  } else {
    status('Chưa nhận được nhiệm vụ', 'Bấm Bắt đầu nghe để thử lại; chỉ nói sau tiếng “Yes”.', 'idle');
  }
}
function startRecognition(mode,resume=false) {
  if(resume){generation++;recognizer=null;state.listening=false;clearTimeout(retryTimer);clearTimeout(deadlineTimer);clearTimeout(networkStableTimer);controls();}
  else stopRecognition();
  if (!shouldRun) return;
  if((mode==='task'||mode==='busy-task')&&!resume)lastCaptureFinal='';
  const captureToken=captureEpoch;
  const capturing=mode==='task'||mode==='answer'||mode==='busy-task';
  const mine = generation, speech = new Recognition();
  recognizer = speech;
  const language = $('task-language').value;
  speech.lang = language; speech.continuous = mode==='wake'||mode==='busy-wake'||state.live;
  speech.interimResults = true; speech.maxAlternatives = 3;
  const finalized = new Set(), pendingFinals = new Set();
  let taskStarted = false, speechEnded = false, finalizing = false, recognitionEnded = false;
  function completeTask() {
    if (state.live && capturing && pendingFinals.size) {
      fail('Chrome chưa chốt đủ lời nói. Nhiệm vụ chưa gửi; hãy gọi tên và nói lại.');
      return;
    }
    finishTask();
  }
  function captureDeadline() {
    if (mine !== generation || !shouldRun) return;
    if (!state.live) { finishTask(); return; }
    if (finalizing || recognitionEnded || (speechEnded && quietTimer)) return;
    if (!taskStarted && !state.request && !pendingFinals.size) { completeTask(); return; }
    fail('Đã hết thời gian thu mà câu nói chưa kết thúc. Chưa gửi nhiệm vụ; hãy chia thành câu ngắn hơn.');
  }
  if (capturing&&!resume) { state.request = '';state.lastHeard=''; $('request').value = ''; }
  status('Đang kết nối nhận dạng…', 'Chờ Chrome báo đang nghe.', mode);
  speech.onstart = () => {
    if (mine !== generation || !shouldRun) return;
    state.listening = true; controls(); log(`LISTENING | ${mode} | ${language}`);
    if(mode==='wake'||mode==='busy-wake'){
      clearTimeout(networkStableTimer);
      networkStableTimer=setTimeout(()=>{if(mine===generation&&state.listening)networkFailures=0;},15000);
    }
    if (mode === 'wake'||mode==='busy-wake') status(mode==='busy-wake'?'Codex đang làm — nghe tên gọi':language==='vi-VN'?'Đang chờ “Bảo Bối”':'Đang chờ “Hey Jarvis”',mode==='busy-wake'?'Bấm Hủy để dừng; gọi Bảo Bối/Javis để giao việc mới.':'Nói riêng tên gọi, rồi đợi tiếng “Yes”.',mode);
    else {
      status(mode==='answer'?'Your answer?':'JARVIS READY — nói nhiệm vụ',mode==='answer'?(pendingQuestion?.question||'Answer within 20 seconds.'):(state.live ? 'Nói nhiệm vụ; Codex sẽ thực thi sau khi bạn ngừng nói.' : 'Bắt đầu nói ngay. Bản thử chỉ hiện văn bản, không thực thi.'),mode);
      if(mode!=='answer')deadlineTimer = setTimeout(captureDeadline, resume?25000:30000);
    }
  };
  function scheduleSilence() {
    if (finalizing) return;
    clearTimeout(quietTimer);
    quietTimer = setTimeout(() => {
      quietTimer = null;
      if (captureToken!==captureEpoch || !shouldRun || finalizing) return;
      if (recognitionEnded) { completeTask(); return; }
      finalizing = true;
      log(`SILENCE | ${silenceMs/1000}s; yêu cầu Chrome chốt văn bản`);
      status('Đang chốt câu vừa nói', 'Gửi ngay khi Chrome trả bản nhận dạng cuối.', 'finalizing');
      try {
        speech.stop(); // Graceful stop preserves final results; abort would discard them.
        flushTimer = setTimeout(completeTask, 2000);
      } catch (error) { fail(error.message); }
    }, silenceMs);
  }
  requestFinalizeCapture=()=>{
    if(!['task','busy-task'].includes(mode)||captureToken!==captureEpoch||finalizing||!state.request.trim())return;
    clearTimeout(quietTimer);quietTimer=null;
    if(!pendingFinals.size){completeTask();return;}
    finalizing=true;status('Đang chốt câu vừa nói','Gửi ngay sau bản nhận dạng cuối.','finalizing');
    try{speech.stop();flushTimer=setTimeout(completeTask,2000);}catch(error){fail(error.message);}
  };
  speech.onspeechstart = () => {
    if (mine !== generation || !shouldRun || !capturing || !state.live || finalizing) return;
    speechEnded = false;
    clearTimeout(quietTimer);
    if (!taskStarted) { taskStarted = true; if(mode!=='answer'){clearTimeout(deadlineTimer); deadlineTimer = setTimeout(captureDeadline, 60000);} }
  };
  speech.onspeechend = () => {
    if (mine !== generation || !shouldRun || !capturing || !state.live || finalizing) return;
    speechEnded = true;
    scheduleSilence();
  };
  speech.onresult = event => {
    if (mine !== generation || !shouldRun) return;
    // results is a complete snapshot, not an append-only list. Chrome can remove
    // trailing interim entries without returning replacements for their indices.
    pendingFinals.clear();
    for (let i = 0; i < event.results.length; i++) {
      const result = event.results[i];
      if (!result.isFinal && result[0].transcript.trim()) pendingFinals.add(i);
    }
    if (mode === 'task'||mode==='busy-task') log(`RESULTS | changed=${event.resultIndex} total=${event.results.length} pending=${pendingFinals.size}`);
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const result = event.results[i], text = result[0].transcript.trim();
      state.lastHeard=text;
      $('interim').textContent = text || '…';
      if (capturing && state.live && !speechEnded && !finalizing) scheduleSilence();
      if (!result.isFinal || finalized.has(i)) continue;
      finalized.add(i); state.lastFinal = text; $('final').textContent = `Đã chốt (${language}): ${text}`;
      log(`HEARD | ${mode} | ${text}`);
      if(mode==='wake'||mode==='busy-wake')networkFailures=0;
      if(/^(?:cancel|cancle|never mind)[.!?]*$/i.test(text)){
        log('VOICE CANCEL DISABLED | use the Hủy button');
        continue;
      }
      if (capturing) {
        if(mode==='answer'){
          const wake=parseWake(text);if(wake.matched){void dismissPendingQuestion();void acknowledge(wake.wake);return;}
        }
        if((mode==='task'||mode==='busy-task')&&resume&&i===0&&text.toLowerCase().replace(/[\s.!?,]+/g,'')===lastCaptureFinal.toLowerCase().replace(/[\s.!?,]+/g,'')){
          log('RESTART DUPLICATE | kept the previous final segment once');continue;
        }
        if(mode==='task'||mode==='busy-task')lastCaptureFinal=text;
        const repeatedWake = parseWake(text);
        if (!state.request.trim() && repeatedWake.matched && !repeatedWake.remaining) {
          let hasFollowingSpeech = false;
          for (let j = i + 1; j < event.results.length; j++) {
            if (event.results[j][0].transcript.trim()) { hasFollowingSpeech = true; break; }
          }
          if (hasFollowingSpeech) { log('WAKE PREFIX | bỏ tên gọi, giữ phần nhiệm vụ theo sau'); continue; }
          log('WAKE ONLY | gọi lại tên sau READY; nói lại “Yes”, không gửi Codex');
          void (mode==='busy-task'?acknowledgeBusy:acknowledge)(repeatedWake.wake); return;
        }
        state.request = [state.request, text].filter(Boolean).join(' '); $('request').value = state.request;
      } else {
        const combined = Date.now() - greetingAt < 3000 ? `${pendingGreeting} ${text}` : text;
        let wake = parseWake(text);
        if (!wake.matched) wake = parseWake(combined);
        pendingGreeting = /^(hey|hay|hi|hai|hello)[\s,.!?]*$/i.test(text) ? text : '';
        greetingAt = Date.now();
        if (wake.matched) {
          log('WAKE | đã khớp tên gọi');
          if (wake.remaining) log(`CÙNG CÂU | ${wake.remaining} — hãy nói lại nhiệm vụ sau tiếng “Yes”.`);
          void (mode==='busy-wake'?acknowledgeBusy:acknowledge)(wake.wake); return;
        }
      }
    }
    if((mode==='task'||mode==='busy-task')&&pendingFinals.size===0&&immediateSuffix.test(state.request)){
      const command=state.request.replace(immediateSuffix,'').trim();
      if(command){state.request=command;$('request').value=command;requestFinalizeCapture?.();}
    }
  };
  speech.onerror = event => {
    if (mine !== generation || !shouldRun) return;
    log(`RECOGNITION ERROR | ${event.error}`);
    if (event.error === 'no-speech') return;
    if(event.error==='network'&&(mode==='wake'||mode==='busy-wake')&&navigator.onLine!==false&&networkFailures<3){
      const delay=1000*2**networkFailures++;
      stopRecognition();
      status('Đang nối lại nhận dạng giọng nói',`Chrome báo lỗi mạng; thử lại sau ${delay/1000} giây (${networkFailures}/3).`,'reconnecting');
      retryTimer=setTimeout(()=>{if(shouldRun)startRecognition(mode);},delay);
      return;
    }
    const hints = {
      'not-allowed': 'Chrome chưa được cấp quyền mic. Cho phép mic trên trang này rồi bấm Bắt đầu.',
      'service-not-allowed': 'Dịch vụ nhận dạng Chrome không khả dụng trong trình duyệt/profile này.',
      'audio-capture': 'Chrome không mở được microphone. Kiểm tra mic mặc định của Chrome và các ứng dụng đang dùng mic.',
      'network': 'Dịch vụ nhận dạng Chrome báo lỗi mạng. Kiểm tra Internet rồi thử lại.',
      'language-not-supported': 'Dịch vụ Chrome không hỗ trợ ngôn ngữ được chọn.'
    };
    fail(hints[event.error] || `Chrome báo: ${event.error}`);
  };
  speech.onend = () => {
    if (mine !== generation || !shouldRun) return;
    recognitionEnded = true;
    state.listening = false; controls(); log(`END | ${mode}`);
    if (capturing) {
      if (!state.live || finalizing) completeTask();
      else {
        status('Đang chờ chốt câu', `Giữ mốc ${silenceMs/1000} giây im lặng trước khi gửi.`, 'finalizing');
        if (!quietTimer) scheduleSilence();
        if(mode==='task'||mode==='busy-task'){
          clearTimeout(retryTimer);
          retryTimer=setTimeout(()=>{if(captureToken===captureEpoch&&shouldRun&&(!jobBusy||mode==='busy-task'))startRecognition(mode,true);},250);
        }
      }
    }
    else {
      status('Đang nối lại nhận dạng…', 'Chrome đã ngắt phiên nghe; đang thử nối lại.', 'reconnecting');
      retryTimer = setTimeout(() => startRecognition(mode==='busy-wake'?'busy-wake':'wake'), 700);
    }
  };
  try { speech.start(); } catch (error) { fail(error.message); }
}
$('start').onclick = async () => {
  if(jobBusy || manualPending || shouldRun)return;
  networkFailures=0;
  const intent = ++runEpoch;
  shouldRun = true; state.error = ''; state.panelError = ''; $('error').textContent = '';
  pendingGreeting = ''; controls();
  try {
    await ensureAudio();
    if (!shouldRun || intent !== runEpoch) return;
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const microphone = stream.getAudioTracks()[0]?.label || 'Mic mặc định Chrome';
    stream.getTracks().forEach(track => track.stop());
    if (!shouldRun || intent !== runEpoch) return;
    state.microphone = microphone;
    $('microphone').textContent = `Mic Chrome báo: ${state.microphone}. Web Speech dùng đầu vào mặc định của trình duyệt.`;
    if (shouldRun) startRecognition('wake');
  } catch (error) { if (shouldRun && intent === runEpoch) fail(`Không mở được mic: ${error.message}`); }
};
$('stop').onclick = stop;
$('tone').onclick = () => previewAudio('yes');
$('send-now').onclick = () => requestFinalizeCapture?.();
$('manual-send').onclick = sendTyped;
$('refresh-worksets').onclick = loadWorksets;
$('fast-save').onclick=saveFastActions;
$('quick-screenshot').onclick=()=>submitFastAction('screenshot');
$('quick-lock').onclick=()=>submitFastAction('lock');
$('quick-screens-off').onclick=()=>submitFastAction('screens-off');
$('web-save').onclick=saveWebAction;$('web-load').onclick=loadWebAction;$('web-remove').onclick=removeWebAction;
$('work-import').onclick=async()=>{
  try{
    const items=JSON.parse($('work-json').value);
    const value=await api('/api/work/import',{source:$('work-source').value.trim(),items});
    $('work-memory-status').textContent=`Đã nhập ${value.imported} việc từ ${value.source}.`;
  }catch(error){$('work-memory-status').textContent=`Chưa nhập: ${error.message}`;}
};
async function loadWorkPolicy(){
  const source=$('work-source').value.trim();
  try{
    const value=await api('/api/work/policy?'+new URLSearchParams({source}));
    $('work-allow-ai').checked=value.allow_ai===true;
    $('work-memory-status').textContent=value.allow_ai?'Nguồn này được phép gửi sang Codex.':'Nguồn này chỉ dùng cục bộ; chưa gửi dữ liệu sang Codex.';
  }catch(error){$('work-allow-ai').checked=false;$('work-memory-status').textContent=`Không đọc được quyền nguồn: ${error.message}`;}
}
$('work-policy-load').onclick=loadWorkPolicy;
$('work-source').oninput=()=>{$('work-allow-ai').checked=false;$('work-memory-status').textContent='Đã đổi nguồn; đọc quyền nguồn trước khi lưu.';};
$('work-policy-save').onclick=async()=>{
  try{
    const value=await api('/api/work/policy',{source:$('work-source').value.trim(),allow_ai:$('work-allow-ai').checked===true});
    $('work-memory-status').textContent=value.allow_ai?'Đã bật gửi nguồn này sang Codex.':'Đã tắt gửi nguồn này sang Codex.';
  }catch(error){$('work-memory-status').textContent=`Chưa lưu quyền nguồn: ${error.message}`;}
};
$('goal-save').onclick=async()=>{
  try{const value=await api('/api/work/goal',{name:$('goal-name').value.trim(),criteria:$('goal-criteria').value.trim()});
    $('work-memory-status').textContent=`Đã lưu mục tiêu: ${value.name}`;}
  catch(error){$('work-memory-status').textContent=`Chưa lưu mục tiêu: ${error.message}`;}
};
$('goal-list').onclick=async()=>{
  try{const value=await api('/api/work/goals');$('goals-list').textContent=value.goals.map(g=>`${g.id} · ${g.name} — ${g.criteria}`).join('\n')||'Chưa lưu mục tiêu.';}
  catch(error){$('work-memory-status').textContent=error.message;}
};
$('goal-delete').onclick=async()=>{
  try{await api('/api/work/goal/delete',{id:$('goal-delete-id').value.trim()});$('work-memory-status').textContent='Đã xóa mục tiêu.';void $('goal-list').onclick();}
  catch(error){$('work-memory-status').textContent=`Chưa xóa mục tiêu: ${error.message}`;}
};
$('decision-save').onclick=async()=>{
  try{await api('/api/work/decision',{source:$('work-source').value.trim(),item_id:$('decision-item').value.trim(),note:$('decision-note').value.trim()});
    $('work-memory-status').textContent='Đã lưu quyết định cho việc được chọn.';}
  catch(error){$('work-memory-status').textContent=`Chưa lưu quyết định: ${error.message}`;}
};
$('decision-list').onclick=async()=>{
  try{const query=new URLSearchParams({source:$('work-source').value.trim(),item_id:$('decision-item').value.trim()});
    const value=await api('/api/work/decisions?'+query);
    $('decisions-list').textContent=value.decisions.map(d=>`${d.id} · ${d.note} (${d.created_at})`).join('\n')||'Chưa lưu quyết định.';}
  catch(error){$('work-memory-status').textContent=`Không đọc được quyết định: ${error.message}`;}
};
$('decision-delete').onclick=async()=>{
  try{await api('/api/work/decision/delete',{id:$('decision-delete-id').value.trim()});$('work-memory-status').textContent='Đã xóa quyết định.';void $('decision-list').onclick();}
  catch(error){$('work-memory-status').textContent=`Chưa xóa quyết định: ${error.message}`;}
};
function loadVoiceSettings(){
  try{selectedVoice=localStorage.getItem('javis.replyVoice')||'';const gain=Number(localStorage.getItem('javis.cueGain'));if(gain>=.2&&gain<=1)cueGain=gain;}catch(_){}
  const list=window.JavisSpeech?.voices()||[];
  if(typeof document.createElement==='function'){
    $('reply-voice').replaceChildren();
    for(const voice of list){const option=document.createElement('option');option.value=voice.voiceURI||voice.name;option.textContent=voice.name;$('reply-voice').appendChild(option);}
    if(!list.some(v=>(v.voiceURI||v.name)===selectedVoice))selectedVoice=(list.find(v=>/Zira/i.test(v.name))||list[0])?.voiceURI||(list.find(v=>/Zira/i.test(v.name))||list[0])?.name||'';
    $('reply-voice').value=selectedVoice;
  }
  $('cue-volume').value=String(Math.round(cueGain*100));$('cue-level').textContent=`${Math.round(cueGain*100)}%`;
  $('voice-info').textContent=list.length?'Free local English voices. Vietnamese speech is not enabled; no paid service is used.':'No free local English voice is available. Results remain visible in Details.';
}
$('reply-voice').onchange=()=>{selectedVoice=$('reply-voice').value;try{localStorage.setItem('javis.replyVoice',selectedVoice);}catch(_){}};
$('silence-seconds').oninput=()=>{$('silence-value').textContent=`${$('silence-seconds').value} giây`;};
$('silence-save').onclick=async()=>{
  const seconds=Number($('silence-seconds').value);
  try{
    const value=await api('/api/voice-settings',{silence_seconds:seconds});
    silenceMs=value.silence_seconds*1000;
    $('silence-seconds').value=String(value.silence_seconds);
    $('silence-value').textContent=`${value.silence_seconds} giây`;
    $('silence-status').textContent=`Đã lưu ${value.silence_seconds} giây; áp dụng từ lần ngừng nói tiếp theo.`;
  }catch(error){$('silence-status').textContent=`Chưa lưu thời gian chờ: ${error.message}`;}
};
$('cue-volume').oninput=()=>{const value=Number($('cue-volume').value);if(Number.isFinite(value)&&value>=20&&value<=100){cueGain=value/100;$('cue-level').textContent=`${value}%`;try{localStorage.setItem('javis.cueGain',String(cueGain));}catch(_){}}};
async function previewAudio(kind){
  if(jobBusy||manualPending||speechBusy||pendingQuestion)return;
  const intent=runEpoch;stopRecognition();speechBusy=true;controls();
  try{if(kind==='voice')await speakReply('Hello. I am Javis. Your task is complete. What would you like to do next?');else await playCue(kind==='yes'?'yes':'done',null,true);}
  catch(error){notice(error.message,'waiting',6000);}
  finally{speechBusy=false;controls();if(intent===runEpoch && shouldRun)startRecognition('wake');}
}
$('preview-voice').onclick=()=>previewAudio('voice');$('preview-done').onclick=()=>previewAudio('done');
window.speechSynthesis?.addEventListener?.('voiceschanged',loadVoiceSettings);loadVoiceSettings();
bindPanel(document);
window.addEventListener('pagehide', stop);
window.addEventListener('offline', () => { if (shouldRun) fail('Máy đang offline. Nhận dạng Chrome cần kết nối mạng.'); });
fetch('/config', { cache: 'no-store' }).then(response => {
  if (!response.ok) throw new Error('Không đọc được cấu hình tên gọi.');
  return response.json();
}).then(config => {
  nativePet=config.native_pet===true;
  state.live = config.execution_enabled === true;
  readyAudioBase64 = typeof config.ready_audio === 'string' && config.ready_audio.length <= 350000 ? config.ready_audio : '';
  if (Number.isFinite(config.silence_ms) && config.silence_ms >= 500 && config.silence_ms <= 20000) silenceMs = config.silence_ms;
  $('silence-seconds').value=String(Math.max(5,silenceMs/1000));
  $('silence-value').textContent=`${Math.max(5,silenceMs/1000)} giây`;
  csrfToken = config.csrf_token || '';
  if (state.live) {
    $('mode-badge').textContent = 'CODEX FULL ACCESS — THỰC THI THẬT';
    $('intro').textContent = 'Gọi tên, chờ tiếng “Yes” rồi nói nhiệm vụ. Bộ công việc và tiện ích đã hỗ trợ chạy trực tiếp; yêu cầu khác gửi vào phiên Codex hiện có.';
    $('request-title').textContent = 'Nhiệm vụ đã nhận';
    $('execution').hidden = false;
    $('desktop').hidden = false;
    void loadWorksets();
    void loadFastActions();
    void loadWorkPolicy();
    $('session').textContent = `Phiên cố định: ${config.session_id}`;
    $('privacy').textContent = 'Chrome có thể gửi audio tới dịch vụ nhận dạng của trình duyệt. Tiện ích trực tiếp không gọi Codex; yêu cầu khác dùng phiên Codex đã lưu. Nhật ký nhiệm vụ lưu cục bộ; yêu cầu AI còn lưu trong lịch sử Codex. Không lưu bản thu. Dừng mic không hủy nhiệm vụ đã gửi.';
    document.title = 'Jarvis — Chrome Voice + Codex';
    void api('/api/state').then(value => {
      if (value.active) { jobBusy = true; controls(); void watchJob(value.active.id, runEpoch); }
    }).catch(error => fail(error.message));
  }
  aliases = [...new Set(['jarvis','javis',...config.wake_aliases].map(name => name.toLowerCase().trim()))]
    .filter(Boolean).sort((a,b) => b.length - a.length);
  log(`WAKE NAMES | ${aliases.join(', ')}`);
  if (!Recognition) fail('Không có Web Speech API. Hãy mở bằng Google Chrome desktop.');
  else status('Sẵn sàng thử', 'Bấm Bắt đầu, cho phép mic nếu Chrome hỏi, rồi nói riêng “Hey Jarvis”.', 'idle');
  controls();
  if(nativePet)void pumpPet();
}).catch(error => fail(error.message));
