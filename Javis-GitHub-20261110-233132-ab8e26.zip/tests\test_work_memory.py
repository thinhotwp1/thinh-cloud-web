import json
from pathlib import Path
import tempfile
import unittest
from datetime import datetime,timezone,timedelta
from memory_store import MemoryStore
from work_memory import WorkMemory


class WorkMemoryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.memory=MemoryStore(self.root);self.work=WorkMemory(self.memory)
        self.work.import_items('dashboard',[{'item_id':'A','title':'Deploy API','status':'in progress','observed_at':'2026-11-06T09:00:00+07:00','source_ref':'https://work.example/tasks/A','reason':'Waiting for API review'},
            {'item_id':'B','title':'Frontend bug','status':'blocked','observed_at':'2026-11-06T09:00:00+07:00','source_ref':'https://work.example/tasks/B','reason':'Blocked by design decision'}])
        self.work.import_items('dashboard',[{'item_id':'A','title':'Deploy API','status':'done','observed_at':'2026-11-07T09:00:00+07:00','source_ref':'https://work.example/tasks/A','reason':'API review completed'},
            {'item_id':'B','title':'Frontend bug','status':'blocked','observed_at':'2026-11-07T09:00:00+07:00','source_ref':'https://work.example/tasks/B','reason':'Blocked by design decision'}])
    def tearDown(self):self.temp.cleanup()
    def test_status_uses_latest_sourced_snapshot_without_model(self):
        result=self.work.answer('Việc A làm tới đâu rồi?')
        self.assertEqual(result.outcome,'success');self.assertIn('done',str(result));self.assertIn('2026-11-07',str(result))
    def test_why_returns_bounded_source_evidence_for_one_model_turn(self):
        rows=self.work.evidence('Việc B tại sao chưa hoàn thành?')
        self.assertEqual(len(rows),1);self.assertEqual(rows[0]['item_id'],'B')
        self.assertEqual(rows[0]['reason'],'Blocked by design decision')
        self.assertEqual(rows[0]['previous_status'],'blocked')
    def test_missing_reason_is_not_invented(self):
        self.work.import_items('dashboard',[{'item_id':'C','title':'Unknown blocker','status':'blocked','observed_at':'2026-11-07T10:00:00+07:00','source_ref':'https://work.example/tasks/C'}])
        result=self.work.answer('Tại sao việc C chưa xong?')
        self.assertEqual(result.outcome,'partial');self.assertIn('chưa có bằng chứng',str(result).lower())
        self.assertEqual(self.work.evidence('Tại sao việc C chưa xong?'),[])
    def test_explicit_goal_and_decision_can_be_recalled_and_removed(self):
        goal=self.work.save_goal('Ổn định dashboard','Không còn việc bị chặn','user')
        note=self.work.save_decision('dashboard','B','Tạm hoãn do thiết kế chưa duyệt','user')
        self.assertEqual(self.work.get_goal(goal['id'])['name'],'Ổn định dashboard')
        self.assertEqual(self.work.list_goals()[0]['id'],goal['id'])
        self.assertIn('thiết kế chưa duyệt',self.work.evidence('Việc B vì sao chưa hoàn thành?')[0]['decision'])
        self.work.delete_decision(note['id']);self.assertNotIn('decision',self.work.evidence('Việc B vì sao chưa hoàn thành?')[0])
        self.work.delete_goal(goal['id']);self.assertEqual(self.work.list_goals(),[])
    def test_import_rejects_unbounded_or_untrusted_records(self):
        with self.assertRaises(ValueError):self.work.import_items('dashboard',[{'item_id':'bad','title':'X','status':'open','observed_at':'invalid'}])
        with self.assertRaises(ValueError):self.work.import_items('dashboard',[{'item_id':'bad','title':'X','status':'open','observed_at':'2026-11-07T09:00:00+07:00','source_ref':'file:///C:/secret'}])
        with self.assertRaises(ValueError):self.work.import_items('dashboard',[{'item_id':'bad','title':'X','status':'open','observed_at':'2026-11-07T09:00:00+07:00','source_ref':'http://127.0.0.1:8766/'}])
    def test_old_sourced_snapshot_is_pruned_without_losing_current_status(self):
        self.work.import_items('dashboard',[dict(item_id='A',title='Deploy API',status='open',observed_at='2026-07-01T09:00:00+07:00',source_ref='https://work.example/tasks/A',reason='Old reason')])
        self.work.prune(now=datetime(2026,11,7,tzinfo=timezone.utc).timestamp())
        with self.memory.connection() as db:
            self.assertEqual(db.execute("SELECT count(*) FROM work_snapshots WHERE item_id='A'").fetchone()[0],2)
            self.assertEqual(db.execute("SELECT count(*) FROM work_snapshots WHERE reason='Old reason'").fetchone()[0],0)
        self.assertEqual(self.work.answer('Việc A tới đâu?').outcome,'success')
    def test_yesterday_uses_dated_status_and_reason(self):
        self.work.clock=lambda:datetime(2026,11,7,12,tzinfo=timezone.utc).timestamp()
        self.work.local_tz=timezone(timedelta(hours=7))
        status=self.work.answer('Việc A hôm qua làm tới đâu?')
        self.assertIn('in progress',str(status))
        self.assertIn('2026-11-06',str(status))
        row=self.work.evidence('Việc A hôm qua tại sao chưa hoàn thành?')[0]
        self.assertEqual(row['status'],'in progress')
        self.assertEqual(row['reason'],'Waiting for API review')
        self.assertIn('2026-11-06',row['reason_observed_at'])
    def test_old_reason_is_not_presented_as_current_reason(self):
        self.work.import_items('dashboard',[dict(item_id='D',title='Design',status='blocked',observed_at='2026-11-06T09:00:00+07:00',source_ref='https://work.example/D',reason='Waiting for review')])
        self.work.import_items('dashboard',[dict(item_id='D',title='Design',status='blocked',observed_at='2026-11-07T09:00:00+07:00',source_ref='https://work.example/D')])
        self.assertEqual(self.work.evidence('Tại sao việc D chưa xong?'),[])
    def test_source_ai_permission_defaults_off_and_is_per_source(self):
        self.assertFalse(self.work.ai_allowed('dashboard'))
        self.work.set_ai_permission('dashboard',True)
        self.assertTrue(self.work.ai_allowed('dashboard'))
        self.assertFalse(self.work.ai_allowed('other'))
        self.work.set_ai_permission('dashboard',False)
        self.assertFalse(self.work.ai_allowed('dashboard'))
    def test_retention_runs_on_long_lived_read(self):
        moment=[datetime(2026,11,7,12,tzinfo=timezone.utc).timestamp()]
        with tempfile.TemporaryDirectory() as folder:
            fresh=WorkMemory(MemoryStore(Path(folder)),clock=lambda:moment[0])
            fresh.save_goal('Old goal','Old criteria','user')
            fresh.save_decision('dashboard','A','Old decision','user')
            self.assertEqual(len(fresh.list_goals()),1)
            moment[0]+=91*86400
            self.assertEqual(fresh.list_goals(),[])
            self.assertEqual(fresh.list_decisions('dashboard','A'),[])
    def test_dashboard_why_uses_unfinished_items_and_discloses_missing_reasons(self):
        self.work.import_items('dashboard',[dict(item_id='C',title='Undiagnosed',status='blocked',observed_at='2026-11-07T10:00:00+07:00',source_ref='https://work.example/tasks/C')])
        result=self.work.answer('Tại sao dashboard nhiều việc chưa xong?')
        self.assertEqual(result.outcome,'partial')
        self.assertIn('B',str(result))
        self.assertIn('C',str(result))
        self.assertNotIn('API review completed',str(result))
