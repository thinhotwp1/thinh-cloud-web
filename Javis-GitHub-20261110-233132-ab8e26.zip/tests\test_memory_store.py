from pathlib import Path
import tempfile
import unittest
import json
import sqlite3
from memory_store import MemoryStore
from execution_result import ExecutionResult, parse_codex_result


class MemoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.store = MemoryStore(self.root)

    def tearDown(self):
        self.tmp.cleanup()

    def test_durable_ids_steps_privacy_and_restart(self):
        job = dict(id='a', text='open https://x.test/a?token=private', state='running')
        self.store.begin_job(job, 'grant-secret')
        with self.assertRaises(ValueError): self.store.begin_job(job, 'grant-secret')
        job.update(state='completed', outcome='success', reply='ok')
        self.store.finish_job(job, [dict(label='step', state='success', evidence='ok')]*30)
        reopened = MemoryStore(self.root)
        saved = reopened.get_job('a')
        self.assertEqual(saved['outcome'], 'success')
        self.assertEqual(len(saved['steps']), 20)
        self.assertNotIn('private', json.dumps(saved))
        self.assertNotIn('grant-secret', reopened.path.read_bytes().decode('latin1'))
        self.assertTrue(reopened.matches_retry('a', 'grant-secret', job['text']))

    def test_interrupted_is_not_success_and_context_bounded(self):
        self.store.begin_job(dict(id='a',text='work',state='running'), 'g')
        self.assertEqual(MemoryStore(self.root).get_job('a')['state'], 'interrupted')
        for i in range(15):
            record=dict(id=str(i),text='x'*8000,state='completed',outcome='success',reply='y'*4000)
            self.store.begin_job(record, 'g');self.store.finish_job(record, [])
        context=self.store.summary_context('today', 'a')
        self.assertLessEqual(len(context.encode()),12000)
        self.assertNotIn('grant',context)

    def test_bad_legacy_import_and_notification_claims(self):
        other=self.root/'other';(other/'state').mkdir(parents=True)
        (other/'state/webspeech-requests.jsonl').write_text('{bad\n'+json.dumps(dict(id='old',text='old',state='completed',reply='done'))+'\n')
        store=MemoryStore(other)
        self.assertEqual(store.get_job('old')['outcome'],'unknown')
        self.assertTrue(store.claim_notification('old','done'))
        self.assertFalse(MemoryStore(other).claim_notification('old','done'))

    def test_corrupt_database_fails_without_replacing_it(self):
        other=self.root/'bad';(other/'state').mkdir(parents=True)
        target=other/'state/javis.sqlite3';target.write_bytes(b'not sqlite')
        with self.assertRaises(sqlite3.DatabaseError): MemoryStore(other)
        self.assertEqual(target.read_bytes(),b'not sqlite')
    def test_summary_keeps_latest_job_even_with_many_unicode_steps(self):
        job=dict(id='unicode',text='tổng hợp',state='completed',outcome='success',reply='kết quả')
        self.store.begin_job(job,'g')
        self.store.finish_job(job,[dict(label='bước '*80,state='success',evidence='bằng chứng '*80)]*20)
        context=self.store.summary_context('last task')
        self.assertEqual(json.loads(context)[0]['id'],'unicode')
        self.assertLessEqual(len(context.encode()),12000)
    def test_locked_database_does_not_accept_an_unjournaled_job(self):
        with self.store.connection() as held:
            held.execute('BEGIN IMMEDIATE')
            with self.assertRaises(sqlite3.OperationalError):
                self.store.begin_job(dict(id='locked',text='work',state='queued'),'g')
        self.assertIsNone(self.store.get_job('locked'))

    def test_codex_result_does_not_infer_success_from_text(self):
        self.assertEqual(parse_codex_result('Done').outcome,'unknown')
        valid={'version':1,'outcome':'success','reply':'opened','steps':[{'label':'Open','state':'success','evidence':'https://example.com'}]}
        self.assertEqual(parse_codex_result(json.dumps(valid)).outcome,'success')
        valid['steps']=[]
        self.assertEqual(parse_codex_result(json.dumps(valid)).outcome,'unknown')
        self.assertIsInstance(ExecutionResult('ok','success',[]),str)
